$(document).ready(function(){
	$("#srcHdr").validate({
		rules:{
			srcKey:{
				required: true,
			},
		},
		messages:{
			srcKey:{
				required: null,
			},
		},
        submitHandler : function () {
			// your function if, validate is success
			$.ajax({
				type : "POST",
				url : baseUrl + "search/getrslt",
				data : $('#srcHdr').serialize(),
				dataType : "json",
				success : function (data) {
					if(data.status == "ok")
					{
						if(data.cat !== null)
						{
							window.location.href = baseUrl + "search?getct="+data.cat+"&srcKey="+data.key;
							return false;
						}else
						{
							window.location.href = baseUrl + "search?srcKey="+data.key;
							return false;
						}
					}else
					{
						//have end check.
					}
					return false;
				}
			});
        }
    });
	
	$("#productRequest").validate({
		rules:{
			name:{
				required: true,
			},
			phone:{
				required: true,
				number: true,
			},
			email:{
				required: true,
				email: true,
			},
			address:{
				required: true,
			},
		},
        submitHandler : function () {
			// your function if, validate is success
			$.ajax({
				type : "POST",
				url : baseUrl + "search/sendproductrequest",
				data : $('#productRequest').serialize(),
				dataType : "json",
				success : function (data) {
					if(data.status == "ok")
					{
						$('#subsuccess').html(data.success);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
        }
    });
	

	$(document).on('change', '#minOrdrQnty', function(){
		var price_main = parseInt($('#gtPrice').val());
		var main_qty = parseInt($('#minOrdrQnty').val());
		var total = price_main * main_qty;
		var total_htl = '<strong>Total Price :&nbsp;&nbsp;</strong> TK.'+total;
		$('#totalDynamicAmount').html(total_htl);
	});
	$(document).on('change', '#selOptPrice', function(){
		var qty = $('#minOrdrQnty').val();
		var price = $('#gtPrice').val();
		get_option_price($(this).val(), qty, price);
	});
	$(document).on('click', '#cpnSubmit', function(){
		var coupon_code = $('#cpnCode').val();
		var totalcrt_amnt = $(this).attr('data-crttal');
		if(coupon_code !== '')
		{
			apply_coupon(coupon_code, totalcrt_amnt);
		}else
		{
			$('#cpnSubMessg').html('<div class="alert alert-danger">Coupon code is empty!</div>');
		}
	});
	$(document).on('click', '#gotFb', function(){
		$('#loader').show();
		gotoFacebook($(this).attr('goto-fb'));
	});
	$(document).on('click', '#gotGgl', function(){
		$('#loader').show();
		gotoGoogle($(this).attr('goto-ggl'));
	});
	$(document).on('click', '#upfile', function(){
		$('#hideFile').click();
	});
	$(document).on('change', '#hideFile', function(){
		$('#dashbrdLoader').show();
		single_photo();
	});
	$(document).on('click', '#upprescript', function(){
		$('#hidePrescriptFile').click();
	});
	$(document).on('change', '#hidePrescriptFile', function(){
		$('#dashbrdLoader').show();
		single_prescription();
	});
	$("#loginform").validate({
		rules:{
			emailuser:{
				required: true,
			},
			passrd:{
				required: true,
			}
		},
        submitHandler : function () {
			$('#loader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/login/checkuser",
                data : $('#loginform').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("loginform").reset();
						$('#loader').hide();
						$("#alert").html(data.success);
						if(data.if_rdr_url)
						{
							window.setTimeout(function(){
								window.location.href = data.if_rdr_url;
							}, 3000);
						}else
						{
							window.setTimeout(function(){
								window.location.href = baseUrl + "customer/dashboard";
							}, 3000);
						}
						return false;
					}else if(data.status == "warning")
					{
						document.getElementById("loginform").reset();
						$('#loader').hide();
						$("#alert").html(data.warning);
						return false;
					}else if(data.status == "failed_error")
					{
						document.getElementById("loginform").reset();
						$('#loader').hide();
						$("#alert").html(data.error);
						return false;
					}else if(data.status == "valid_error")
					{
						document.getElementById("loginform").reset();
						$('#loader').hide();
						$("#alert").html(data.validation_error);
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#signupForm").validate({
		rules:{
			fullname:{
				required: true,
			},
			email:{
				required: true,
			},
			password:{
				required: true,
			}
		},
        submitHandler : function () {
			$('#signloader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/register/register_customer",
                data : $('#signupForm').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "exok")
					{
						document.getElementById("signupForm").reset();
						$('#signloader').hide();
						$("#signupalert").html(data.exist_content);
						return false;
					}else if(data.status == "ok"){
						document.getElementById("signupForm").reset();
						$('#signloader').hide();
						$("#signupalert").html(data.success_content);
						window.setTimeout(function(){
							window.location.href = baseUrl + "customer/dashboard";
						}, 3000);
						return false;
					}else if(data.status == "notok")
					{
						document.getElementById("signupForm").reset();
						$('#signloader').hide();
						$("#signupalert").html(data.failed_content);
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#prfup").validate({
		rules:{
			full_name:{
				required: true,
			},
			phone:{
				required: true,
				number: true,
			},
			email:{
				required: true,
				email: true,
			}
		},
        submitHandler : function () {
			$('#cartPageLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/dashboard/update_profile",
                data : $('#prfup').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("prfup").reset();
						$('#cartPageLoader').hide();
						$("#prfUpdate").html(data.success_content);
						setTimeout(function() {
							$(".successMsg").fadeOut('slow', function(){
							  $(this).remove();
							});
						}, 3000 );
						$('html, body').animate({
							scrollTop: $("body").offset().top
						 }, 2000);
						 setTimeout(function() {
							 window.location.reload();
						  }, 5000);
						return false;
					}else if(data.status == "nok")
					{
						document.getElementById("prfup").reset();
						$('#cartPageLoader').hide();
						$("#prfUpdate").html(data.failed_content);
						$('html, body').animate({
							scrollTop: $("body").offset().top
						 }, 2000);
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#upPassrf").validate({
		rules:{
			password:{
				required: true,
			},
			repass:{
				required: true,
				equalTo: "#Password",
			}
		},
        submitHandler : function () {
			$('#cartPageLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/dashboard/update_password",
                data : $('#upPassrf').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("upPassrf").reset();
						$('#cartPageLoader').hide();
						$("#prfUpdate").html(data.success_content);
						setTimeout(function() {
							$(".successMsg").fadeOut('slow', function(){
							  $(this).remove();
							});
						}, 3000 );
						$('html, body').animate({
							scrollTop: $("body").offset().top
						 }, 2000);
						return false;
					}else if(data.status == "nok")
					{
						document.getElementById("upPassrf").reset();
						$('#cartPageLoader').hide();
						$("#prfUpdate").html(data.failed_content);
						$('html, body').animate({
							scrollTop: $("body").offset().top
						 }, 2000);
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#rcvrEmal").validate({
		rules:{
			email:{
				required: true,
				email: true,
			}
		},
        submitHandler : function () {
			$('#cartPageLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/login/checkmail",
                data : $('#rcvrEmal').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("rcvrEmal").reset();
						setTimeout(function() {
							window.location.href = baseUrl + "customer/login/reset";
						}, 3000 );
						return false;
					}else if(data.status == "notok")
					{
						document.getElementById("rcvrEmal").reset();
						$("#recvrMessg").html(data.error);
						$('#cartPageLoader').hide();
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#restFrm").validate({
		rules:{
			resetcd:{
				required: true,
				number: true,
			}
		},
        submitHandler : function () {
			$('#cartPageLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/login/checkcode",
                data : $('#restFrm').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("restFrm").reset();
						setTimeout(function() {
							window.location.href = baseUrl + "customer/login/newpassword";
						}, 3000 );
						return false;
					}else if(data.status == "notok")
					{
						document.getElementById("restFrm").reset();
						$("#recvrMessg").html(data.error);
						$('#cartPageLoader').hide();
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#newPassSet").validate({
		rules:{
			password:{
				required: true,
			},
			password_confirmation:{
				required: true,
				equalTo: "#nWpass",
			}
		},
        submitHandler : function () {
			$('#cartPageLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "customer/login/update_password",
                data : $('#newPassSet').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("newPassSet").reset();
						setTimeout(function() {
							window.location.href = baseUrl + "customer/login/success";
						}, 3000 );
						return false;
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#subsCribe").validate({
		rules:{
			email:{
				required: true,
				email: true,
			}
		},
		messages:{
			email:{
				required: null,
				email: null,
			}
		},
        submitHandler : function () {
			$('#subscriLoader').show();
            // your function if, validate is success
            $.ajax({
                type : "POST",
                url : baseUrl + "subscribe/save_email",
                data : $('#subsCribe').serialize(),
                dataType : "json",
                success : function (data) {
					if(data.status == "ok")
					{
						document.getElementById("subsCribe").reset();
						$('#subscribeMessg').html(data.success_content);
						$('#subscriLoader').hide();
						return false;
					}else if(data.status == "notok"){
						document.getElementById("subsCribe").reset();
						$('#subscribeMessg').html(data.exist_email);
						$('#subscriLoader').hide();
					}else
					{
						//have end check.
					}
					return false;
                }
            });
        }
    });
	
	$("#minMaxPrice").validate({
		rules:{
			min:{
				required: true,
			},
			max:{
				required: true,
			}
		},
		messages:{
			min:{
				required: '',
			},
			max:{
				required: '',
			}
		},
        submitHandler : function () {
			window.location=document.getElementById('minMaxPrice').attr('action');
        }
    });
	
	$("#srcHdr").validate({
		rules:{
			getct:{
				required: true,
			},
			s:{
				required: true,
			}
		},
		messages:{
			getct:{
				required: '',
			},
			s:{
				required: '',
			}
		},
        submitHandler : function () {
			window.location=document.getElementById('srcHdr').attr('action');
        }
    });
	
});
function gotoFacebook(val)
{
	setTimeout(function() {
		 window.location.href=val;
	}, 3000);
}
function gotoGoogle(val)
{
	setTimeout(function() {
		 window.location.href=val;
	}, 3000);
}
function get_option_price(val, qty, price)
{
	$('#cartLoader').show();
	$.ajax({
		type : "POST",
		url : baseUrl + "variation/get_price",
		data : {option:val, qty:qty, price:price},
		dataType : "json",
		success : function (data) {
			if(data.status == "ok")
			{
				$('#priceInpt').html(data.price_content);
				$('#totalDynamicAmount').html('<strong>Total Price :&nbsp;&nbsp;</strong> TK.'+data.price);
				$('#cartLoader').hide();
				return false;
			}else if(data.status == "null"){
				$('#cartLoader').hide();
			}else
			{
				//have end check.
			}
			return false;
		}
	});
}
function single_prescription()
{
	var val = $('#upprescript').attr('data-order-number');
	var data = new FormData();
	data.append('attachment_file', $('#hidePrescriptFile').prop('files')[0]);
	data.append('order_number', val);
	$.ajax({
		   type:"POST",
		   url: baseUrl + "customer/dashboard/prescriptionup",
		   data: data,
		   dataType: 'json',
		   mimeType: "multipart/form-data",
		   contentType: false,
		   cache: false,
		   processData: false,
		   success: function(data){
				if(data.status == 'ok'){
					$("#prescriptionPreview").html(data.imgurl);
					$('#dashbrdLoader').hide();
				}else{
					//error occured.
				}
		   }
	});
}
function single_photo()
{
	var data = new FormData();
	data.append('attachment_file', $('#hideFile').prop('files')[0]);
	$.ajax({
		   type:"POST",
		   url: baseUrl + "customer/dashboard/singleimg",
		   data: data,
		   dataType: 'json',
		   mimeType: "multipart/form-data",
		   contentType: false,
		   cache: false,
		   processData: false,
		   success: function(data){
				if(data.status == 'ok'){
					$("#profilPhoto").html(data.imgurl);
					$('#dashbrdLoader').hide();
				}else{
					//error occured.
				}
		   }
	});
}
function apply_coupon(coupon_code, totalcrt_amnt)
{
	$('#reviewPageLoader').show();
	$.ajax({
		type : "POST",
		url : baseUrl + "coupon/apply_coupon",
		data : {coupon_code:coupon_code, totalcrt_amnt:totalcrt_amnt},
		dataType : "json",
		success : function (data) {
			if(data.status == "error")
			{
				$('#cpnSubMessg').html(data.error_message);
				$('#cpnCode').val('');
				$('#reviewPageLoader').hide();
				return false;
			}else if(data.status == "expire"){
				$('#cpnSubMessg').html(data.expre_message);
				$('#cpnCode').val('');
				$('#reviewPageLoader').hide();
				return false;
			}else if(data.status == "ok"){
				$('#copnContainer').html(data.coupon_content);
				$('#cpnCode').val('');
				$('#reviewPageLoader').hide();
				return false;
			}else
			{
				//have end check.
			}
			return false;
		}
	});
}