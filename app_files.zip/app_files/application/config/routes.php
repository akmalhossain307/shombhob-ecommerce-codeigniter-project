<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
//$route['default_controller'] = 'welcome';
//$route['default_controller'] = 'pages';
//$route['test'] = 'pages/test';


// Routes for admin panel

$route['dashboard'] 	    = 'Dashboard/index';
$route['admin'] 	    	= 'Dashboard/login';
$route['admin-login'] 	    = 'Dashboard/login';
$route['login'] 			= 'Dashboard/checkLogin';
$route['logout'] 			= 'Dashboard/logout';

//Routes for user management
$route['admin/create-new-user'] 			= 'Users/createNewUser';
$route['admin/user-list'] 					= 'Users/userList';
$route['admin/saveUser'] 					= 'Users/saveUser';
$route['admin/delete-user/(:any)'] 		    = 'Users/deleteWebsiteUser/$1';
$route['admin/change-website-user-password']= 'Users/changeWebsiteUserPassword';
$route['admin/change-password']             = 'Users/changeUserPassword';


$route['default_controller'] = 'pages';
$route['main_domain'] = 'pages/index';
$route['fb-logout'] = 'pages/logout';

// Routes for SSL Payment 
$route['payment'] = 'payment/index';
$route['requestssl'] = 'order/request_api_hosted';
$route['success'] = 'order/success_payment';
$route['fail'] = 'order/fail_payment';
$route['cancel'] = 'order/cancel_payment';
$route['ipn'] = 'order/ipn_listener';

// Routes for re-order or re-payment
$route['repayment/(:any)'] 	= 'order/re_order/$1';

$route['requestssl1'] = 'order/request_api_hosted1';
$route['success1'] = 'order/success_payment1';
$route['fail1'] = 'order/fail_payment1';
$route['cancel1'] = 'order/cancel_payment1';
$route['ipn1'] = 'order/ipn_listener1';


// Routes for front-end
// Route for displaying products by category and sub-category 
$route['products/category/(:any)']='Product/fetchProductSubCategoryByCategory/$1';
$route['products/sub-category/(:any)']='Product/fetchProductBySubCategory/$1';

// Routes for checkout
$route['checkout'] 							= 'Checkout/index';

// Routes for single product details
$route['category/(:any)'] 			= 'Product/fetchProductBySubCategory/$1';
$route['(:any)'] 			= 'Product/getSingleProductDetails/$1';
//$route['/(:any)'] 			= 'Product/getSingleProductDetails/$1';
$route['offerProductDetails/(:any)'] 		= 'Product/getSingleOfferProductDetails/$1';
$route['request-restock'] 		= 'Product/productRestockRequest';

// Routes for search
$route['search/productRequest'] 			= 'Search/saveProductRequest';
$route['search/addSubscribe'] 				= 'Search/saveSubscriber';

// Route for pages 
$route['offers'] 							= 'Pages/offerPage';
$route['pages'] 							= 'Pages/displayPage';
$route['page/faq'] 							    = 'Pages/faq';
$route['page/about-us'] 							= 'Pages/about';
$route['page/privacy-confidentiality'] 			= 'Pages/privacy';
$route['page/terms-conditions'] 					= 'Pages/terms_conditions';
$route['page/return-refund-policy'] 				= 'Pages/return_refund_policy';
$route['page/how-to-order'] 						= 'Pages/how_to_order';
$route['page/contact'] 						    = 'Pages/contact';
$route['page/sitemap'] 							= 'Pages/sitemap';


// Other routes 
$route['uploadPrescription'] 				= 'Customer/uploadPrescription';




// Routes for marchant panel

$route['marchantDashboard'] = 'Marchant/marchantDashboard';
$route['marchant'] 			= 'Marchant/login';
$route['marchantRegister'] 	= 'Marchant/register';
$route['registerMarchant'] 	= 'Marchant/registerMarchant';
$route['loginMarchant'] 	= 'Marchant/checkLogin';
$route['marchantLogout'] 	= 'Marchant/logout';




//Routes for settings
$route['admin/generalSettings'] 			= 'DashboardSettings/generalSettings';
$route['admin/updateGeneralSettings'] 		= 'DashboardSettings/updateGeneralSettings';
$route['admin/socialSettings'] 				= 'DashboardSettings/socialSettings';
$route['admin/updateSocialSettings'] 		= 'DashboardSettings/updateSocialSettings';
$route['admin/managePages'] 				= 'DashboardSettings/managePages';
$route['admin/page/create'] 				= 'DashboardSettings/createPage';
$route['admin/page/save'] 					= 'DashboardSettings/savePage';
$route['admin/page/edit/(:any)'] 			= 'DashboardSettings/editPage/$1';
$route['admin/page/update/(:any)'] 			= 'DashboardSettings/updatePage/$1';
$route['admin/page/delete/(:any)'] 			= 'DashboardSettings/deletePage/$1';

// Routes for slider
$route['admin/manageSliders'] 				= 'DashboardSettings/manageSliders';
$route['admin/slider/create'] 				= 'DashboardSettings/createSlider';
$route['admin/slider/save'] 				= 'DashboardSettings/saveSlider';
$route['admin/slider/edit/(:any)'] 			= 'DashboardSettings/editSlider/$1';
$route['admin/slider/update/(:any)'] 		= 'DashboardSettings/updateSlider/$1';
$route['admin/slider/delete/(:any)'] 		= 'DashboardSettings/deleteSlider/$1';

// Routes for banner
$route['admin/manageBanners'] 				= 'DashboardSettings/manageBanners';
$route['admin/banner/create'] 				= 'DashboardSettings/createBanner';
$route['admin/banner/save'] 				= 'DashboardSettings/saveBanner';
$route['admin/banner/edit/(:any)'] 			= 'DashboardSettings/editBanner/$1';
$route['admin/banner/update/(:any)'] 		= 'DashboardSettings/updateBanner/$1';
$route['admin/banner/delete/(:any)'] 		= 'DashboardSettings/deleteBanner/$1';

// Routes for category
$route['admin/categoryList'] 				= 'DashboardCategory/index';
$route['admin/category/add'] 				= 'DashboardCategory/addCategory';
$route['admin/category/create'] 			= 'DashboardCategory/createCategory';
$route['admin/category/view/(:any)'] 		= 'DashboardCategory/viewCategory/$1';
$route['admin/category/update/(:any)'] 		= 'DashboardCategory/updateCategory/$1';
$route['admin/category/delete/(:any)'] 		= 'DashboardCategory/deleteCategory/$1';

// Routes for sub-category
$route['admin/subCategoryList'] 			= 'DashboardCategory/subCategory';
$route['admin/subCategory/create'] 			= 'DashboardCategory/createSubCategory';
$route['admin/subCategory/save'] 			= 'DashboardCategory/saveSubCategory';
$route['admin/subCategory/view/(:any)'] 	= 'DashboardCategory/viewSubCategory/$1';
$route['admin/subCategory/update/(:any)'] 	= 'DashboardCategory/updateSubCategory/$1';
$route['admin/subCategory/delete/(:any)'] 	= 'DashboardCategory/deleteSubCategory/$1';

// Routes for brand
$route['admin/brandList'] 					= 'DashboardCategory/brand';
$route['admin/brand/create'] 				= 'DashboardCategory/createBrand';
$route['admin/brand/view/(:any)'] 			= 'DashboardCategory/viewBrand/$1';
$route['admin/brand/update/(:any)'] 		= 'DashboardCategory/updateBrand/$1';
$route['admin/brand/delete/(:any)'] 		= 'DashboardCategory/deleteBrand/$1';

// Routes for product
$route['admin/productList']					= 'DashboardProduct/index';
$route['admin/product/create']				= 'DashboardProduct/createProduct';
$route['admin/product/save']				= 'DashboardProduct/saveProduct';
$route['admin/product/view/(:any)'] 		= 'DashboardProduct/viewProduct/$1';
$route['admin/product/edit/(:any)'] 		= 'DashboardProduct/editProduct/$1';
$route['admin/product/saveUpdate/(:any)']	= 'DashboardProduct/updateProduct/$1';
$route['admin/product/delete/(:any)'] 		= 'DashboardProduct/deleteProduct/$1';
$route['admin/product/stockOutProduct'] 	= 'DashboardProduct/stockOutProduct';
$route['admin/product/requestedProduct'] 	= 'DashboardProduct/requestedProduct';
$route['admin/product/requestedProduct/delete/(:any)'] 	= 'DashboardProduct/deleteRequestedProduct/$1';
$route['admin/product/couponList'] 			='DashboardProduct/couponList';
$route['admin/product/createCoupon'] 		='DashboardProduct/createCouponOffer';
$route['admin/product/saveCoupon'] 			='DashboardProduct/saveCoupon';
$route['admin/product/deleteCoupon/(:any)'] ='DashboardProduct/deleteCoupon/$1';
$route['admin/product/offerList'] 			='DashboardProduct/offerList';
$route['admin/product/createOffer'] 		='DashboardProduct/createProductOffer';
$route['admin/product/saveOffer'] 			='DashboardProduct/saveProductOffer';
$route['admin/product/viewOffer/(:any)'] 	= 'DashboardProduct/viewProductOffer/$1';
$route['admin/product/editOffer/(:any)'] 	= 'DashboardProduct/editProductOffer/$1';
$route['admin/product/UpdateOffer/(:any)']	= 'DashboardProduct/updateProductOffer/$1';
$route['admin/product/deleteOffer/(:any)'] 	= 'DashboardProduct/deleteProductOffer/$1';
$route['admin/send-offer'] 	                = 'DashboardProduct/sendOfferTemplate';
$route['admin/send-offer-to-customer'] 	    = 'DashboardProduct/sendOfferToCustomer';






// Routes for product orders
$route['admin/productOrders'] 				= 'DashboardOrder/index';
$route['admin/invoiceList'] 				= 'DashboardOrder/invoiceList';
$route['admin/prescription-list'] 			= 'DashboardOrder/prescriptionList';
$route['admin/orders/viewOrder/(:any)'] 	= 'DashboardOrder/viewOrder/$1';
$route['admin/orders/viewInvoice/(:any)'] 	= 'DashboardOrder/viewInvoice/$1';
$route['admin/orders/printInvoice/(:any)'] 	= 'DashboardOrder/printInvoice/$1';
$route['admin/orders/printCustomerInvoice/(:any)'] 	= 'DashboardOrder/printCustomerInvoice/$1';
$route['admin/orders/delete/(:any)'] 		= 'DashboardOrder/deleteOrder/$1';

$route['admin/productwise-sales-report'] 	= 'DashboardOrder/productwiseReport';



// Routes for product search keywords & product view
$route['admin/search-keyword-list'] 		= 'DashboardProduct/keywordList';
$route['admin/product-view-list'] 			= 'DashboardProduct/productViewList';
$route['admin/product-restock-list'] 		= 'DashboardProduct/productRestockRequstList';
// Routes for customer
$route['admin/customerList'] 				= 'DashboardCustomer/index';
$route['admin/customer/view/(:any)'] 		= 'DashboardCustomer/viewCustomer/$1';
$route['admin/customer/delete/(:any)'] 		= 'DashboardCustomer/deleteCustomer/$1';

// Routes for customer's query
$route['admin/customerQueryList'] 				= 'Contact/query_list';


// Routes for subscriber
$route['admin/subscriberList'] 				= 'DashboardCustomer/subscriberList';
$route['admin/subscriber/delete/(:any)'] 	= 'DashboardCustomer/deleteSubscriber/$1';

$route['404_override'] = 'pages/notFound';
$route['translate_uri_dashes'] = FALSE;
