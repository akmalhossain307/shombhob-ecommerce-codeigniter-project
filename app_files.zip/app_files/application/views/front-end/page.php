
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
                    
                    
					
                    <!-- Start Left Feature -->
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style" id="hidden4SearchResult">
                  
                        <br /> 

	  <div class="card">
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#faq" aria-controls="home" role="tab" data-toggle="tab"> <span>FAQ</span></a></li>
          <li role="presentation"><a href="#aboutUs" aria-controls="profile" role="tab" data-toggle="tab">  <span>About Us</span></a></li>
          <li role="presentation"><a href="#privacyAndConfidentiality" aria-controls="messages" role="tab" data-toggle="tab">  <span>Privacy and Confidentiality</span></a></li>
          <li role="presentation"><a href="#termsAndConditions" aria-controls="settings" role="tab" data-toggle="tab">  <span>Terms and Conditions</span></a></li>
          <li role="presentation"><a href="#returnAndRefundPolicy" aria-controls="settings" role="tab" data-toggle="tab">  <span>Return And Refund Policy</span></a></li>
          <li role="presentation"><a href="#howToOrder" aria-controls="settings" role="tab" data-toggle="tab">  <span>How to Order</span></a></li>
          <li role="presentation"><a href="#contactUs" aria-controls="settings" role="tab" data-toggle="tab">  <span>Support/Contact Us</span></a></li>
          
        </ul>
        </div>
        <!-- Tab panes -->
        <div class="tab-content">
          
		  <?php 
	  if(isset($_GET['aboutUs']))
	  {
		  echo$_GET['aboutUs'];
	  }
	  ?>
		  
		  
		  <?php 
		  
		  foreach($pageInfo as $page)
		  {
			  if($page->pageTitle=="FAQ")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane active" id="faq">
				  <?php echo$page->pageContent;?>
				  
				  
				  
				  </div>
				  
				  <?php 
			  } 
			  
			  else if($page->pageTitle=="About Us")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="aboutUs">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  } 
			  
			  else if($page->pageTitle=="Terms and Conditions")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="termsAndConditions">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  }
			  
			  else if($page->pageTitle=="Privacy and Confidentiality")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="privacyAndConfidentiality">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  }
			  
			  else if($page->pageTitle=="Return And Refund Policy")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="returnAndRefundPolicy">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  }
			  
			  else if($page->pageTitle=="How to Order")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="howToOrder">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  }
			  
			  else if($page->pageTitle=="Contact Us")
			  {
				  ?>
				  <div role="tabpanel" class="tab-pane" id="contactUs">
				  <?php echo$page->pageContent;?>
				  </div>
				  
				  <?php 
			  }
		  }
		  ?>
          
		  <br/>
		  <br/>
		  <br/>
		  
		  </div>
        
        
        </div>
    
      
	  
	  
	  
	  <!-- Start Footer Area -->
        
            <div class="container-fluid">
                <div class="row">
                    <div class="footer__container clearfix footr">
                         <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4 col-sm-6">
                            <div class="ft__widget">
                                <div class="ft__logo">
                                    <a href="<?php echo base_url();?>">
                                        <img src="<?php echo base_url('assets/front-end')?>/images/logo/Yesbd_Logo_with_Tag_line.png" alt="footer logo">
                                    </a>
                                </div>
                                <div class="footer-address">
                                    <ul>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-pin"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>232-234,Tejgaon Industrial Area, Dhaka-1208, Bangladesh.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-email"></i>
                                            </div>
                                            <div class="address-text">
											<a href="mailto:info@yesbd.com">info@yesbd.com</a>
                                                
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-phone-in-talk"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>09612779900 </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <ul class="social__icon">
								<li><a href="https://www.facebook.com/yesbdpharmacy" target="_blank"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-twitter"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-instagram"></i></a></li>
                                    
                                    <li><a href="#"><i class="zmdi zmdi-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        
                        <div class="col-md-4 col-lg-4 col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Infomation</h2>
						<ul class="footer-categories">
						
							<li><a href="<?php echo base_url('pages');?>">FAQ</a></li>
						
							<li><a href="<?php echo base_url('pages');?>">About Us</a></li>
							<li><a href="<?php echo base_url('pages');?>">Privacy and Confidentiality</a></li>
							<li><a href="<?php echo base_url('pages');?>">Terms and Conditions</a></li>
							<li><a href="<?php echo base_url('pages');?>">Return and Refund Policy</a></li>
							<li><a href="<?php echo base_url('pages');?>">How to Order</a></li>
							<li><a href="<?php echo base_url('pages');?>">Support/Contact Us</a></li>
							<li><a href="<?php echo base_url('sitemap');?>">Sitemap</a></li>
							
							
						</ul>
                            </div>
                        </div>
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4  col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Newsletter</h2>
                                <div class="newsletter__form">
                                    <p>Get all the latest information on Events,
Sales and Offers. Sign up for newsletter today.</p>
                                    <div class="input__box">
                                        <div id="mc_embed_signup">
                                            <form action="<?php echo base_url('search/addSubscribe')?>" method="post">
                                                <div id="mc_embed_signup_scroll" class="htc__news__inner">
                                                    <div class="news__input">
                                                        <input type="email"  name="email" class="email" placeholder="Email Address" required>
                                                    </div>
                                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                                   
                                                    <div class="clearfix subscribe__btn"><input type="submit" title="Send"value="Send" name="subscribe" id="mc-embedded-subscribe" class="bst__btn btn--white__color">
                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>        
                                </div>
                            </div>
							<br />
							<br />
							<img src="<?php echo base_url('assets/front-end/images/SSLCommerz-logo.png')?>" alt="" />
							
                        </div>
                        <!-- End Single Footer Widget -->
                    </div>
                </div>
                <!-- Start Copyright Area -->
                <div class="htc__copyright__area">
                    <div class="row">
                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                            <div class="copyright__inner">
                                <div class="copyright">
                                    <p>© 2019 <a href="https://yesbd.com/">Yesbd.com Ltd.</a>
                                    All Right Reserved.</p>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Copyright Area -->
            </div>


	
	
	  
	  
	  
	  
	  
	  
	  
	  
    </div>
                    <!-- End Left Feature -->
                
            </div>
        </section>
        <!-- End Feature Product -->