			
		<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
                    <!-- Start Left Feature -->
                    <!-- Start Left Feature -->
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style">
						<div id="searchResult"></div> <!--Search result will be listed here-->
					</div>
					
                    <!-- Start Left Feature -->
                  
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style" id="hidden4SearchResult">
                        
						<br /><br /><br /><br /><br />
						
						
						
						
						
						
<div class="panel panel-info">
	<div class="panel-heading">Order Information!</div>
		<div class="panel-body">

	
		<?php if($this->session->userdata('order_placed')){ ?>
		<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<strong>Order placed Successfully!</strong>

		</div>
		<?php }?>

		<h2>Your Order Number is: <span><?php echo $this->session->userdata('odrnmr');?></span></h2>

<i>Dear customer, we will send you a copy of your order details to your given email and also an SMS to your mobile no..</i>

		</div>
</div>
						
						
						
						
						
						
						
						
						
						
						
						
					
                           
                     	<br />
						<br /><br />
						<br />
						
                    </div>
                  
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        
         <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
