<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
                   
					
                    <!-- Start Left Feature -->
                  
                    <div class="col-md-10 col-lg-10 col-sm-10 col-xs-12 float-left-style">
                        
                            <div class="showing_fillter">
                                <div class="row m0">
								
									<div class="form-inline text-left">
									  <div class="form-group">
										<label for="email">FILTER BY CATEGORY </label>
									  </div>
									  &nbsp;&nbsp;
									 <div class="btn-group" role="group">
									 <form action="<?php echo base_url('pages/offerPage');?>" method="POST">
									 <?php 
										foreach($offerCategories as $category)
										{
										$this->load->model('product_model');
										$cnt_offers = $this->product_model->countOfferByCategory($category['mainCategory']);	
											
										$cat=$category['mainCategory'];	
										echo"<button type='submit' name='category'value='$cat'class='btn btn-default'>$cat <span style='color:coral'>($cnt_offers)</span></button>";
										
										}
										?>
									</form>	
									</div>
									  
									  
									</div>
                                    
                                </div>
                            </div>
                            <div class="categories_product_area">
                                <div class="row">
									 <div class="col-lg-4 col-sm-6">
									&nbsp;&nbsp;<h2 style="border-bottom:2px solid black;">Special Offers</h2> 
									</div>
								</div><br />
								<div class="row">
								
								<div id="offerByCategory"></div>
								
								
								
								<?php 
								if(@$offersByCategory)
								{
								foreach($offersByCategory as $offers)
								{
									?>
								
								
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											
											<a href="<?php echo base_url('offerProductDetails/').$offers->offer_id;?>">
											<?php $imgURL=$offers->productImage;?>
                                                <img src="<?php echo base_url().$imgURL?>" alt="<?php echo$offers->title;?>">
											</a>
												<?php 
												$att=$offers->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="new")
												{
													echo"<h5 class='new'>New</h5>";
												}
												else 
												{
												echo"<h5 class='new'>New</h5>";	
												}
												?>
                                              
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
											   
											   
                                                    <li><a title="View" class="btn btn-success btn-lg" href="<?php echo base_url('offerProductDetails/').$offers->offer_id;?>"> Details</a></li>
                                                    <li>
													
													
													
							<form action="<?php echo base_url('product/offer_add_cart');?>" method="POST" enctype="multipart/form-data">	
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>	
										
							<input type="hidden"name="currentURL" value="<?php echo$currentURL;?>"/>
							<input type="hidden"name="offer_id" value="<?php echo$offers->offer_id;?>"/>
							<input type="hidden"name="offer_name" value="<?php echo$offers->title;?>"/>
							<input type="hidden"name="offer_price" value="<?php			
													if($offers->discountPrice)
													{
													$price=$offers->discountPrice;
													}
													else 
													{
													$price=$offers->price;	
													}
										echo$price;?>"/>
							<input type="hidden"name="offer_old_price" value="<?php echo$offers->price;?>"/>
							<input type="hidden"name="quantity" value="1"/>
							<?php $imgURL=$offers->productImage;?>
								
							<input type="hidden"name="offer_image" value="<?php echo base_url().$imgURL;?>"/>
							
							<input class=" btn btn-primary btn-lg add_cart_btn1" type="submit" value="Add To Cart" />
							
							</form>
													
													
													</li>
                                                   
                                                </ul>
                                                <h4><?php echo$offers->title;?></h4>
                                                <h6><span>Price:</span> 
												<?php 
												$price=$offers->price;
												$discount=$offers->discountPrice;
												if($discount){
													echo"<del>TK $price</del>";
												}
													?>
												  TK <?php echo$discount;?></h6>
                                            </div>
                                        </div>
                                    </div>
								<?php 
								} 
								} 
								
								else {
									
									?>
									
									<?php 
								if($offerProducts)
								{
								foreach($offerProducts as $offer)
								{
									?>
								
								
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a href="<?php echo base_url('offerProductDetails/').$offer->offer_id;?>">
											<?php $imgURL=$offer->productImage;?>
                                                <img src="<?php echo base_url().$imgURL?>" alt="<?php echo $offer->title;?>">
												</a>
												
												<?php 
												$att=$offer->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="new")
												{
													echo"<h5 class='new'>New</h5>";
												}
												else 
												{
												echo"<h5 class='new'>New</h5>";	
												}
												?>
                                              
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
                                                    <li><a title="View" class="btn btn-success btn-lg" href="<?php echo base_url('offerProductDetails/').$offer->offer_id;?>">Details</a></li>
                                                    <li>
													
							<form action="<?php echo base_url('product/offer_add_cart');?>" method="POST" enctype="multipart/form-data">	
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>	
										
							<input type="hidden"name="currentURL" value="<?php echo$currentURL;?>"/>
							<input type="hidden"name="offer_id" value="<?php echo$offer->offer_id;?>"/>
							<input type="hidden"name="offer_name" value="<?php echo$offer->title;?>"/>
							<input type="hidden"name="offer_price" value="<?php			
													if($offer->discountPrice)
													{
													$price=$offer->discountPrice;
													}
													else 
													{
													$price=$offer->price;	
													}
										echo$price;?>"/>
							<input type="hidden"name="offer_old_price" value="<?php echo$offer->price;?>"/>
							<input type="hidden"name="quantity" value="1"/>
							<?php $imgURL=$offer->productImage;?>
								
							<input type="hidden"name="offer_image" value="<?php echo base_url().$imgURL;?>"/>
							
							<input class=" btn btn-primary btn-lg add_cart_btn1" type="submit" value="Add To Cart" />
							
							</form>
													
													
													
													</li>
                                                    
                                                </ul>
                                                <h4><?php echo$offer->title;?></h4>
                                                <h6><span>Price:</span> 
												<?php 
												$price=$offer->price;
												$discount=$offer->discountPrice;
												if($discount){
													echo"<del>TK $price</del>";
												}
													?>
												  TK <?php echo$discount;?></h6>
                                            </div>
                                        </div>
                                    </div>
								<?php 
								} 
								} 
								?>
									
									<?php 
									
								}
								?>
								
								
								
								
									
                                    </div>
                              </div>
                     
                       
				
         <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
						
                        
                    </div>
					
					
					
<div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 float-right-style">					
	<div class="categories-menu mrg-xs">				
		<div class="nav-side-menu">
			<div class="category-heading">
                               <h3> Categories</h3>
                            </div>
			<i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <?php 
				$this->load->model('product_model');
				$cnt_offers = $this->product_model->countTotalOffers();
				?>
				
			<a href="<?php echo base_url('offers')?>">
				<li>
                 <span style="color:coral">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Offers (<?php echo$cnt_offers;?>)</span>
                </li></a>
				
				<?php 
				$catCounter=0;
			$this->load->model('product_model');
			$category=$this->product_model->productMainCategory();
			foreach($category as $cat)
			{
				$catCounter++;
			?>
			<?php $imgURL=$cat->category_icon;?>
				

                <li  data-toggle="collapse" data-target="#<?php echo$catCounter;?>" class="collapsed">
                  <a href="#">
				<img alt="category icon" src="<?php echo base_url().$imgURL?>" width="20"height="15"> &nbsp;&nbsp;
				  <?php echo$cat->category_name;?> 
				  
				  <span class="arrow" style="padding:0px;font-size:10px"></span></a>
                </li>
				<ul class="sub-menu collapse" id="<?php echo$catCounter;?>">
				<?php
				$category_id=$cat->category_id;
				$subCategoryByCategory=$this->product_model->productSubCategory($category_id);
				
				if($subCategoryByCategory){
						$counter=0;				
						foreach($subCategoryByCategory as $subCat){
						$counter++;
										
						
						?>
                
                    <li><a href="<?php echo base_url('products/sub-category/').$subCat->subcat_id;?>"><?php echo$subCat->subCategoryName;?></a></li>
                    
               
				
				<?php 
				}
				}
				echo"</ul>";
			
				}
						
				?>
				
				
            </ul>
     </div>
</div>
</div>
	
						
 </div>
 <!-- End Left Feature -->
					
					
					
					
					
					
					
                </div>
            </div>
        </section>
        <!-- End Feature Product -->