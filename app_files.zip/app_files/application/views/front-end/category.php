<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
                    <!-- Start Left Feature -->
					<div class="col-md-9 col-lg-9 col-sm-8 col-xs-12 float-left-style">
						<div id="searchResult"></div> <!--Search result will be listed here-->
					</div>
					
					
					
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12 float-left-style" id="hidden4SearchResult">
                        
						
                            <div class="showing_fillter">
                                <div class="row m0">
								
									<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>">Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										
										<li><a href="<?php echo$currentURL;?>">Category</a></li>       
										<li class="active"><?php echo$category_name;?></li>        
									</ol>
								
									<div class="form-inline text-right">
									  <div class="form-group">
										<label for="email">SORT BY: </label>
									  </div>
									  <div class="form-group">
										<select class="form-control">	
											<option>Price</option>
											<option>Low to High</option>
											<option>High to Low</option>
										</select>
									  </div>
									  <div class="form-group">
										<select class="form-control">
											<option>Sort By</option>
											<option>Newest</option>
											<option>Oldest</option>
											<option>A-Z</option>
											<option>Z-A</option>
										</select>
									  </div>
									</div>
                                    
                                </div>
                            </div>
                            <div class="categories_product_area">
                                <div class="row">
								
								<?php if($categoryProduct){
									foreach($categoryProduct as $product){
								?>
								
								
                                    <div class="col-lg-4 col-sm-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a title="Click to View Details" class="view_detail quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"> <img src="<?php echo base_url().$product->productImage;?>" alt=""> </a>
                                                
                                                <h5 class="new">New</h5>
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
											   <!--
											   <li> <a href=""class="viewTest" id="test">Test</a></li>
											   -->
											  
                                                    <li class="p_icon"><a title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"><span class="ti-plus"></span></a></li>
                                                    
													<li>
												
													<button class="add_cart_btn" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productoldprice="<?php echo $product->price;?>"data-productimage="<?php echo base_url().$product->productImage;?>" data-productprice="<?php
																
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
													
													</li>
													
                                                    <li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
												<p><?php echo$product->measuringType;?></p>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									<?php 
									}
									}
									else 
									{
										echo"No product found in this category...";
									}
									?>
									
                                </div>
                               
                            </div>
                     
                       
						
						
                        
                    </div>
                   <!--Load the sidebar categories-->
					<?php $this->load->view('front-end/sidebar');?><!-- End Left Feature --><!-- End Left Feature -->
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        
        
       
        
        
         <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
        
         

