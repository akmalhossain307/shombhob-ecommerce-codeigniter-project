<div class="container-fluid">
                <div class="row">
                    <div class="footer__container clearfix footr">
                         <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4 col-sm-6">
                            <div class="ft__widget">
                                <div class="ft__logo">
                                    <a href="<?php echo base_url();?>">
                                        <img src="<?php echo base_url();?>assets/front-end/images/logo/logo-for-website-190by78v2.png" alt="footer logo">
                                    </a>
                                    
                                   
                                </div>
                                <div class="footer-address">
                                    <ul>
                                        <li>
                                             <!--
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-pin"></i>
                                            </div>
                                            <div class="address-text">
                                               
                                                <p>232-234,Tejgaon Industrial Area, Dhaka-1208, Bangladesh.</p>
                                              
                                            </div>  -->
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-email"></i>
                                            </div>
                                            <div class="address-text">
											<a class="helpline" href="mailto:info@shombhob.com">info@shombhob.com</a>
                                                
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-phone-in-talk"></i>
                                            </div>
                                            <div class="address-text ">
                                                <p class="helpline">+8801755697233 </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <ul class="social__icon">
									<li><a href="https://www.facebook.com/shombhob2021" target="_blank" title="Facebook page"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <!--<li><a href="#"><i class="zmdi zmdi-twitter"></i></a></li>-->
                                    <li><a href="https://www.instagram.com/shombhob2021/" target="_blank" title="Instagram"><i class="zmdi zmdi-instagram"></i></a></li>
                                    
                                   
                                </ul>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        
                        <div class="col-md-4 col-lg-4 col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Information</h2>
						<ul class="footer-categories">
						
							<li><a href="<?php echo base_url('page/faq');?>">FAQ</a></li>
						
							<li><a href="<?php echo base_url('page/about-us');?>">About Us</a></li>
							<li><a href="<?php echo base_url('page/privacy-confidentiality');?>" >Privacy and Confidentiality</a></li>
							<li><a href="<?php echo base_url('page/terms-conditions');?>">Terms and Conditions</a></li>
							<li><a href="<?php echo base_url('page/return-refund-policy');?>">Return and Refund Policy</a></li>
							<li><a href="<?php echo base_url('page/how-to-order');?>">How to Order</a></li>
							<li><a href="<?php echo base_url('page/contact');?>">Support/Contact Us</a></li>
							<li><a href="<?php echo base_url('page/sitemap');?>">Sitemap</a></li>
							
							
						</ul>
                            </div>
                        </div>
                        
                        
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4  col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Newsletter</h2>
                                <div class="newsletter__form">
                                    <p>Get all the latest information on Events,
Sales and Offers. Sign up for newsletter today.</p>
                                    <div class="input__box">
                                        <div id="mc_embed_signup">
                                            <form action="<?php echo base_url('search/addSubscribe')?>" method="post">
                                                <div id="mc_embed_signup_scroll" class="htc__news__inner">
                                                    <div class="news__input">
                                                        <input type="email"  name="email" class="email" placeholder="Email Address" required>
                                                    </div>
                                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                                   
                                                    <div class="clearfix subscribe__btn"><input type="submit" title="Send"value="Send" name="subscribe" id="mc-embedded-subscribe" class="bst__btn btn--white__color">
                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>        
                                </div>
                            </div>
							<br />
						
							<img src="<?php echo base_url('assets/front-end/images/SSLCommerz-logo.png')?>" alt="ssl_images" width="100%"height="80px"/>
							
							<br/>	<br/>
							<span style="text-align:center;">
                             
                                    © <?php echo date('Y');?> <a href="https://shombhob.com/">Shombhob.com Ltd.</a>
                                    All Right Reserved.
                             </span>
							
                        </div>
                        <!-- End Single Footer Widget -->
                       
                    </div>
                </div>
                
                
            </div>