<?php
header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!--
    <meta name="google-site-verification" content="sduVv7zrES8JKi8pcIGtIZZlVtAiCp1kKmi4bF19Lik" />
    -->
    
    <meta name="google-site-verification" content="hn33bj22M4pVYDuA_0xWe4MEtZWkumeO0--yyNb5YXM" />
    
    <title><?php //echo$title;?> Shombhob.com || Your online health shop</title>
  <meta name="description" content="Shombhob.com is a pioneer online medicine and healthcare shop. All pharmacy medicines and helthcare items are available in this website.">
  <meta name="keywords" content="Online Pharmacy,Online pharmacy in Bangladesh,Online pharmacy in BD,pharmacy online,online medicine,online medicine service bd,online medicine Bangladesh,Online medicine delivery,Medicine delivery bd,shombhob,Epharmacy,E pharmacy,E-pharmacy,medicine home delivery dhaka ,buy medicine online dhaka,online healthcare products,meds online,pharmacy,medicine delivery,online pharmaceutical,personal product,baby care products,skin care product,herbal medicine bd,ousud,oshud,osud,medicine,Bangladesh online medical pharmacy">

    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!--Google font-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@300;400;700&display=swap" rel="stylesheet">
    
    <!-- Place favicon.ico in the root directory -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/front-end')?>/images/favicon.ico">
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
  
    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/bootstrap.min.css">
    <!-- Owl Carousel main css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/owl.theme.default.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/responsive.css">
    <!-- User style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/custom.css">
	
	<!-- Icon css link -->
	
	<!--
	<link href="<?php //echo base_url('assets/front-end')?>/css/font-awesome.min.css" rel="stylesheet">
	-->
	
	<link href="<?php echo base_url('assets/front-end')?>/vendors/line-icon/css/simple-line-icons.css" rel="stylesheet">
	<link href="<?php echo base_url('assets/front-end')?>/vendors/elegant-icon/style.css" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo base_url('assets/front-end/social/jssocials.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/front-end/social/jssocials-theme-flat.css'); ?>">

	<!-- category style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/style.css">

   <!-- style for jQuery UI-->
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="https://jquery.com/resources/demos/style.css">
  
  <!--Header style codes-->
  <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/short-header.css">


 
	
<!-- Include jQuery library -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!--Toastr Notifications-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet" />


	<!--side slider-->
	<link rel="stylesheet" href="https://www.jqueryscript.net/css/jquerysctipttop.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 
 <link rel="stylesheet" href="<?php echo base_url('assets/front-end')?>/css/BootSideMenu.css">





<script type="text/javascript"> 
// for modal popup display after page load
$(window).load(function()
{
    $('#cartModal').modal('show');
});
</script>
	
<script>
/* Update cart item quantity */
function updateCartItem(obj, rowid){
	$.get("<?php echo base_url('product/updateItemQty/'); ?>", {rowid:rowid, qty:obj.value}, function(resp){
		if(resp == 'ok'){
			
			location.reload();
			//alert('Cart updated...');
			
		}else{
			alert('Cart update failed, please try again.');
			location.reload();
		}
	});
}
</script>	



<!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v10.0'
          });
        };

        (function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      </script>

      <!-- Your Chat Plugin code -->
      <div class="fb-customerchat"
        attribution="page_inbox"
        page_id="350040622736413">
      </div>












	
      
      
      <style>
      
  .helpline{font-family: 'Lato', sans-serif !important;font-size:17px;}
 .sidebarCategory{font-family: 'Merriweather', sans-serif !important;} 
      .carousel-indicators{display:none!important;}
      
          
         #loginHdr{background:#C6DBDA;height:60px;} 
         
         
 .loader {
    border: 16px solid #f3f3f3; /* Light grey */
    border-top: 16px solid #3498db; /* Blue */
    border-radius: 50%;
    width: 120px;
    height: 120px;
    animation: spin 2s linear infinite;
 }

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.hide-loader{
display:none;
}
        
         
       body{
           font-family: 'Playfair Display', sans-serif !important;
       }  
         
         
         
         
         
          
      </style>
     
	
</head>

<body onclick="document.getElementById( 
             'suggestions').style.display='none';">
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]--> 

<!--
 <div class="loader text-center" id="loader">
     </div>
        
-->

<div class="container-fluid top-text" style="height:5px"> 		
<marquee onmouseover="this.stop();" onmouseout="this.start();" height="25px" direction="left">
    <span style="color:coral;font-size:14px">
প্রিয় গ্রাহক, আপনাদের সেবায় আমরা প্রয়োজনীয় ঔষধ ও স্বাস্থ্যসুরক্ষা সামগ্রী  সমগ্র ঢাকা সিটির ভিতরে ২-৪ ঘণ্টায় ডেলিভারি দিয়ে থাকি ।  আপনার প্রয়োজনীয় ঔষধ/ পণ্যটি এখনই অর্ডার করে রাখুন ।  আমাদের সাথে যোগাযোগ করুন +৮৮০১৭৫৫৬৯৭২৩৩ ই নাম্বার এ ।  করোনা প্রতিরোধে সামাজিক দূরত্ব বজায় রাখুন, সুস্থ থাকুন । 
	
</span>		
</marquee>	
		
</div>

	


<!--Test -->
<div id="test" > 





<div class="panel panel-default">
    <div class="panel-heading"><img src="<?php echo base_url('uploads/shopping-bag-flat.png')?>" width="30px" height="35px"/> &nbsp;&nbsp;Shopping Cart</div>
   
   
   <a href="#" class="closeBtn toggler" data-whois="toggler"><span aria-hidden="true">Close</span></a>
                                
  
  
   
   
    <?php 
    $this->load->helper('url');
	$currentURL = current_url();
	
	
    
    if($this->cart->total_items() > 0){
        
      //  for($i=0;$i)
      //echo$this->cart->total_items()
      $no = 1;
      $cartContents = $this->cart->contents();
       foreach ($cartContents as $items){
     $countItem=$no++;
  }
  
        
        ?>
   
   
   <script> 
   
  document.getElementById('productCounter').innerHTML="<?php echo$countItem;?>";
  //location.reload();
 // window.location='<?php echo "$currentURL";?>';
  //exit();
   
   </script>
  <?php 
  
    }
   ?>
   
   
   
   
   
   <div class="list-group">
   
       
       
   
					
					
					
					 <table class="table table-striped table-responsive">
						
						
						<tbody id="detail_cart">
						
						
					
							
						</tbody>
					  </table>
                        
                  
					 <a href="<?php echo base_url();?>" class="toggler btn btn-success btn-sm" data-whois="toggler" style="margin-top: 200px;padding: 12px;color:white;background:blue;width: 132px;height: auto;margin-left:0px;position:fixed">Continue Shopping</a>
				
					 
					 
                                    
					<div class="text-center">
					    
					    
					    
					    
					    
					
					<?php if($this->session->userdata('custmrLogin')){
									
									?>
									
								
									
						<form action="<?php echo base_url('coupon/applyCoupon');?>" method="POST">	
						<b>Apply Coupon</b> <br />
						<p>Enter your coupon code if you have one.</p>
						<input type="text" name="coupon_code"class="form-control"placeholder="Coupon code"required > <br />
						
						<?php 
									$this->load->helper('url');
									$currentURL = current_url();
									//print_r($currentURL);
									//$totalCartAmount=number_format($this->cart->total());
								?>
								<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
								<input type="hidden" name="totalcrt_amnt" value="<?php //echo$totalCartAmount;?>"/>
						
				
					  
				<?php  if($this->session->flashdata('expired')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('expired'); ?> </span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					
				<?php  } else if($this->session->flashdata('applied')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
					<?php echo $this->session->flashdata('applied'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					<?php  } else if($this->session->flashdata('used')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('used'); ?></span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					
				<?php } else if($this->session->flashdata('wrong')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('wrong'); ?></span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
					
					
						        <?php 
								
								$totalCartAmount=$this->cart->total();
								if($totalCartAmount<200)
								{
								    echo"<small class='text-muted'>Order minimum BDT 200 to apply coupon code.</small><br/>";
								   	echo"<a href='#' class='btn btn-primary btn-sm' style='color:white' disabled> Apply Coupon</a>";
								}
								else 
								{
							?>
						<input type="submit" class="btn btn-primary btn-sm"value="Apply Coupon" style="color:white">
    						<?php 
    							}
    						?>
						
						<br /> 
						
						<a href="<?php echo base_url('checkout');?>" class="btn btn-danger toggler" data-whois="toggler" style="margin-top: 170px;padding: 12px;color:white;background:red;width: 128px;height: auto;margin-left: 40px;position:fixed">Finish Shopping</a>
						
						
					</form>
								<?php 
								
								}
								else 
								{
									?>
						<form action="<?php echo base_url('checkout/applyCoupon');?>" method="POST">	
						<b>Apply Coupon</b> <br />
						<p>Enter your coupon code if you have one.</p>
						<input type="text" name="coupon_code"class="form-control"placeholder="Coupon code"required > <br />
						
						 <?php 
								
							$totalCartAmount=$this->cart->total();
								if($totalCartAmount<200)
								{
								    //echo"";
								    
								   	echo"<a href='#' class='btn btn-primary btn-sm' style='color:white' disabled> Apply Coupon</a>";
					 
								}
								else 
								{
							?>
							<a href="" class="btn btn-primary btn-sm" data-target="#myLoginRegisterModal" data-toggle="modal" style="color:white"> Apply Coupon</a>
					
    						<?php 
    							}
    						?>
						
						
						
						<br /> 
						<br /> 
						<br /> 
						
						
						<a href="<?php echo base_url('checkout');?>" class="btn btn-danger toggler" data-whois="toggler" style="margin-top: 200px;padding: 12px;color:white;background:red;width: 128px;height: auto;margin-left: 40px;position:fixed">Finish Shopping</a>
						
					</form>
								
									
									<?php 
									
									
								}	
								
								?>
					
						<br/>
					 <br/>
					 <br/>
				
					 
					
					 
					 
					 
					 
					 
					 
			   
						
						<br />
						<br />
						
                    
                   </div>
   
   
   
       
		</div>
</div>

 </div>
<!--/Test -->











	
<!-- Large modal -->
	<div class="modal fade" id="myLoginRegisterModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" id="loginHdr">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×</button>
                <h2 class="modal-title" id="myModalLabel" style="font-size:17px">
                   <span class="ti-user" ></span>  Customer - Login/Registration</h2>
            </div>
            <div class="modal-body" style="background:#ddd">
                <div class="row">
				
				
				
				
                    <div class="col-md-8" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs loginReg">
                            <li ><a href="#Login" data-toggle="tab"><b>Login</b></a></li>
                            <li class="active"><a href="#Registration" data-toggle="tab"><b>Registration</b></a></li>
                        </ul>
						<br/>
                        <!-- Tab panes -->
                        <div class="tab-content">
						
                            <div class="tab-pane active" id="Registration"><!--Registration tab start-->
					
							
							
                                <form method="POST" action="<?php echo base_url('customer/registration')?>"role="form" class="form-horizontal" id="register">
                                
                                <div class="form-group">
								
                                    <label for="email" class="col-sm-2 control-label">
                                        <span style="color:coral">*</span> Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="Name" placeholder="Name" name="name" required />
                                    </div>

                                </div>
								<div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        <span style="color:coral">*</span> Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" id="Email" name="email" value="<?php echo set_value('email'); ?>"placeholder="Email" required />
									<span class="text-danger">
									<?php 
									if($this->session->flashdata('emailExist')){ 
									echo $this->session->flashdata('emailExist');
									
									}
									?>
									</span>
									</div>
                                </div>
                                <div class="form-group">
                                    <label for="mobile" class="col-sm-2 control-label">
                                        <span style="color:coral">*</span> Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="Mobile" placeholder="Mobile" name="mobile" required />
                                    
										<span class="text-danger">
										<?php 
										if($this->session->flashdata('mobileNumberExist')){ 
										echo $this->session->flashdata('mobileNumberExist');
										
										}
										?>
										</span>
									</div>
									
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-sm-2 control-label">
                                       <span style="color:coral">*</span>Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" id="password" placeholder="Password" name="password"/>
										<span id="result"></span>
                                    </div>				
							
                                </div>
								<?php 
									$this->load->helper('url');
									$currentURL = current_url();
									//print_r($currentURL);

								?>
								<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
								
								
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <center>
                                        <button type="submit" name="submit"class="btn btn-primary btn-sm">
                                            Submit</button>
                                        <button type="reset" class="btn btn-default btn-sm">
                                            Reset</button>
                                        </center>    
                                    </div>
                                </div>
                                </form>
                            </div><!--Registration tab close-->
							
							<div class="tab-pane" id="Login"> <!--Login tab start-->
					
                                <form action="<?php echo base_url('customer/login')?>" method="POST"role="form" class="form-horizontal">
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email<span style="color:coral">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="email1" name="username"placeholder="Email or Phone no" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="col-sm-2 control-label">
                                    Password<span style="color:coral">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="password" name="password"class="form-control" id="pwd" placeholder="password" required />
                                        
                                        
                                        <input type="checkbox"id="showPass" /> Show Password 
		
                                        
<script type="text/javascript"> 
		
function show() {

var p = document.getElementById('pwd');
			
p.setAttribute('type', 'text');
		
}

		
function hide() {
			
var p = document.getElementById('pwd');
			
p.setAttribute('type', 'password');
		
}

		
var pwShown = 0;

		
document.getElementById("showPass").addEventListener("click", function () 
{
			
if (pwShown == 0) 
{
				
pwShown = 1;
				
show();
			
} 
else {
				
pwShown = 0;
				
hide();
			
}
		
}, false);
		

</script>
                                        
                                    </div>
                                </div>
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);

								?>
								<input type="hidden" name="currentURL1" value="<?php echo$currentURL1;?>"/>
								
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Login</button>
                                        
										
										<a href="<?php echo base_url('customer/forgotPassword');?>" >Forgot your password?</a>
										
										<!--
										<a href="#passRecoveryModal" data-toggle="modal">Forgot your password?</a>
										
										-->
										
										
                                    </div>
                                </div>
                                </form>
                            </div><!--Login tab close-->
							
							
							
                        </div>
                        <div id="OR" class="hidden-xs">
                            OR</div>
                    </div>
					
					<div class="col-md-4">
					    
					    <br/> <br/>   <br/>
                            <h3>
							<address>Call Us: <a href="#"><i class="zmdi zmdi-phone-in-talk"></i> +8801755697233</a></address>
							</h3>
                    
					       <br/>    
					    
					 <!--   
					    
					 <div class="fbLogin"> 
					 <a href="<?php //echo @$authURL; ?>"><img src="<?php //echo base_url('assets/fconnect.png');?>" alt="fblogin" width="350px"/></a>
					
					</div>
					
					-->
					
					
					<br />
					
					<!--
					<div class="gLogin"> 
					<a href="#">
					<img src="<?php //echo base_url('assets/gconnect.png');?>" alt="googlelogin" width="350px"/>
					</a>
					</div>
					    
					  -->  
					    
					    
					    
					    
					    
                       
                    </div>
					
					
					
					<!--
                    <div class="col-md-4">
                        <div class="row text-center sign-with">
                            <div class="col-md-12">
                                <h3>
                                    Sign in with</h3>
                            </div>
                            <div class="col-md-12">
                                <div class="btn-group btn-group-justified">
                                    <a href="#" class="btn btn-primary">Facebook</a> <a href="#" class="btn btn-danger">
                                        Google</a>
                                </div>
                            </div>
                        </div>
                    </div>
					-->
					
                </div>
            </div>
        </div>
    </div>
</div>



<div class="container">

<!-- Button to trigger modal --> 
  <!-- Modal -->
  <div class="modal fade" id="prescriptionUploadModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content"style="background:#ddd">
        <div class="modal-header" id="loginHdr">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
          <h2 class="modal-title" style="color:fuchsia;text-align:center;font-size:17px">  <span class="fa fa-cloud-upload">  </span> <!--<span class="fa fa-user-md"></span>--> Upload Your Prescription</h2> 
      
        </div>
        <div class="modal-body">
            
            <center> 
        
        <span style="color:red">Dear customer! please upload your prescription to buy prescribed medicine.</span>
        
         <br/> OR <i>Call Us: +8801755697233</i> </center>
          
			<form action="<?php echo base_url('uploadPrescription')?>" method="POST" enctype="multipart/form-data">
				  <div class="form-group">
					<label for="exampleFormControlInput1"><span style="color:coral">*</span> Name</label>
					<input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="enter your name" required="">
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1"><span style="color:coral">*</span> Contact Number</label>
					<input type="text" name="phone" class="form-control" id="exampleFormControlInput1" placeholder="enter your contact number" required="">
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1">Email(Optional)</label>
					<input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="enter email">
				  </div>
				  
				  
				  <div class="form-group">
				      <!--
						  <div class="text-right"> 
								<img id="img" src="<?php //echo base_url('assets/uploads/preview.png')?>" alt="Prescription image" />
							</div>
							-->
							
							<label for="exampleFormControlSelect2"><strong><span style="color:coral">*</span> Prescription</strong></label>
							<input type='file' name="prescriptionImage"class="form-control"onchange="readURL(this);" required />
							
							
							
						  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Query(If any)</label>
					<textarea class="form-control" name="query" id="exampleFormControlTextarea1" rows="3"> </textarea>
				  </div>
				  
				
		  
		  
        </div>
        <div class="modal-footer">
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);

								?>
		  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
		  
		  
		  <center>
		  
		  <input type="reset" class="btn btn-warning" value="Reset">
		  <input type="submit" class="btn btn-success" value="Submit">
		  <br/>	  <br/>  <br/>	  <br/>
		   </center>
		
		  
        </div>
		</form>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
</div>

<div class="container">

<!-- Button to trigger modal --> 
  <!-- Modal -->
  <div class="modal fade" id="passRecoveryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
          <h2 class="modal-title" style="color:fuchsia">Recover Your Password</h2>
        </div>
        <div class="modal-body">
          
		  
		  <?php 
				if($this->session->flashdata('mobileOrEmailNotExit')){ ?>
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('mobileOrEmailNotExit'); ?></strong>
				</div>
				<?php };?>
				
		  
			<form action="<?php echo base_url('customer/checkEmailOrPhone')?>" method="POST">
				  <div class="form-group">
					<label for="exampleFormControlInput1">Email or Phone</label>
					<input type="text" name="username" class="form-control" id="exampleFormControlInput1" placeholder="enter your email or phone no." required="">
				  </div>
				
        </div>
        <div class="modal-footer">
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);

								?>
		  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
		  <input type="reset" class="btn btn-warning" value="Clear">
		  <input type="submit" class="btn btn-success" value="Submit">
        </div>
		</form>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
</div>



 <!-- Modal for Tracking order -->
  <div class="modal fade" id="trackMyOrder" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content" style="background:#ddd">
        <div class="modal-header" id="loginHdr">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
          <h2 class="modal-title" style="color:fuchsia;font-size:17px"> <span class="fa fa-eye"></span> Track Your Order</h2>
        </div>
        <div class="modal-body">
          
		  
				<?php 
				if($this->session->flashdata('orderNoNotExit')){ ?>
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('orderNoNotExit'); ?></strong>
				</div>
				<?php };?>
				
		  
			<form action="<?php echo base_url('customer/trackOrder')?>" method="POST">
				  <div class="form-group">
					<label for="exampleFormControlInput1">Order No.</label>
					<input type="text" name="order_no" class="form-control" id="exampleFormControlInput1" placeholder="enter order no." required="">
				  </div>
				
        </div>
        <div class="modal-footer">
			<center>			
		  <input type="reset" class="btn btn-warning" value="Clear">
		  <input type="submit" class="btn btn-success" value="Submit">
		  
		  </center>
		  
        </div>
		</form>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
  









	
	
			
	
	<div class="row"> 
				<div class="container-fluid top_section">
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
						<div class="well top_menu">
							<div class="col-md-6 helpline"> Helpline: <i class="zmdi zmdi-phone-in-talk"></i> <a href="#"><b> +8801755697233</b></a>
							&nbsp;&nbsp;&nbsp; <i class="zmdi zmdi-email"> </i> <a href="mailto:info@shombhob.com"><b>info@shombhob.com</b></a>	
							</div>
							
							<div class="col-md-6 top_menu_item">
							<span class="blink">
							
							<a href="#prescriptionUploadModal" data-toggle="modal" style="color:red"> <span class="fa fa-cloud-upload"></span> UPLOAD PRESCRIPTION</a>
							</span>
									&nbsp;&nbsp;&nbsp;
							<a href="" data-target="#trackMyOrder" data-toggle="modal" title="track order!"> <i class="fa fa-shopping-cart" style="color:coral"></i> Track my Order</a>	
								
								&nbsp;&nbsp;&nbsp;
								<a href="<?php echo base_url('checkout');?>"> <i class="fa fa-sign-out" style="color:green"></i>Checkout</a>
								<?php if($this->session->userdata('custmrLogin')){
									
									$cus=$this->session->userdata('customr_name');
									if(empty($cus))
									{
										$cus=@$userData['first_name'].' '.@$userData['last_name'];
									}
									
									?>
									
									<!--
									<a href="<?php //echo base_url('customer/dashboard');?>">Dashboard</a>
									-->
									
		<a href="#"> <?php //echo$this->session->userdata('active_customer');?></a>
							
		
		
		         
	
		         
		         
		         
		         
		         
		         
		         
                        		       
                       
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="fa fa-id-badge" style="color:coral"></span> My Account
                    <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li> <a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard" style="color:magenta"></span> Dashboard</a></li>
                      
                      <li> <a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card" style="color:magenta"></span> Profile</a></li>
                      
                      <li> <a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket" style="color:magenta"></span> Wishlist</a></li>
                      
                      <li> <a href="<?php echo base_url('customer/orderHistory');?>"> <span class="fa fa-history" style="color:magenta"></span> Order History</a></li>
                     
                      <li> <a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out" style="color:magenta"></span> Logout</a></li>
                      
                    </ul>
                                       
                                
                             
                                 
                                   
                                     
                              
		
		
		
		
									
						
								
								
								<a href="<?php //echo base_url('customer/logout');?>"></a>
							
									<a href="<?php echo base_url('fb-logout');?>">  <span class="fa fa-mail-reply" style="color:coral"></span> Logout</a>
								
								<?php 
								}
								else 
								{
									?>
									<!--
									<a href="" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login or Create Account!"> Login</a>
									-->
										&nbsp;&nbsp;&nbsp;
									<a href="" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login!"><span class="ti-user" style="color:#84E847"></span> Login or Signup</a>
									
									<?php 
									
									
								}	
								?>
								
							
								
							</div>
						
						</div>
						
					</div>	
					
				</div>	
				
				
			</div>	
	
	
	

    <!-- Body main wrapper start -->
    <div class="wrapper fixed__footer">
        <!-- Start Header Style -->
        <header id="header" class="htc-header header--3 bg__white">
		
		
            <!-- Start Mainmenu Area -->
            <div id="sticky-header-with-topbar" class="mainmenu__area sticky__header">
                <div class="container-fluid" >
				<div style="margin-bottom:-40px;margin-top:10px">
			<!--
				<center>
				 <span id="tag">
			
				Your Online Health Shop
				</span> 
				</center>
				-->
				</div>
			
				
				
				
				
				
                    <div class="row">
					
					
					
					
                       <div class="col-md-3 col-lg-3 col-sm-6 col-xs-6">
						
					
                            <div class="logo" style="width:149px;height: 85px!important;margin-top: -45px;margin-left: 30px;">
						
    
                              <a href="<?php echo base_url();?>">
 
                                   <!-- <img class="" src="<?php //echo base_url();?>assets/front-end/images/logo/change2.png" alt="logo" height="78" width="190"/>
                                       
                                    -->
                                    <img class="" src="<?php echo base_url();?>assets/front-end/images/logo/logo-for-website-190by78v2.png" alt="logo" height="78" width="190"/>
                                    
                             </a>
								
                            </div>
                        
							
                        </div>
						
						
                        <!-- Start Mainmenu Area -->
                        <div class="col-md-9 col-lg-9 col-sm-6 col-xs-6">
                            <nav class="mainmenu__nav">
                                <ul class="main__menu">
                                    <div class="col-md-12">
                                    
									&nbsp;&nbsp;&nbsp;


									
<div class="hidden-sm hidden-xs">
					
									
<div class="something">

<form action="<?php echo base_url('search/productSearch');?>" method="GET">
     <input style="width:100%;margin-left:13px"name="search_data" id="search_data" type="text" class="form-control"onkeyup="ajaxSearch();" placeholder="Search product here..."  autocomplete="off"> 
	 <div class="text-right"> 
	 
	 <input type="submit" style="margin-top: -61px;padding:7px;margin-right: -55px;" class="btn btn-primary btn-sm " value="Search">
			
	</div>
</form>	 
		
     <div id="suggestions">
         <div id="autoSuggestionsList"></div>
     </div>
	 
</div>



	

				</div>
						</div>
                                    
     
                               
                                 </ul><!-- End Single Mega MEnu -->
                                    
                                
                            </nav>
                                                     
                        </div>
                        <!-- End Mainmenu Area -->
                        <div class="col-md-2 col-sm-4 col-xs-3">  
                            <ul class="menu-extra">
                                
                              
                            </ul>
                        </div>
                    </div>
					
					
					<!--Mobile menu start-->
					
					 
					
					
					<!--Mobile menu close-->
					
					
					
					<!--Mobile menu will go here...-->
					<div class="mobile-menu-area">
									
									<div class="hidden-lg hidden-md">
									<br /> 
									


	



			
	<nav role="navigation" class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle" style="margin-top:11px">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="<?php echo base_url();?>" class="navbar-brand">   
            
            <img src="<?php echo base_url();?>/assets/front-end/images/logo/100n100.png" alt="logo" width="80" height="25"/> 
            </a>
            
            
            
            
            
    <div class="something1">
        
        

     
	 <div class="text-center">
	     
	<input style="width: 44%;margin-left:0px;margin-top: 11px;" name="search_data1" id="search_data1" type="text" class="form-control"onkeyup="ajaxSearch1();" placeholder="Search here..." autocomplete="off">
	    
	 <input type="submit" style="margin-top: -61px;padding: 7px;margin-right: -127px;" class="btn btn-primary btn-sm " value="Search">
	</div>		

		 
	 
     <div id="suggestions1">
         <div id="autoSuggestionsList1"></div>
     </div>
	 
</div>
            
            
            
            
            
			
			
			
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse" data-toggle="collapse" data-target="#navbarCollapse">
            
            
                        
            				

		            	<div class="category-heading">
                               <h3> Categories</h3>
                            </div>
		

  
            <ul id="mobile-menu-content" class="nav navbar-nav">
                <?php 
				$this->load->model('product_model');
				$cnt_offers = $this->product_model->countTotalOffers();
				?>
				
				<li>
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url('offers')?>"> Offers <span style="color:coral"> (<?php echo$cnt_offers;?>)</span></a>
                </li>
				
				<?php 
				$catCounter=0;
			$this->load->model('product_model');
			$category=$this->product_model->productMainCategory();
			foreach($category as $cat)
			{
				$catCounter++;
			?>
			<?php $imgURL=$cat->category_icon;?>
				

                <li  data-target="#<?php echo$catCounter;?>" class="">
                  <a href="<?php echo base_url('products/category/').$cat->category_id;?>">
				<img alt="category icon" src="<?php echo base_url().$imgURL?>" width="20"height="15"> &nbsp;&nbsp;
				  <?php echo$cat->category_name;?> 
				  
				            </a>
                </li>
				
			<?php 
				}
						
				?>
				
				
            </ul>
    


	
						
					 </div>
					
		
                        
                                 
           
            
            
            
            
        </div>
    </div>
</nav>
	
	
			
									
									  
									  
									  
		  
									  
									  
		

	
									  
									   <br />
									  </div>
									  
									  


			
									  
									  
									  
									  
					</div>
					
					
                    
                </div>
           
            </div>
            <!-- End Mainmenu Area -->
        </header>
        <!-- End Header Style -->
        
        <div class="body__overlay"></div>
        <!-- Start Offset Wrapper -->
       
            <?php 
			$this->load->helper('url');
			$crntURL =current_url();
			//$crntURL1 =echo($crntURL);
			$bsURL=base_url();
			//$bsURL1=echo$bsURL;
			//if(isset($_POST['carButton']))
			
			
			?>
			 <!-- Start Cart Panel shopping__cart__on -->
	   
			<div class="shopping__cart <?php if(isset($_POST['carButton'])){echo"";}else if($this->cart->total_items()<1){echo"";} else{echo"";}?>">
			
                <div class="shopping__cart__inner">
				
					<img src="<?php echo base_url('assets/uploads/shopping_bag.png')?>" alt="shopping bag"style="margin-top:-150px" width="80" height="50"/> 
                    <form action="" method="POST" >
					<div class="offsetmenu__close__btn">
					<input type="hidden" name="carButton" />
                        <a href="#"> <i class="zmdi zmdi-close"></i></a>
                    </div></form>
					
                    <div class="shp__cart__wrap">
					
					<h2>Shopping Cart</h2>
					
					 <table class="table table-bordered">
						<thead>
						  <tr>
							<th>Item</th>
							<th>Image</th>
							<th>Price</th>
							<th>Qty</th>
							<th>Sub Total</th>
							<th>Remove</th>
						  </tr>
						</thead>
						
						<tbody id="detail_cart">
						
						
					
							
						</tbody>
					  </table>
                        
                    </div>
					 <a href="<?php echo base_url();?>" class="btn btn-success btn-sm">Continue Shopping</a>
					 
                                    
					<div class="text-center">
					
					<?php if($this->session->userdata('custmrLogin')){
									
									?>
									
									<form action="<?php echo base_url('coupon/applyCoupon');?>" method="POST">	
						<h2>Apply Coupon</h2> <br />
						<p>Enter your coupon code if you have one.</p>
						<input type="text" name="coupon_code"class="form-control"placeholder="Coupon code"required > <br />
						
						
						<?php 
									$this->load->helper('url');
									$currentURL = current_url();
									//print_r($currentURL);
									//$totalCartAmount=number_format($this->cart->total());
								?>
								<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
								<input type="hidden" name="totalcrt_amnt" value="<?php //echo$totalCartAmount;?>"/>
						
				
					  
				<?php  if($this->session->flashdata('expired')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('expired'); ?> </span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					
				<?php  } else if($this->session->flashdata('applied')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
					<?php echo $this->session->flashdata('applied'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					<?php  } else if($this->session->flashdata('used')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('used'); ?></span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					
					
				<?php } else if($this->session->flashdata('wrong')){ ?>
					  <div class="alert alert-warning alert-dismissible" role="alert">
					<span style="color:red"><?php echo $this->session->flashdata('wrong'); ?></span>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
						
						
						
						
						
						
						
						<input type="submit" class="btn btn-primary btn-sm"value="Apply Coupon">
						
						
					</form>
									
								
								<?php 
								}
								else 
								{
									?>
									
									
						<form action="#<?php //echo base_url('checkout/applyCoupon');?>" method="POST">	
						<strong>Apply Coupon</strong> <br />
						<p>Enter your coupon code if you have one.</p>
						<input type="text" name="coupon_code"class="form-control"placeholder="Coupon code"required > <br/>
						
						<a href="" class="btn btn-primary btn-sm" data-target="#myLoginRegisterModal" data-toggle="modal"> Apply Coupon</a>
						
						
						
						
					</form>
									
									
									
									
									
									
									
									<?php 
									
									
								}	
								?>
					
					<br />
					<br /><br />
					<br />
			   
			   
			   
						
			  		
						
						<br />
						<br />
						
                    
                   </div>
				  
				   
				   
                </div>
           
			
		
			
            
            <!-- End Cart Panel -->
		  
        </div>
        <!-- End Offset Wrapper -->
        
        
        
       
		