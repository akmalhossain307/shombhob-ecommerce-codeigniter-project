
        
    </div>
    <!-- Body main wrapper end -->
	
   

	
    <!-- Placed js at the end of the document so the pages load faster -->

	
	
    <!-- for jQuery UI jquery latest version -->
    <!--<script src="https://code.jquery.com/jquery-3.4.1.min.js"> </script>-->
 <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	 
	
	 
    <!-- Bootstrap framework js -->
    <script src="<?php echo base_url('assets/front-end')?>/js/bootstrap.min.js"></script>
	
	<!-- Custom JS -->
 <script src="<?php echo base_url('assets/front-end')?>/js/custom.js"></script>

	<!--Social-->
<script src="<?php echo base_url('assets/front-end/js/jssocials.min.js'); ?>"></script>


	
    <!-- All js plugins included in this file. -->
    <script src="<?php echo base_url('assets/front-end')?>/js/plugins.js"></script>
    <script src="<?php echo base_url('assets/front-end')?>/js/slick.min.js"></script>
    <script src="<?php echo base_url('assets/front-end')?>/js/owl.carousel.min.js"></script>
    <!-- Waypoints.min.js. -->
    <script src="<?php echo base_url('assets/front-end')?>/js/waypoints.min.js"></script>
    <!-- Main js file that contents all jQuery plugins activation. -->
    <script src="<?php echo base_url('assets/front-end')?>/js/main.js"></script>
    
    
    <script src="https://www.w3schools.com/lib/w3.js"></script>
    <script src="<?php echo base_url('assets/front-end')?>/js/BootSideMenu.js"></script>
    
   
   
    <script src="<?php echo base_url('assets/back-end/vendors/notifyjs/');?>notify.min.js"></script>
   <!-- End custom js for this page-->
   
  
    
    <script type="text/javascript"> 
$('#loader').addClass("hide-loader");



</script>





<script type="text/javascript"> 

	// for sticky sidebar menu on scroll
	$(window).scroll(function(){
  //more then or equals to
  if($(window).scrollTop() >=30 ){
      
	  $( ".float-right-style" ).css( "display", "block" );
	  $('.float-right-style').addClass('stick');
  //less then 100px from top
  } else {
	  
	 // $( ".float-right-style" ).css( "display", "block" );
	  $('.float-right-style').removeClass('stick');
	  //$( ".float-right-style" ).css( "display", "block" );
     
 
  }
});

</script>








	
	<script type="text/javascript"> 
	window.onload = () => {
  //add event listener to prevent the default behavior
  const mouseOnlyNumberInputField = document.getElementById("mouse-only-number-input");
  mouseOnlyNumberInputField.addEventListener("keypress", (event) => {
    event.preventDefault();
  });
}
	
	</script>
	

	
	<script> 
	$('.dropdown-toggle').click(function(e) {
  if ($(document).width() > 768) {
    e.preventDefault();

    var url = $(this).attr('href');

       
    if (url !== '#') {
    
      window.location.href = url;
    }

  }
	</script>
	
	
	
	<script type="text/javascript"> 
	
	$('#myModal').on('show.bs.modal', function(e) {
    var addressId = $(e.relatedTarget).data('address-id');
    var addressName = $(e.relatedTarget).data('address-name');
    var addressAddress = $(e.relatedTarget).data('address-address');
    var addressContact = $(e.relatedTarget).data('address-contact');
    var addressArea = $(e.relatedTarget).data('address-area');
    $(e.currentTarget).find('input[name="addressId"]').val(addressId);
    $(e.currentTarget).find('input[name="addressName"]').val(addressName);
    $(e.currentTarget).find('input[name="addressAddress"]').val(addressAddress);
    $(e.currentTarget).find('input[name="addressContact"]').val(addressContact);
    $(e.currentTarget).find('input[name="addressArea"]').val(addressArea);
	});
	
	$('#myModal1').on('show.bs.modal', function(e) {
    var addressId = $(e.relatedTarget).data('address-id');
   
    $(e.currentTarget).find('input[name="addressId"]').val(addressId);

	});
	
	
	</script>
	
	<script type="text/javascript">
    $(document).ready(function () {
        w3.includeHTML(init);
    });

    function init() {
        $('#test').BootSideMenu({
            side: "right",
            pushBody: false,
            width: '360px'
        });
    }
</script>
	

	<script type="text/javascript"> 

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
	
  $('#getOfferCat').change(function(){ 
	//var id = $(this).find(":selected").val();	
	
           var category_id = $(this).val();  
		   //alert(category_id);
        
				$.ajax({  
				type:"POST",
                url:"<?php echo base_url();?>Product/fetchOfferByCategory",  
                 
				//cache: false,
                data:{category_id:category_id},  
                success:function(data){  
                     $('#offerByCategory').html(data);  
                }  
			});
			}

		 
      });

</script>
	
<script>
  $( function() {
   // $( "#datepicker" ).datepicker({ minDate: 0, maxDate: "6D" });
  } );
  </script>
	<!-- Auto complete search option -->	


	
	
	<script type="text/javascript">
	$(document).ready(function(){
		$('.add_cart_btn1').click(function(){
			var product_id    = $(this).data("productid");
			var product_name  = $(this).data("productname");
			var product_image = $(this).data("productimage");
			var product_price = $(this).data("productprice");
			var product_old_price = $(this).data("productoldprice");
			var quantity   	  = 1;
			$.ajax({
				url : "<?php echo base_url('product/add_to_cart');?>",
				method : "POST",
				data : {product_id: product_id, product_name: product_name, product_image: product_image, product_price: product_price, product_old_price:product_old_price, quantity: quantity},
				success: function(data){
					$('#detail_cart').html(data);
					location.reload();
					//$('.body__overlay').load("<?php echo site_url('product/load_cart');?>");
				}
			});
		});
		
		
		
		$('.search_add_cart_btn').click(function(){
			var product_id    = $(this).data("productid");
			var product_name  = $(this).data("productname");
			var product_image = $(this).data("productimage");
			var product_price = $(this).data("productprice");
			var product_old_price = $(this).data("productoldprice");
			 
			$.ajax({
				url : "<?php echo base_url('product/add_to_cart');?>",
				method : "POST",
				data : {product_id: product_id, product_name: product_name, product_image: product_image, product_price: product_price, product_old_price:product_old_price, quantity: quantity},
				success: function(data){
					$('#detail_cart').html(data);
					location.reload();
					//$('.body__overlay').load("<?php echo site_url('product/load_cart');?>");
				}
			});
		});
		
		
		
		$('#detail_cart').load("<?php echo site_url('product/load_cart');?>");

		
		$(document).on('click','.romove_cart',function(){
			var row_id=$(this).attr("id"); 
			$.ajax({
				url : "<?php echo base_url('product/delete_cart');?>",
				method : "POST",
				data : {row_id : row_id},
				success :function(data){
					$('#detail_cart').html(data);
				}
			});
		});
		
		
		
		/* add to view list*/
		$('.add_cart_btn1').click(function(){
			var product_id    = $(this).data("productid");
			
			//alert(product_id);

			$.ajax({
				url : "<?php echo base_url('product/add_to_view');?>",
				method : "POST",
				data : {product_id: product_id},
				success: function(data){
					//$('#detail_cart').html(data);
					location.reload();
				
				}
			});
			
		});
		
		
		
		
			
	});
</script>
	
	<script type="text/javascript"> 
	$(document).ready(function(){
	$('.quick-view').click(function(){
   var id=$(this).attr('proid');
	//alert(id);
   // AJAX request
   $.ajax({
    url: '<?php echo base_url(); ?>product/getSingleProductDetails',
    type: 'POST',
    data: {id: id},
    success: function(response){ 
      // Add response in Modal body
      $('.modal-body').html(response);

      // Display Modal
      $('#productModal').modal('show'); 
    }
  });
 });
 });
	
	</script>
	
	
	<!--JS for image preview before upload-->
  <script type="text/javascript"> 
	  function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
  </script>
	
	
	
	
	
	
	
	<script type="text/javascript"> 
	// Carousel Auto-Cycle
  $(document).ready(function() {
    $('.carousel').carousel({
      interval: 5000
    })
  });

	
	</script>
	

	
	
	<!--JS for tooltip-->
	<script>
	$(document).ready(function(){
	  $('[data-toggle="tooltip"]').tooltip();   
	});
	</script>
	

	
	<!--JS for tooltip-->
	<script>
	
	//plugin bootstrap minus and plus
	//http://jsfiddle.net/laelitenetwork/puJ6G/
	$('.btn-number').click(function(e){
    e.preventDefault();
    
    fieldName = $(this).attr('data-field');
    type      = $(this).attr('data-type');
    var input = $("input[name='"+fieldName+"']");
    var currentVal = parseInt(input.val());
    if (!isNaN(currentVal)) {
        if(type == 'minus') {
            
            if(currentVal > input.attr('min')) {
                input.val(currentVal - 1).change();
            } 
            if(parseInt(input.val()) == input.attr('min')) {
                $(this).attr('disabled', true);
            }

        } else if(type == 'plus') {

            if(currentVal < input.attr('max')) {
                input.val(currentVal + 1).change();
            }
            if(parseInt(input.val()) == input.attr('max')) {
                $(this).attr('disabled', true);
            }

        }
    } else {
        input.val(0);
    }
});
$('.input-number').focusin(function(){
   $(this).data('oldValue', $(this).val());
});
$('.input-number').change(function() {
    
    minValue =  parseInt($(this).attr('min'));
    maxValue =  parseInt($(this).attr('max'));
    valueCurrent = parseInt($(this).val());
    
    name = $(this).attr('name');
    if(valueCurrent >= minValue) {
        $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the minimum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    if(valueCurrent <= maxValue) {
        $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
    } else {
        alert('Sorry, the maximum value was reached');
        $(this).val($(this).data('oldValue'));
    }
    
    
});
$(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
	
	
	</script>
	
	<script type="text/javascript"> 
	
	$(document).ready(function(){

	var native_width = 0;
	var native_height = 0;
  $(".large").css("background","url('" + $(".small").attr("src") + "') no-repeat");

	//Now the mousemove function
	$(".magnify").mousemove(function(e){
		//When the user hovers on the image, the script will first calculate
		//the native dimensions if they don't exist. Only after the native dimensions
		//are available, the script will show the zoomed version.
		if(!native_width && !native_height)
		{
			//This will create a new image object with the same image as that in .small
			//We cannot directly get the dimensions from .small because of the 
			//width specified to 200px in the html. To get the actual dimensions we have
			//created this image object.
			var image_object = new Image();
			image_object.src = $(".small").attr("src");
			
			//This code is wrapped in the .load function which is important.
			//width and height of the object would return 0 if accessed before 
			//the image gets loaded.
			native_width = image_object.width;
			native_height = image_object.height;
		}
		else
		{
			//x/y coordinates of the mouse
			//This is the position of .magnify with respect to the document.
			var magnify_offset = $(this).offset();
			//We will deduct the positions of .magnify from the mouse positions with
			//respect to the document to get the mouse positions with respect to the 
			//container(.magnify)
			var mx = e.pageX - magnify_offset.left;
			var my = e.pageY - magnify_offset.top;
			
			//Finally the code to fade out the glass if the mouse is outside the container
			if(mx < $(this).width() && my < $(this).height() && mx > 0 && my > 0)
			{
				$(".large").fadeIn(100);
			}
			else
			{
				$(".large").fadeOut(100);
			}
			if($(".large").is(":visible"))
			{
				//The background position of .large will be changed according to the position
				//of the mouse over the .small image. So we will get the ratio of the pixel
				//under the mouse pointer with respect to the image and use that to position the 
				//large image inside the magnifying glass
				var rx = Math.round(mx/$(".small").width()*native_width - $(".large").width()/2)*-1;
				var ry = Math.round(my/$(".small").height()*native_height - $(".large").height()/2)*-1;
				var bgp = rx + "px " + ry + "px";
				
				//Time to move the magnifying glass with the mouse
				var px = mx - $(".large").width()/2;
				var py = my - $(".large").height()/2;
				//Now the glass moves with the mouse
				//The logic is to deduct half of the glass's width and height from the 
				//mouse coordinates to place it with its center at the mouse coordinates
				
				//If you hover on the image now, you should see the magnifying glass in action
				$(".large").css({left: px, top: py, backgroundPosition: bgp});
			}
		}
	})
})
	
	</script>
	
	
	<script>
	
	/*
		$(document).ready(function(){

		 load_data();

		 function load_data(query)
		 {
		  $.ajax({
		   url:"<?php echo base_url(); ?>Search/fetchSearchResult",
		   method:"GET",
		   data:{query:query},
		   success:function(data){
			$('#searchResult').html(data);
		   }
		  })
		 }

		 $('#search_text').keyup(function(){
		  var search = $(this).val();
		  if(search != '')
		  {
		   load_data(search);
		   $('#hidden4SearchResult').hide();
		  }
		  else
		  {
			  
		   load_data(search);
		   $('#searchResult').html(data);
		   
		  }
		 });
		});
		
	
	*/	
		
</script>


<script>

//for search result in mobile view 
/*
		$(document).ready(function(){

		 load_data();

		 function load_data(query)
		 {
		  $.ajax({
		   url:"<?php echo base_url(); ?>Search/fetchSearchResult",
		   method:"GET",
		   data:{query:query},
		   success:function(data){
			$('#searchResult').html(data);
		   }
		  })
		 }

		 $('#search_text1').keyup(function(){
		  var search = $(this).val();
		  if(search != '')
		  {
		   load_data(search);
		   $('#hidden4SearchResult').hide();
		  }
		  else
		  {
		   //load_data(search);
		   
		  }
		 });
		});
		*/
</script>

<script type="text/javascript"> 
<?php if($this->session->flashdata('regSuccess') ){ ?>

    $(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php 
}
else if($this->session->flashdata('regError'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}
else if($this->session->flashdata('logSuccess'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}
else if($this->session->flashdata('logError'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}

else if($this->session->flashdata('validationError'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}

else if($this->session->flashdata('mobileNumberExist'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}

else if($this->session->flashdata('emailExist'))
{
?>
$(window).on('load',function(){
        $('#myLoginRegisterModal').modal('show');
    });
<?php	
}
else if($this->session->flashdata('mobileOrEmailNotExit'))
{
?>
$(window).on('load',function(){
        $('#passRecoveryModal').modal('show');
    });
<?php	
}


?>
</script>




<script type="text/javascript">

function ajaxSearch()
{
    var input_data = $('#search_data').val();

    if (input_data.length === 0)
    {
        $('#suggestions').hide();
    }
    else
    {

        var post_data = {
            'search_data': input_data,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>search/autocomplete/",
            data: post_data,
            success: function (data) {
                // return success
                if (data.length > 0) {
                    $('#suggestions').show();
                    $('#autoSuggestionsList').addClass('auto_list');
                    $('#autoSuggestionsList').html(data);
                }
            }
         });

     }
 }
 
 
 function ajaxSearch1()
{
    var input_data = $('#search_data1').val();

    if (input_data.length === 0)
    {
        $('#suggestions1').hide();
    }
    else
    {

        var post_data = {
            'search_data1': input_data,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>search/autocomplete1/",
            data: post_data,
            success: function (data) {
                // return success
                if (data.length > 0) {
                    $('#suggestions1').show();
                    $('#autoSuggestionsList1').addClass('auto_list1');
                    $('#autoSuggestionsList1').html(data);
                }
            }
         });

     }
 }

 
 
 // Carousel Auto-Cycle
  $(document).ready(function() {
    $('.carousel').carousel({
      interval: 3000
    })
  });
 
 
 
</script>



<script type="text/javascript"> 
$.notify("<?php echo $this->session->flashdata('success'); ?>", "success");
$.notify("<?php echo $this->session->flashdata('error'); ?>", "error");

$.notify("<?php echo $this->session->flashdata('cartSuccess'); ?>", "success");

</script>


	
</body>

</html>