<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
                    <!-- Start Left Feature -->
                    
<div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 float-right-style">					
	<div class="categories-menu mrg-xs">				
		<div class="nav-side-menu">
			<div class="category-heading">
                               <h3> Categories</h3>
                            </div>
			<i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list sidebarCategory">
  
            <ul id="menu-content" class="menu-content collapse out">
                <?php 
				$this->load->model('product_model');
				$cnt_offers = $this->product_model->countTotalOffers();
				?>
				
				<li>
                 &nbsp;&nbsp;<a href="<?php echo base_url('offers')?>"> Offers <span style="color:coral"> (<?php echo$cnt_offers;?>)</span></a>
                </li>
				
				<?php 
				$catCounter=0;
			$this->load->model('product_model');
			$category=$this->product_model->productMainCategory();
			foreach($category as $cat)
			{
				$catCounter++;
			?>
			<?php $imgURL=$cat->category_icon;?>
				

                <li  data-toggle="collapse" data-target="#<?php echo$catCounter;?>" class="collapsed">
                  <a href="#">
				<img alt="category icon" src="<?php echo base_url().$imgURL?>" width="20"height="15"> &nbsp;&nbsp;
				  <?php echo$cat->category_name;?> 
				  
				  <span class="arrow" style="padding:0px;font-size:10px"></span></a>
                </li>
				<ul class="sub-menu collapse" id="<?php echo$catCounter;?>">
				<?php
				$category_id=$cat->category_id;
				$subCategoryByCategory=$this->product_model->productSubCategory($category_id);
				
				if($subCategoryByCategory){
						$counter=0;				
						foreach($subCategoryByCategory as $subCat){
						$counter++;
										
						
						?>
                
                    <li><a href="<?php echo base_url('category/').$subCat->subCategorySlug;?>"><?php echo$subCat->subCategoryName;?></a></li>
                    
               
				
				<?php 
				}
				}
				echo"</ul>";
			
				}
						
				?>
				
				
            </ul>
     </div>
</div>
</div>
	
</div>
  
		<!-- End Left Feature -->
	</div>

					
					
                    <div class="col-md-10 col-lg-10 col-sm-10 col-xs-12 float-left-style">
						
                            <div class="showing_fillter">
                                <div class="row m0">
								
									<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>">Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Category</a></li>
										<li class="active"><?php echo ucfirst($categorySlug);?></li>        
									</ol>
								
				
				
				
				
				
				<div class="btn-group" role="group">
				
				<?php 
					$this->load->helper('url');
					$currentURL = current_url();
				?>
				
					<form action="<?php echo $currentURL;?>" method="POST">
					
					<label for="email">SORT BY Price: </label> &nbsp;&nbsp;&nbsp;
				
							
						
						 <button type="submit" name="filterBy" value="lowToHigh" class="btn btn-primary btn-sm">Low to High</button> 
						 
						 &nbsp;&nbsp;<button type="submit" name="filterBy" value="highToLow" class="btn btn-info btn-sm">High to Low</button>
						 &nbsp;&nbsp;&nbsp;&nbsp;
						 <label for="email">SORT BY: </label>
						 &nbsp;&nbsp;<button type="submit" name="filterBy" value="newest" class="btn btn-success btn-sm">Newest</button>

						 &nbsp;&nbsp;<button type="submit" name="filterBy" value="oldest" class="btn btn-warning btn-sm">Oldest</button>
						 
						 &nbsp;&nbsp;<button type="submit" name="filterBy" value="atoz" class="btn btn-danger btn-sm">A-Z</button>
						 
						 &nbsp;&nbsp;<button type="submit" name="filterBy" value="ztoa" class="btn btn-info btn-sm">Z-A</button>
						 
					</form>	
				</div>
				       
                                </div>
                            </div>
							

				
				
				 <div class="categories_product_area">
                                <div class="row">
								
								<?php 
if(isset($_POST['filterBy']))
	{
		
		//$currntURL=$this->input->post('currentURL');
		$filterKeyword=$_POST['filterBy'];
		
		if($filterKeyword=='lowToHigh')
		{
			$filterProducts=$this->product_model->filterByProductPriceLowToHigh();	
		}
		else if($filterKeyword=='highToLow')
		{
		$filterProducts=$this->product_model->filterByProductPriceHighToLow();
		}
		else if($filterKeyword=='newest')
		{
		$filterProducts=$this->product_model->filterByProductNewest();
		}
		else if($filterKeyword=='oldest')
		{
		$filterProducts=$this->product_model->filterByProductOldest();
		}
		else if($filterKeyword=='atoz')
		{
		$filterProducts=$this->product_model->filterByProductAtoZ();
		}
		else if($filterKeyword=='ztoa')
		{
		$filterProducts=$this->product_model->filterByProductZtoA();
		}	
		
		
			foreach($filterProducts as $product)
			{
				
				 $this->load->model('Product_model');
				 $get_default_photo = $this->product_model->get_default_photo($product['product_id']);
				 $proImage = $get_default_photo['image_url'];
			?>
								
								
								
								
								
                                    <div class="col-lg-2 col-sm-4 col-md-2 col-xs-6">
                                        <div class="l_product_item">
                                            
                                           <?php
        									$qty=$product['product_quantity'];
        									if($qty==0)
        									{
        									    ?> 
                                            
                                            <span class="product-new-label" style="background-color: #e67e22;color: #fff;font-size: 17px;padding: 2px 10px;position: absolute;right: 10px;top: 10px;transition: all .3s;">Out of stock</span>
                                            
                                            <?php 
        									}
                                            ?>
                                            
                                            
                                            
                                            
                                            <div class="l_p_img">
											<a title="Click to View Details" class="view_detail quick-view modal-view detail-link" href="<?php echo base_url().$product['slug'];?>"> <img src="<?php echo base_url().$proImage;?>" alt="<?php echo $product['slug'];?>" height="190px"> </a>
                                                
												
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
											   <!--
											   <li> <a href=""class="viewTest" id="test">Test</a></li>
											   -->
											  
                                                    <li> <a href="<?php echo base_url().$product['slug'];?>" class="btn btn-success">Details</a></li>
                                                    <li>
													
													
							<?php 

                            $pres=$product['product_need_prescription'];
                            $type=$product['type'];
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                            
									<br/>	
                            	<a href="<?php echo base_url().$product['slug'];?>" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary">Add to Bag</a>
                            
                            <h5 class="hot">Need Prescription</h5>
                           
                            
                            
                            <?php 
                            }
                            else 
                            {
                            ?>
											
											
											<?php
        									$qty=$product['product_quantity'];
        									if($qty==0)
        									{
        									    ?>
        									    	<br/>
								
								<input class="btn btn-primary btn-sm disabled" type="text" value="Add To Bag" title="Product Out of Stock" />
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>		
													
												<br/>		
										<button class=" btn btn-primary add_cart_btn1" data-productid="<?php echo $product['product_id'];?>" data-productname="<?php echo $product['title'];?>"data-productimage="<?php echo base_url().$proImage;?>" data-productprice="<?php 
													if($product['discountPrice'])
													{
													$price=$product['discountPrice'];
													}
													else 
													{
													$price=$product['price'];	
													}
													echo$price;?>">Add To Cart</button>
													
							<?php 
        									}
							}
							?>					
													
													</li>
													
													
                                                </ul>
                                                <h4><?php echo $product['title'];?></h4>
												<p><?php echo$product['measuringType'];?></p>
                                                <h6><span>Price:</span> 
												
												<?php if($product['discountPrice'])
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product['price'];?></del> TK <?php echo$product['discountPrice'];
												}
												else 
												{
													?>
													TK  <?php echo$product['price'];?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									}
									
									
									?>
								</div>
                                
                            </div>
                     
				<?php 
			}
			 
			else 
			{
		
?>	
							
							
                           
						
						
						
                                <div class="row">
								
								<?php if($categoryProduct){
									foreach($categoryProduct as $product){
									 $this->load->model('Product_model');
									 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
									 $proImage = $get_default_photo['image_url'];
								?>
								
								
                                    <div class="col-lg-2 col-sm-4 col-md-2 col-xs-6">
                                        <div class="l_product_item">
                                            
                                            <div class="l_p_img">
                                                
                                                <?php
        									$qty=$product->product_quantity;
        									if($qty==0)
        									{
        									    ?> 
                                            
                                            <span class="product-new-label" style="background-color: #e67e22;color: #fff;font-size: 17px;padding: 2px 10px;position: absolute;right: 10px;top: 10px;transition: all .3s;">Out of stock</span>
                                            
                                            <?php 
        									}
                                            ?>
                                                
                                                
											<a title="Click to View Details" class="view_detail quick-view modal-view detail-link" href="<?php echo base_url().$product->slug;?>"> <img src="<?php echo base_url().$proImage;?>" alt="<?php echo $product->slug;?>" height="190px"> </a>
                                                
												<?php 
												/*
												$att=$product->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="featured")
												{
												echo"<h5 class='sale'>Featured</h5>";	
												}else if($att=="hot")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="normal")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="new")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}
												*/
												?>
												
												
                                                <!--
                                                <h5 class="new">New</h5>
                                                -->
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
											   <!--
											   <li> <a href=""class="viewTest" id="test">Test</a></li>
											   -->
											  
                                                    <li> <a href="<?php echo base_url().$product->slug;?>" class="btn btn-success">Details</a></li>
                                                    <li>
													
													
							<?php 

                            $pres=$product->product_need_prescription;
                            $type=$product->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                            
										<br/>	
                            	<a href="<?php echo base_url().$product->slug;?>" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary">Add to Bag</a>
                            
                            
                           
                            
                            
                            <?php 
                            }
                            else 
                            {
                            ?>
											
											
											<?php
        									$qty=$product->product_quantity;
        									if($qty==0)
        									{
        									    ?>
									<br/>
							<!--	<input class="btn btn-primary btn-sm disabled" type="text" value="Add To Bag" title="Product Out of Stock" /> -->
							<?php 
							    $this->load->helper('url');
							    $currentURL11 = current_url();
							
							?>
							<form method="POST" action="<?php echo base_url('product/productRestockRequest');?>">
    							<input type="hidden"name="url" value="<?php echo$currentURL11;?>"/>
    							<input type="hidden"name="product_id" value="<?php echo$product->product_id;?>"/>
    							<input type="submit"name="submit" value="Request Stock" class="btn btn-warning"/>
							</form>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>		
													
												<br/>		
										<button class=" btn btn-primary add_cart_btn1" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productimage="<?php echo base_url().$proImage;?>" data-productprice="<?php 
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
													
							<?php 
        									}
							}
							?>					
													
													</li>
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
												<p><?php echo$product->measuringType;?></p>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									}
									}
									else 
									{
										echo"<center><span style='color:coral;align:center;font-size:16px;'>No product found in this category...</span></center><br/><br/><br/>";
									}
									?>
								</div>
                                
                           
                     
			<?php 
			} 
			?>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		 <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
					 
</div>
					 
	
	<?php 
	/*
	if(isset($_POST['submit']))
	{
	        $this->load->model('product_model');
	        $proId=$_POST['product_id'];
	       // exit();
			$data=array(
			    "product_id"=>$proId
			    );
		    $save = $this->product_model->saveproductRestockRequest($data);
		    if($save)
    		{
    		     $this->session->set_flashdata('success','Product re-stock request sent successfully!');
    		    
    		    //echo"<script> alert('Product re-stock request sent successfully!')</script>";
    		  
		    }
		    else 
		    {
		        $this->session->set_flashdata('error','Something went wrong! Product restock request not sent.');
		        //echo"<script> alert('Something went wrong! Product restock request not sent.')</script>";
    		   
		    }
	}
	*/
	?>
	
	

  



	
	<script type="text/javascript"> 
$.notify("<?php echo $this->session->flashdata('success'); ?>", "success");
$.notify("<?php echo $this->session->flashdata('error'); ?>", "error");

$.notify("<?php echo $this->session->flashdata('cartSuccess'); ?>", "success");

</script>
	
	
	  
                 
				 
				 
            </div>
        
            
        </section>
        <!-- End Feature Product -->