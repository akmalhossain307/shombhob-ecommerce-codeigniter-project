
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span> Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Checkout</li>       
										      
				</ol>
				
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				    
			
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        
                          <br/>      
                          <div class="panel-group">
                            <div class="panel panel-default">
                       
                                <h4 class="panel-title">
                                  <a data-toggle="collapse" href="#collapse1">    
                                  
                                        <h3 style="padding:10px;background:#303030;color:#fff;font-weight:normal"> <span class="fa fa-angle-double-down"></span> Collapse Customer Panel</h3>
                               
                                    </a>
                                </h4>
                            
                              <div id="collapse1" class="panel-collapse collapse">
                                   <div class="category-menu-list">
                                     <ul>
                               
                                  <li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>"> <span class="fa fa-history"></span> Order History</a>
								</li>
							
								
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
                                </ul>
                            </div>
                               
                              </div>
                            </div>
                          </div>
                        
                        
                        <span style='color:green' class='fa fa-bank'></span> <span style='color:green'>Safe and Secure Payments. Easy returns. 100% Authentic products.</span>
                        
                        
				<?php 
				} 
				else 
				{
					echo" <br /><br /><br /> <span style='color:green' class='fa fa-bank'></span> <span style='color:green'>Safe and Secure Payments. Easy returns. 100% Authentic products.</span>";
				}
				?>
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12 ">
                        
                        
                        	<br/>

                    <h2 style="text-align: left;">
                       &nbsp; CHECKOUT
                    </h2>
					
					
					
			
					
					
					
                    <br/>
                    
					<?php if($this->session->userdata('custmrLogin')==false){?>
					
					<div class="panel panel-info">
						<div class="panel-heading" style="background:#C6DBDA;height:40px">
						<h1 class="panel-title" style="font-size:13px"><span class="ti-user"></span> Customer-Login/Registration</h1>
						</div>
						<div class="panel-body" style="background:#ddd">
						
						
						 <div class="col-md-8" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Signin" data-toggle="tab">Login</a></li>
                            <li><a href="#Signup" data-toggle="tab">Registration</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Signin">
							<br />
                                <form action="<?php echo base_url('customer/login')?>" method="POST"role="form" class="form-horizontal">
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Username</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="email1" name="username"placeholder="Email" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" name="password"class="form-control" id="pwd1" placeholder="password" required />
                                    
                                        <input type="checkbox" id="showPass1"> Show Password 

<script type="text/javascript"> 
		
function show1() {

var p = document.getElementById('pwd1');
			
p.setAttribute('type', 'text');
		
}

		
function hide1() {
			
var p = document.getElementById('pwd1');
			
p.setAttribute('type', 'password');
		
}

		
var pwShown = 0;

		
document.getElementById("showPass1").addEventListener("click", function () 
{
			
if (pwShown == 0) 
{
				
pwShown = 1;
				
show1();
			
} 
else {
				
pwShown = 0;
				
hide1();
			
}
		
}, false);
		

</script>
                                        
                                    </div>
                                </div>
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);

								?>
								<input type="hidden" name="currentURL1" value="<?php echo$currentURL1;?>"/>
								
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Login</button>
                                       
                                       
                                                
									<!--	
										<a href="#passRecoveryModal" data-toggle="modal">Forgot your password?</a>
										
										-->
										
										<a href="<?php echo base_url('customer/forgotPassword');?>" >Forgot your password?</a>
                                       
                                       
                                       
                                       
                                       
                                    </div>
                                </div>
                                </form>
                            </div>
                            <div class="tab-pane" id="Signup">
							<br />
                                <form method="POST" action="<?php echo base_url('customer/registration')?>"role="form" class="form-horizontal" id="register">
                                
                                <div class="form-group">
								
                                    <label for="email" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="Name" placeholder="Name" name="name" required />
                                    </div>

                                </div>
								<div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" id="Email" name="email" value="<?php echo set_value('email'); ?>"placeholder="Email" required />
									<span class="text-danger">
									<?php 
									if($this->session->flashdata('emailExist1')){ 
									echo $this->session->flashdata('emailExist1');
									
									}
									?>
									</span>
									</div>
                                </div>
                                <div class="form-group">
                                    <label for="mobile" class="col-sm-2 control-label">
                                        Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="Mobile" placeholder="Mobile" name="mobile" required />
                                    
										<span class="text-danger">
										<?php 
										if($this->session->flashdata('mobileNumberExist1')){ 
										echo $this->session->flashdata('mobileNumberExist1');
										
										}
										?>
										</span>
									</div>
									
                                </div>
                                <div class="form-group">
                                    <label for="password" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" id="password" placeholder="Password" name="password"/>
										<span id="result"></span>
                                    </div>				
							
                                </div>
								<?php 
									$this->load->helper('url');
									$currentURL = current_url();
									//print_r($currentURL);

								?>
								<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
								
								
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" name="submit"class="btn btn-primary btn-sm">
                                            Submit</button>
                                        <button type="reset" class="btn btn-default btn-sm">
                                            Reset</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                        <div id="OR" class="hidden-xs">
                            OR</div>
                    </div>
					
					<div class="col-md-4">
                        <div class="row text-center sign-with">
                            <h3>
							<address><b>Call Us:</b> <a href="#"><i class="zmdi zmdi-phone-in-talk"></i> +8801755697233</a></address>
							</h3>
                        </div>
                    </div>
					
					<!--
                    <div class="col-md-4">
                        <div class="row text-center sign-with">
                            <div class="col-md-12">
                                <h3>
                                    Sign in with</h3>
                            </div>
                            <div class="col-md-12">
                                <div class="btn-group btn-group-justified">
                                    <a href="#" class="btn btn-primary">Facebook</a> <a href="#" class="btn btn-danger">
                                        Google</a>
                                </div>
                            </div>
                        </div>
                    </div>
					-->
						
						</div>
						
						<br />
						<br />
						<br />
						<br />
						<br />
						<br />
						
						
					</div>
					
					<?php 
					
					}
					
					if($this->session->userdata('custmrLogin')==true && $this->session->userdata('delivery_address')==false)
					{
					?>
					
					<div class="col-lg-12">  
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					<?php 
					if($this->session->userdata('customr_mobile')=='01738279545')
					{
					?>
					<div class="panel panel-success">
					<div class="panel-heading">Information of Merchant's customer</div>
							  
					<div class="panel-body">
					  
				<h3 style="color:coral"><i>Enter Customer Information</i></h3> <br />
					  
				<?php 
				if($this->session->flashdata('merchantActive')){ ?>
				
				<div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('merchantActive'); ?></strong>
				</div>
				
				<?php };?>
				
				<?php 
				if($this->session->flashdata('error')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('error'); ?></strong>
				</div>
				
				<?php };?>
					  
	<form action="<?php echo base_url('checkout/saveMerchantCustomerAddress');?>" method="POST">	  
					  
					  
						<div class="col-lg-4">
						  <label for="email"> Name:</label>
						  <input type="text" class="form-control"  name="name">
						</div>
						
						<div class="col-lg-4">
						  <label for="email"> Phone:</label>
						  <input type="text" class="form-control" name="address_phone">
						</div>
						
						<div class="col-lg-4">
						  <label for="email">Area:</label>
					<select class="form-control" id="id_state" name="address_area" required>
						<option selected>Select Area</option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
					</select>
			
						  
						</div>
			
	
				<div class="col-lg-12">
				 
					 <label for="email"> Address:</label>
					 <input type="text" class="form-control" name="address_address"placeholder="Enter full address" />
					  
				</div>
						
				<div class="col-lg-12">
				<br />
						
				<?php 
				if($this->session->userdata('custmrLogin'))
				{
					$custommerId=$this->session->userdata('active_customer');
				}
				$this->load->helper('url');
				$currentURL = current_url();
				//print_r($currentURL);
				?>
				
					<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
					<input type="hidden" name="address_customerId" value="<?php echo$custommerId;?>"/>
					
					
					<input type="hidden" name="merchant" value="merchantCustomer"/>
						
						
						  <input type="reset" class="btn btn-danger btn-sm" value="Reset" />
					&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-primary btn-sm" value="Save Address" />
						</div>
						
						
					</form>	
						
					  </div>
					  
					   <br/><br/> <br/><br/>
					  
					  
					  
		<?php 
		$mrchtActive=$this->session->userdata('merchantActive');
		if($mrchtActive==true)
		{
		?>			  
					  
	<form action="<?php echo base_url('checkout/setDeliveryAddress')?>" method="POST">				  
		<div class="text-right">

		<?php 
			
		 foreach($customer_address as $address)
		 {
			 ?>
			 <input type="hidden"  name="address" value="<?php echo$address->address_id;?>" >
			 
			 <?php 
		 }
		 ?>
		
			<input type="hidden" name="deliveryAddress" value="setDeliveryAddress"/>
			
			<input type="submit"class="btn btn-warning btn-lg" value="Next" />		
						
		</div>  
	</form>			  
					  
		<?php 
		}
		?>			  
					  
					  
					  
 
				</div>
							
				<?php 
						
				}
				else 
				{
				
					
				?>
				
					<div class="panel panel-success">
					  <div class="panel-heading">
					  <h3 class="panel-title">
                        Contact and Delivery Information
                      </h4> 
					</div>
					
					
					  <div class="panel-body">
					   <?php 
						 if($customer_address==false)
						 {
							 
							?>
					  <h3 style="color:coral" class="text text-muted">No delivery address found. Please fill below information to complete the delivery information.</h3> <br />
					  
					  
					  
					  
				<?php 
				if($this->session->flashdata('error')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('error'); ?></strong>
				</div>
				
				<?php };?>
					  
	<form action="<?php echo base_url('checkout/saveCustomerAddress');?>" method="POST">	  
					  
					  
						<div class="col-lg-4">
						  <label for="email"> Name:</label>
						  <input type="text" class="form-control"  name="name" value="<?php echo $this->session->userdata('customr_name')?>" name="email">
						</div>
						
						<div class="col-lg-4">
						  <label for="email"> Phone:</label>
						  <input type="text" class="form-control" name="address_phone" value="<?php echo $this->session->userdata('customr_mobile')?>" name="email">
						</div>
						
						<div class="col-lg-4">
						  <label for="email">Area:</label>
					<select class="form-control" id="id_state" name="address_area" required>
						<option selected>Select Area</option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
					</select>
			
						  
				</div>
			
	
						<div class="col-lg-12">
						 
						 <label for="email"> Address:</label>
						 <input type="text" class="form-control" name="address_address"placeholder="Enter full address" />
						  
						</div>
						
						<div class="col-lg-12">
						<br />
						
						
						
						<?php 
				if($this->session->userdata('custmrLogin'))
				{
					$custommerId=$this->session->userdata('active_customer');
				}
				$this->load->helper('url');
				$currentURL = current_url();
				//print_r($currentURL);
				?>
				
					<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
					<input type="hidden" name="address_customerId" value="<?php echo$custommerId;?>"/>
						
						
						  <input type="reset" class="btn btn-danger btn-sm" value="Reset" />
					&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-primary btn-sm" value="Save Address" />
						</div>
						
						
					</form>	
						
					  </div>
					  
					  
					</div>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
		  
			
	<div class="row">
	
	
	
		<?php 	 
		 }
		  
		 
		 else 
		 {
			?>
		 
			<div class="col-lg-12"> 
				<i style="color:red;font-size:18px">Select delivery address </i><br/>(<small class="text text-muted">Address where you want to receive your product</small>)
				
			</div>
			
			
	
		<?php 
			 
			$counter=0; 
		 foreach($customer_address as $address)
		 {
			 $counter++;
			 if($counter==1){
		 ?>
	<form action="<?php echo base_url('checkout/setDeliveryAddress')?>" method="POST">
		<div class="col-lg-4">
		<br />
			<div class="panel panel-default">
			  <div class="panel-heading">
			  <h1 class="panel-title">
			  <input type="radio" id="male" name="address" value="<?php echo$address->address_id;?>" checked> Address <?php echo$counter;?></h1>
			  
			  </div>
			  
			  <div class="panel-body">
				<strong>Name: </strong><?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?><br> 
				<strong>Contact: </strong> <?php echo$address->address_phone;?> <br> 
				<strong>Address: </strong> <?php echo$address->address_address;?> <br> 
				<strong>Area: </strong> <?php echo$address->address_area;?><br> 
				 
				 <a data-toggle="modal" data-target="#myModal" data-address-id="<?php echo$address->address_id;?>" data-address-name="<?php echo$address->name;?>"data-address-contact="<?php echo$address->address_phone;?>"data-address-address="<?php echo$address->address_address;?>"data-address-area="<?php echo$address->address_area;?>"href="#"class="btn btn-info btn-sm">Edit</a> &nbsp;&nbsp;&nbsp;
				 <a data-toggle="modal" data-target="#myModal1" data-address-id="<?php echo$address->address_id;?>" href="#"class="btn btn-danger btn-sm">Delete</a>
				 
				 
			  </div>
			</div>
		</div>
		
		<?php 
			 }
			 else 
			 {
				 
			 
		?>
		
		<div class="col-lg-4">
		<br />
			<div class="panel panel-default">
			  <div class="panel-heading">
			  <h1 class="panel-title">
			  <input type="radio" id="male" name="address" value="<?php echo$address->address_id;?>"> Address <?php echo$counter;?></h1>
			  
			  </div>
			  
			  <div class="panel-body" style="background:#ddd">
				<strong>Name: </strong><?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?><br> 
				<strong>Contact: </strong> <?php echo$address->address_phone;?> <br> 
				<strong>Address: </strong> <?php echo$address->address_address;?> <br> 
				<strong>Area: </strong> <?php echo$address->address_area;?><br> 
				 
			<a data-toggle="modal" data-target="#myModal" data-address-id="<?php echo$address->address_id;?>" data-address-name="<?php echo$address->name;?>"data-address-contact="<?php echo$address->address_phone;?>"data-address-address="<?php echo$address->address_address;?>"data-address-area="<?php echo$address->address_area;?>"href="#"class="btn btn-info btn-sm">Edit</a> &nbsp;&nbsp;&nbsp;
			
			<a data-toggle="modal" data-target="#myModal1" data-address-id="<?php echo$address->address_id;?>" href="#"class="btn btn-danger btn-sm">Delete</a>
			
			</div>
			</div>
		</div>
			
			<?php 
			 }
			 }
			 
			 ?>
			 
			 
			 
			 
			 <div class="col-lg-12">			  
		
		<a href="#newAddress" class="btn btn-info" data-toggle="collapse">Add New Address</a>
		
				
	  	
	  <div class="text-right">

		<input type="hidden" name="deliveryAddress" value="setDeliveryAddress"/>
		<br/>
		
	
		<input type="submit"class="btn btn-primary" value="Next >>"/>		
					
	</div>
	  
	  </form>
	  
	  <div id="newAddress" class="collapse">
		
						<?php 
				if($this->session->flashdata('error')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('error'); ?></strong>
				</div>
				
				<?php };?>
				
				
				<form action="<?php echo base_url('checkout/saveCustomerAddress');?>" method="POST">	  
					  
					  
						<div class="col-lg-4">
						  <label for="email"> Name:</label>
						  <input type="text" class="form-control"  name="name" value="<?php echo $this->session->userdata('customr_name')?>" name="email">
						</div>
						
						<div class="col-lg-4">
						  <label for="email"> Phone:</label>
						  <input type="text" class="form-control" name="address_phone" value="<?php echo $this->session->userdata('customr_mobile')?>" name="email">
						</div>
						
						<div class="col-lg-4">
						  <label for="email">Area:</label>
					<select class="form-control" id="id_state" name="address_area" required>
						<option value="" selected>Select Area</option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
					</select>
			
						  
				</div>
			
	
						<div class="col-lg-12">
						 
						 <label for="email"> Address:</label>
						 <input type="text" class="form-control" name="address_address"placeholder="Enter full address" />
						  
						</div>
						
						<div class="col-lg-12">
						<br />
						
						<?php 
				if($this->session->userdata('custmrLogin'))
				{
					$custommerId=$this->session->userdata('active_customer');
				}
				$this->load->helper('url');
				$currentURL = current_url();
				//print_r($currentURL);
				?>
				
					<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
					<input type="hidden" name="address_customerId" value="<?php echo$custommerId;?>"/>
						
						
						  <input type="reset" class="btn btn-danger btn-sm" value="Reset" />
					&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-primary btn-sm" value="Save Address" />
						
						</div>
					 
			</form>	
		
	  </div>
  </div>
			 
			 
			 
			 
			 
			 
			 
			 
			 
			 <?php
			 
			 }
			 ?>
			
			
			
			
			
			
			
			
			
			
			
			
				 
				 
				 <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Are you sure to delete this address?</h4>
        </div>
        <div class="modal-body">
	<form action="<?php echo base_url('checkout/deleteSingleAddress');?>" method="POST"> 
          
	
		  <?php 
			
			$this->load->helper('url');
			$currentURL = current_url();
			//print_r($currentURL);
			?>
			<input type="hidden" name="addressId" value=""/>
			<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
			
			<a class="btn btn-warning btn-sm"href="<?php echo base_url('checkout');?>">No</a>
			
					&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" class="btn btn-primary btn-sm" value="Yes" />
		  
		  
		  </form>
		  
        </div>
        
      </div>
      
    </div>
  </div>
				 
	
	
	<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Address</h4>
        </div>
        <div class="modal-body">
	<form action="<?php echo base_url('checkout/updateCustomerAddress');?>" method="POST"> 
          
          <label>Name:</label><input type="text" name="addressName" value="" class="form-control"/>
          <label>Contact:</label><input type="text" name="addressContact" value="" class="form-control"/>
          <label>Address:</label><input type="text" name="addressAddress" value="" class="form-control"/>
          
          
          <label>Area:</label>
		  
		  <select class="form-control" id="id_state" name="addressArea" required>
						<option value="" selected>Select Area</option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
				</select>
			
		  
		  
		  <br />
		  
		  <?php 
			
			$this->load->helper('url');
			$currentURL = current_url();
			//print_r($currentURL);
			?>
			<input type="hidden" name="addressId" value=""/>
			<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
			
			
			<input type="reset" class="btn btn-danger btn-sm" value="Reset" />
					&nbsp;&nbsp;&nbsp;&nbsp;
					
					
			<input type="submit" class="btn btn-primary btn-sm" value="Submit" />
		  
		  
		  </form>
		  
        </div>
        
      </div>
      
    </div>
  </div>
			 
			  
		
		 
		
		
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		</div>
					  

											
			
			   
			</table>
		</div>
   
</div>

</div>

<?php 
					}
					}
					else 
					{
						echo"";
					}
?>
					
					
				
	<!-- Modal -->
<div class="modal fade" id="editDeliveryAddress" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">

<?php foreach($customer_address as $address)
		 {
			 ?>
		 
		 
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2 class="modal-title" id="myModalLabel" style="color:fuchsia">Update Delivery Address</h2>
      </div>
      <div class="modal-body">
   <?php $cus_id=$address->address_customerId;?>
   <form action="<?php echo base_url('checkout/updateDeliveryAddress/').$cus_id;?>" method="POST">
   
			<tr>
				<td>
					<label for="id_first_name">First name:</label></td>
				<td>
					<input class="form-control" id="id_first_name" value="<?php echo$address->address_first_name;?>"name="address_first_name"type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_last_name">Last name:</label></td>
				<td>
					<input class="form-control" value="<?php echo$address->address_last_name;?>" id="id_first_name" name="address_last_name"type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_phone">Phone:</label></td>
				<td>
					<input class="form-control" value="<?php echo$address->address_phone;?>" id="id_phone" name="address_phone" type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_address_line_1">Address:</label></td>
				<td>
					<textarea name="address_address" id=""class="form-control" cols="30" rows="10"required ><?php echo $address->address_address;?></textarea>
				</td>
			</tr>
			
			<tr>
				<td style="width: 175px;">
					<label for="id_state">Area:</label></td>
				<td>
					<select class="form-control" id="id_state" name="address_area" required>
					<?php $area=$address->address_area;?>
						<option value="<?php echo$area;?>" selected><?php echo$area;?></option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
				<br /> 
				
				<?php 
				if($this->session->userdata('custmrLogin'))
				{
					$custommerId=$this->session->userdata('active_customer');
				}
				$this->load->helper('url');
				$currentURL = current_url();
				//print_r($currentURL);
				?>
				
					<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
					<input type="hidden" name="address_customerId" value="<?php echo$custommerId;?>" />
				
					
				</td>
			</tr>
   
   
   
   
   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Update" />
      </div>
	  
	  </form>
    </div>
  </div>
  
  
  
  
  <?php }?>
  
</div>
		 	<?php 
			
			
			if($this->session->userdata('address_id')==true && $this->session->userdata('paymentMethod')==false && $this->session->userdata('custmrLogin')==true)
			{
				
				
				?>
			
			
			  <div class="panel panel-info">
			  <div class="panel-heading"><h4>Payment Information</h4></div>
			  <div class="panel-body">
							
							   <form action="<?php echo base_url('checkout/setPaymentMethod')?>" method="POST">
									
										<input type="radio" name="paymentType" value="COD"checked> <b>CASH ON DELIVERY</b>
										
									
										<br />
										<br />
									
										<input type="radio" name="paymentType" value="SSL"> <b>Payment with Debit/Visa/Mastercard/DBBL/Rocket/other Bank etc <img src="<?php echo base_url()?>/assets/front-end/images/sslcz-verified.png" alt="card payment"></b>
									
										<br />
										<br />
										
									 
					 <div class="text-right">			 
									 
				<input type="hidden" name="payMethod" value="setPaymentMethod"/>
				<input type="submit"class="btn btn-primary" value="Next >>" />
									 
					</div>			 
									 
									 
									 
									 
									 
									
								</form>
							
			  </div>
			</div>
					
			 <br />
			 <br />
			 <br />
			 <br />
			 <br />
			 <br />
			 <br />
			 <br />
			 
					
			<?php 
			}
			else 
			{
				echo"";
			}
			?>		
			
			
			<?php 
			if($this->session->userdata('paymentMethod')==true && $this->session->userdata('custmrLogin')==true)
			{
				?>
				
		
			<div class="panel panel-info">
			  <div class="panel-heading"><h4>Order Summary</h4></div>
			  <div class="panel-body">
							
						
						
						
						<div class="col-md-12"> 
							<div class="panel panel-default">
									<div class="panel-heading">
									<h1 class="panel-title"><b>Set Preferred Delivery Schedule</b></h1>
									</div>
									<div class="panel-body">
									<?php 
									$customer_id=$this->session->userdata("active_customer");
									?>
									<form action=""method="POST">
											<div class="col-lg-3"> 
											<p>Date: <input style="background:white"type="text" name="deliveryDate"class="form-control"id="datepicker"  autocomplete="off" readonly ></p>
										
										
									
											
<script>
  $( function() {
    $( "#datepicker" ).datepicker({ minDate:0, maxDate: "6D",dateFormat: 'dd/mm/yy' });
  } );
  </script>										
											
<script> 
											
	$(function() {
    //$("#datepicker").datepicker();
    $("#datepicker").change(function() {
		
        var selectedDate = $(this).val();
		//alert(selectedDate);
		
		
		
var d = new Date();
var hours=d.getHours();
var date = d.getDate();
var month = d.getMonth() + 1; // Since getMonth() returns month from 0-11 not 1-12
var year = d.getFullYear();
 
//var dateStr ="0"+date+"/"+"0"+month+"/"+year;
var dateStr =date+"/"+"0"+month+"/"+year;
//var inputDate="10/12/2019";

//alert(dateStr);

if(selectedDate==dateStr)
{
//	alert("Inside...Date matched");
	//document.write("Date matched");
	
	if(hours>=9 && hours<=10)
	{
	
		var data="<option value='11to1' selected > 11:00 AM - 1:00 PM</option><option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5'> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=11 && hours<=12)
	{
	
		var data="<option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5'> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=13 && hours<=14)
	{
	
		var data="<option value='3to5' selected> 3:00 PM - 5:00 PM</option><option value='3to5'> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	
	else if(hours>=15 && hours<=16)
	{
	
		var data="<option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=17 && hours<=18)
	{
		var data="<option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=19 && hours<=20)
	{
		var data="<option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	
	
}
else 
{	
    
    //var data="<option value='9to11' selected >input date not matched with system date</option>";
	var data="<option value='9to11' selected >9:00 AM - 11:00 AM</option><option value='11to1' > 11:00 AM - 1:00 PM</option><option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5' > 3:00 PM - 5:00 PM</option><option value='5to7'> 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
	//$("#deliverySlot").text(data);
	document.getElementById("deliverySlot").innerHTML=data;	
}
});
	
});					

</script>
											
</div>							
									
									
										<div class="col-lg-3"> 
										<span>Schedule</span> 
											<select class="form-control" name="deliverySlot" id="deliverySlot"> 
											
											
											</select>
										</div>
											
											
											
										
										<div class="col-lg-3"> 
										<br />
										<input type="hidden" name="customerId" value="<?php echo$customer_id;?>" />
										<input type="submit" class="btn btn-primary"name="schedule" value="Apply Schedule" />
										
										</div>
								</form>
								
									</div>
									<br />
									
							</div>	
						</div>	
						
						
						


			
							
									<br />
								<h2>Order Summary</h2> <br />
								
								<div class="table-responsive">
								
								
								<table class="table table-bordered">
								<thead>
								  <tr style="background:#923EFF;color:white">
									<th>Item(s)</th>
									<!--<th>Image</th>-->
									<th>Unit Price</th>
									<th>Qty</th>
									<th>Sub Total</th>
								  </tr>
								</thead>
		<?php 						
		
		foreach ($this->cart->contents() as $items) {
			
		?>
								<tr> 
									
									
									
									<td><?php echo $items['name'];?></td>
									
								<!--	<td><img src="<?php //echo$items['image']; ?>" alt="product image" width="90"height="70" /></td> -->
									<td>TK <?php echo $items['price'];?></td>
									<td><?php echo $items['qty'];?></td>
									<td>TK <?php echo number_format($items['subtotal'],2);?></td>
								</tr>
								
							<?php 
							}
							?>
								<tr> 
									
									<td colspan="3" align="right"><b>Sub-Total</b></td>
									<td>TK <?php echo number_format($this->cart->total(),2)?></td>
								</tr>
								
								
								
								<tr> 
									
									<td colspan="3" align="right"><b>Delivery Charge</b></td>
									<td>TK 0.00</td>
								</tr>
								
			<?php 
			
			if($this->session->userdata('applcopn_code') !== null)
			{
				
				$coupon_code=$this->session->userdata('applcopn_code');
				$this->load->model('Coupon_model');
				//$cnp_applied=$this->Coupon_model->customer_has_applied_coupon($coupon_code);
				$cnp_applied= $this->Coupon_model->customer_has_applied_coupon($coupon_code);
				if($cnp_applied==true)
				{
					if($cnp_applied['coupon_discount_type']==1)
					{
						$disAmount=$cnp_applied['coupon_discount_amount'];
					}
					else 
					{
						$main_price=$this->cart->total();
						$disAmount=($main_price / 100) * intval($cnp_applied['coupon_discount_price']);
					}
				}
				
				?>
				<tr> 
									
					<td colspan="3" align="right"><b>Applied Coupon</b></td>
					<td><?php echo$coupon_code;?></td>
				</tr>
				<tr> 
									
					<td colspan="3" align="right"><b>Coupon Discount</b></td>
					<td>TK <?php echo number_format($disAmount,2);?></td>
				</tr>
				<tr> 
									
					<td colspan="3" align="right"><b>Order Total</b></td>
					<td>TK <?php $grndTotal=($this->cart->total()-$disAmount+0);
						echo number_format($grndTotal,2)
					?></td>
				</tr>
				
				<?php 
			}
			else 
			{
			?>
								
								
								
								<tr> 
									
									<td colspan="3" align="right"><b>Order Total</b></td>
									<td>TK <?php  $grndTotal=($this->cart->total()+0);
										echo number_format($grndTotal,2)
									?></td>
								</tr>
			
			<?php }?>					
								
								</tbody>
							  </table>
							  
							  
					</div>		  
							  
							  
							  
							  
							  
							  
							  
							  
							
						<div class="row"> 
							<div class="col-md-7"> 
							
								<div class="panel panel-primary">
								<div class="panel-heading">
								<h1 class="panel-title">Delivery Information</h1>
								</div>
								<div class="panel-body">
								<?php 
								$this->load->model('customer_model');
								$cust_id=$this->session->userdata("active_customer");
		
	$address_id=$this->session->userdata("address_id");							$customer_address=$this->customer_model->fetchCustomerAddressById($cust_id);
								 foreach($customer_address as $address)
								 {
									 $add_id=$address->address_id;
									 if($add_id==$address_id){
								 ?>
								<strong>Name: </strong><?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?><br /> 
								<strong>Contact: </strong> <?php echo$address->address_phone;?> <br /> 
								<strong>Address: </strong> <?php echo$address->address_address;?> <br /> 
								<strong>Area: </strong> <?php echo$address->address_area;?><br /> 
								
								<?php 
								}
									 else 
									 {
										 echo"";
									 }
									 }
								?>
								<strong>Preferred Delivery Schedule:</strong> 
								<input type="hidden" name="address_id" value="<?php echo$address->address_id;?>"/>
								
								
								<?php 
									 
								if(isset($_POST['schedule']))
								{
									$deliverDate=$_POST['deliveryDate'];
									$deliverSlot=$_POST['deliverySlot'];
									if($deliverSlot=='9to11')
									{
										$slot='9am to 11am';
									}
									else if($deliverSlot=='11to1')
									{
										$slot='11am to 1pm';
									}
									else if($deliverSlot=='1to3')
									{
										$slot='1pm to 3pm';
									}else if($deliverSlot=='3to5')
									{
										$slot='3pm to 5pm';
									}
									else if($deliverSlot=='5to7')
									{
										$slot='5pm to 7pm';
									}
									else if($deliverSlot=='7to9')
									{
										$slot='7pm to 9pm';
									}
									
									
									echo$deliverDate." <b>Within</b> ".$slot;
								}
								else 
								{
									echo"Not specified.";
								
								}
								?><br /> 
								 
								<input type="hidden" name="deliveryDate" value="<?php echo@$deliverDate;?>" />
								<input type="hidden" name="deliverySlot" value="<?php echo@$slot;?>" />
								</div>
								</div>
							</div>
							<div class="col-md-5"> 
								<div class="panel panel-primary">
								<div class="panel-heading">
								<h1 class="panel-title">Payment Information</h1>
								</div>
								<div class="panel-body">
									<table class="table table-bordered">
										<tbody>
										  <strong>Payment Method: </strong> <br />  
											<?php 
											$payMethod=$this->session->userdata('paymentMethod');
											if($payMethod=="COD")
											{
												?>
												<img src="<?php echo base_url()?>/assets/front-end/images/cod.png" alt="Cash on Delivery payment" width="200px" height="100px">
											
											<?php 
											}
											else if($payMethod=="SSL")
											{
												?>
												<img src="<?php echo base_url()?>/assets/front-end/images/ssl.png" alt="Card payment" width="200px" height="100px">
												<?php 
											}												
												
											?>
											
										
										
											
										
										  
										</tbody>
									  </table>
								
								
								
								</div>
								</div>
							</div>
							
							<br />
							<br />
							
							
							
						</div>	
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  <?php 
											
							if($payMethod=="SSL")
							{
							?>
							<h2 style="color:coral">Do you want to pay now?</h2> <br />
							
							<form action="<?php echo base_url()?>requestssl" method="POST">
							    
							
							<img src="<?php echo base_url()?>assets/front-end/images/SSLCommerz-logo.png" alt="">
							
							<br />
							<br/>
							<br/>
						
							
							<table>
                				<tr>
                				
                					<td><input type="hidden" name="fname" required class="tbox" autofocus placeholder="Name" value="<?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?>"></td>
                				</tr>
                				<?php 
                				
                				$this->load->model('customer_model');
								$cust_id=$this->session->userdata("active_customer");
		
								$customer_info=$this->customer_model->fetchCustomerById($cust_id);
								 foreach($customer_info as $cus)
								 {
                				?>
                				
                				<tr>
                				
                					<td><input type="hidden" name="email" required class="tbox" placeholder="Email" value="<?php echo $cus->email; ?>"></td>
                				</tr>
                				<?php 
								 }
                				?>
                				
                				<tr>
                			
                					<td><input type="hidden" name="phone" required class="tbox" placeholder="Phone" value="<?php echo$address->address_phone;?>"></td>
                				</tr>
                				
                				
                			<!--
                				<tr>
                				
                					<td><input type="text" name="amount" required value="5.00" class="tbox" placeholder="Amount"></td>
                				</tr>
                			-->
                				
                				<tr>
                				
                					<td><input type="hidden" name="country" required class="tbox" placeholder="Country" value="Bangladesh"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="address" required class="tbox" placeholder="Address" value="<?php echo$address->address_address;?>"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="street" required class="tbox" placeholder="Street Address" value="<?php echo$address->address_area;?>"></td>
                				</tr>
                				<tr>
                				
                					<td><input type="hidden" name="state" required class="tbox" placeholder="State" value="<?php echo$address->address_area;?>"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="city" required class="tbox" placeholder="City" value="Dhaka"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="postcode" required class="tbox" placeholder="Post Code" value="1208"></td>
                				</tr>
                			
                			</table>
                			
                			
                			<?php //echo$this->cart->total_items()?>
     <input type="hidden" name="address_id" value="<?php echo$address->address_id;?>"/>          			
     			
    <input type="hidden" name="deliveryDate" value="<?php echo@$deliverDate;?>" />
	<input type="hidden" name="deliverySlot" value="<?php echo@$slot;?>" />           			
    <input type="hidden"name="cartTotal" value="<?php echo$this->cart->total();?>" />
	<input type="hidden"name="delivery_cost" value="0" />
	<input type="hidden"name="coupon_code" value="<?php echo@$coupon_code;?>" />
	<input type="hidden"name="coupon_discount_amount" value="<?php echo@$disAmount;?>" />
	<input type="hidden"name="grandTotal" value="<?php echo $grndTotal;?>" />
	 <input type="hidden" name="items" value="<?php echo$this->cart->total_items();?>"/> 					
							
	
	
	
	
	 <?php 
	 if($grndTotal<260)
	 {
		 ?>
		 <span style="color:red;font-size:15px">Minimum order amount is Tk 200 </span>
		 <input type="button" value="Pay & confirm Order Now" class="btn btn-primary btn-block disabled">
		 <?php 
	 }
	 else 
	 {
	 ?>
		 <small>Please agree with our <a href="<?php echo base_url('page/terms-conditions');?>"><b>terms and conditions</b></a> before placing an order.</small>
					
	<input type="submit" name="submit" value="Pay & confirm Order Now" class="btn btn-primary btn-block">
	
	<?php 
	 }
	?>
	
	
	
	
	
	<!--<a href="<?php //echo base_url()?>requestssl" class="btn btn-danger btn-block">Pay & confirm Order Now</a> -->
							
					<br />
					<br />
					<br />
					<br />
							
							</form>
							
							
							<?php 
							    
							    
							}   
							else 
							{
							
							?>
							   
							  
		<form action="<?php echo base_url('order/confirmOrder')?>" method="POST">					  
							  
								
	<br />
	<?php 
	$payMethod=$this->session->userdata('paymentMethod');
	?>
	
	
	<input type="hidden" name="address_id" value="<?php echo$address->address_id;?>"/>          			
     			
    <input type="hidden" name="deliveryDate" value="<?php echo@$deliverDate;?>" />
	<input type="hidden" name="deliverySlot" value="<?php echo@$slot;?>" />           			
    <input type="hidden"name="cartTotal" value="<?php echo$this->cart->total();?>" />
	<input type="hidden"name="delivery_cost" value="0" />
	<input type="hidden"name="coupon_code" value="<?php echo@$coupon_code;?>" />
	<input type="hidden"name="coupon_discount_amount" value="<?php echo@$disAmount;?>" />
	<input type="hidden"name="grandTotal" value="<?php echo $grndTotal;?>" />
	
	
	
	<?php 
	 if($grndTotal<260)
	 {
		 ?>
		 <span style="color:red;font-size:15px">Minimum order amount is Tk 200 </span>
		 <input type="button" class="btn btn-danger btn-block disabled" value="Confirm Order"/>
		 <?php 
	 }
	 else 
	 {
	 ?>
	 
	 
  <small>Please agree with our <a href="<?php echo base_url('page/terms-conditions');?>"><b>terms and conditions</b></a> before placing an order.</small>
		
							
	<input type="submit" class="btn btn-danger btn-block" value="Confirm Order"/>
	
	<?php 
	 }
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			 
							
		</form>			
					<br />
					<br />
					<br />
					<br />
					
			<?php 
							}
			
			?>		
					
                </div>
			
                </div>
                
                
         <!--       
		</form>
		
		-->
			<?php 
			}
			else 
			{
				echo"";
			}
			?>
			
			
			
		 </div>	
			
		 </section>
        <!-- End Feature Product -->
			
			
			
			
			
			
			
	 <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
			
			
			