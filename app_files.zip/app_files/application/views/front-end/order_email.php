<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Shombhob.com Order Details</title>
	
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	
</head>
<body>
<div class="container">

<?php 
$order_id=$this->session->userdata('payer_order');
$this->load->model('dashboardOrder_model');
$orderInfo=$this->dashboardOrder_model->getSingleOrderById($order_id);

foreach($orderInfo as $order){
	$orderID=$order->order_id;
	//$customerID=$order->order_customerid;
	$cusAddressID=$order->order_addressid;
	$inv=$this->dashboardOrder_model->fetchInvoiceByOrderId($orderID);
	$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($cusAddressID);
	$orderDetails=$this->dashboardOrder_model->fetchOrderDetailsByOrderId($orderID);
	
	?>
	
		<div class="row"> 
		<table class="table table-stripped">
			<tr>
			
				<div class="col-md-9"> 
				<td><a href="https://shombhob.com" target="_blank"><img src="<?php echo base_url('assets/front-end/images/logo/shombhob_logo.jpg')?>" width="150px" height="60px"alt="logo" /></a></td>
				</div>
				
				<div class="col-md-3"> 
				<td align="right"> <br />Helpline &nbsp;&nbsp;: +8801755697233 <br />Email&nbsp;&nbsp;: info@shombhob.com</td>
				</div>
				
				
			</tr>
		</table>
		
		</div>
		
		<br/>	<br/>
		
		
		
			<b>Hello <?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?>! <?php } else { echo$cus['name'];}?>!</b>
			<span>Thank you for shopping with us. Please find your order summary below.</span> <br /> <span>As always, shombhob.com remains at your service. </span>
			<br /><br />
			<b>shombhob.com</b> Team.
			
			
		
		<div class="row"> 
		
		<div class="col-md-12"> <center><h3>Delivery Information</h3></center></div> <br />
		</div>
		
		<div class="row"> 
		<br />
			<table width="100%">
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Name:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?> <?php } else { echo$cus['name'];}?></td>
					<td align="right"><b>Order Date:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$order->order_date;?></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Address:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_address'];?></td>
					<td align="right"><b>Order Number:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$order->order_number;?></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Area:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_area'];?></td>
					<td align="right"><b>Payment Method:</b></td>
					<td align="left">&nbsp;&nbsp;<?php 
					        //$paymentChannel=$order->paymentChannel;
            				$p_method=$order->order_payment_method;
            				if($p_method=="COD")
            				{
            					echo"Cash On Delivery";
            				}
            				else if($p_method=="SSL")
            				{
            					echo"SSL Commerz Payment Method";
            				}
            				?>
            		</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Phone No.:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_phone'];?></td>
					<td align="right"><b>Payment Status:</b></td>
					<td align="left">&nbsp;&nbsp;
    					<?php 
    					$trnxID=$order->order_payment_trnx_id;
    					if($p_method=="COD")
    					{
    					   echo$order->order_payment_status; 
    					}
    					else if($order->order_payment_status=="Processing" || $order->order_payment_status=="Paid"|| $order->order_payment_status=="PAID")
    					{
    					    echo"Paid(TransactionID: $trnxID)";
    					}
    					else 
    					{
    					    echo$order->order_payment_status;
    					}
    					?>
					
					</td>
					<td></td>
					<td></td>
				</tr>
				
			
				
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Preferred Delivery Schedule:</b></td>
					
					<td align="left"> <?php echo $order->order_delivery_date;?> <b> Within </b> <?php echo $order->order_delivery_slot;?>.</td>
					<td align="right"><b>Delivery Status:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$order->order_delivery_status;?></td>
					<td></td>
					<td></td>
				</tr>
			</table>
		
		
		</div>
		
		<div class="row"> 
			
			<div class="col-md-12"> <center><h3>Order Details</h3></center></div> 
		</div>
		
		<div class="row"> 
		<br />
			<table width="100%" class="table table-bordered table-hover">
				<tr style="background:#EBCAFE">
					<td align="center"><b>SL No.</b></td>
					<td align="center"><b>Item</b></td>
					<td align="center"><b>Quantity</b></td>
					<td align="right"><b>Unit Price</b></td>
					<td align="right"><b>Total</b></td>
				</tr>
	<?php 
		$sl=0;
		foreach($orderDetails as $details){
		$itemID=$details->details_item_id;
		$sl++;
		
		$products=$this->dashboardOrder_model->fetchOrderedProductsById($itemID); 
		
		foreach($products as $product){
		
		 //$this->load->model('product_model');
		 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
		 $proImage = $get_default_photo['image_url'];
		
	?>
	
	 <tr>
		<td align="center"><?php echo$sl;?></td>
		<td align="left"><?php echo$product->title;?></td>
		<td align="center"><?php echo$details->details_item_quantity;?></td>
		<td align="right">Tk <?php echo$details->details_item_unitprice;?></td>
		<td align="right">Tk <?php echo$details->details_item_subtotal;?></td>
	</tr>
	  
	  <?php 
		}
		}
	  ?>
	
	
	
				
				
				<tr>
					<td align="right"colspan="4"><b>Sub Total</b>:</td>
					<td align="right">Tk <?php echo$order->order_total_amount;?> </td>
				</tr>
				<?php $apply_coupon=$order->order_applied_coupon;
				  if($apply_coupon)
				  {
					  ?>
				<tr>
					<td align="right"colspan="4"><b>Applied Coupon:</b></td>
					<td align="right"><?php echo$order->order_applied_coupon;?></td>
				</tr>
				<tr>
					<td align="right"colspan="4"><b>Coupon Discount (TK):</b></td>
					<td align="right"><?php echo$order->order_coupon_discount;?></td>
				</tr>
					  <?php 
				  }
				  ?>
				<tr>
					<td align="right"colspan="4"><b>Delivery Charge</b>:</td>
					<td align="right">Tk <?php echo$order->order_delivery_cost;?> </td>
				</tr>
				<tr>
					<td align="right"colspan="4"><b>Grand Total</b>:</td>
					<td align="right">Tk <?php echo$order->order_grand_total;?> </td>
				</tr>
				
				
			</table>
		
		<br /><br />
		</div>
		
		<div class="row"> 
		
			<br />
			<br />
			<br />
			<div class="col-md-12"> <center><p>Copyright &copy; Shombhob.com <?php echo date('Y');?>-All Rights Reserved.</p>
			<!--
			<img src="<?php //echo base_url('uploads/customer_invoice_banner.jpg')?>" alt="" width="60%" height="250"/>
			-->
			
			</center></div>
		</div>
		
		<?php 
}
		?>

</div>

	
  <!-- JavaScript: placed at the end of the document so the pages load faster -->
  <!-- JQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  
</body>
</html>