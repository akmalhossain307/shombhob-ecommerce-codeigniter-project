
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style">
						<div id="searchResult"></div> <!--Search result will be listed here-->
					</div>
					
				
                    <!-- Start Left Feature -->
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style" id="hidden4SearchResult">
					
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url()?>">Home</a></li>
						<?php 
						$this->load->helper('url');
						$currentURL = current_url();
						
						?>
						
						<li><a href="<?php echo$currentURL;?>">product Details</a></li>       
					</ol>
                  
                        
      <?php 
	  foreach ($offerProductDetails as $detail)
			{
				?>
				
				
                        <div class="modal-product">
                            
							<!-- Lets make a simple image magnifier -->
							<div class="magnify">
								
								<!-- This is the magnifying glass which will contain the original/large version -->
								<div class="large">
								</div>
								
								<!-- This is the small image -->
								<?php $imgURL=$detail->productImage;?>
								<img class="small" src="<?php echo base_url().$imgURL;?>" width="200"/>
								
							</div>
							
							
                            <!-- end product images -->
                            <div class="product-info">
							
							<h1><?php echo $detail->title;?></h1> <br />
								<span><?php echo $detail->shortDescription;?> </span>
                               
                                <div class="price-box-3">
                                    <div class="s-price-box">
									<span><b>Pack size :</b> <?php echo $detail->measuringType;?></span> <br />
									<span><b>MRP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</b> <?php if($detail->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $detail->price;?></del> TK <?php echo$detail->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$detail->price;?>
												
												<?php 
												}
												?></span> <br />
									<span><b>Delivery &nbsp;&nbsp; : Inside Dhaka</b>-Within 6 hours </span> <br />
									 
									 
										<div class="input-group col-md-8">
										<span><b>Order Qty  :</b></span> <br />
										  <span class="input-group-btn">
											  <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												  <span class="glyphicon glyphicon-minus"></span>
											  </button>
										  </span>
										  <input type="hidden" id="product_price" value="<?php 
													if($detail->discountPrice)
													{
													$price=$detail->discountPrice;
													}
													else 
													{
													$price=$detail->price;	
													}
													echo$price;?>" />
										
										  <input style="margin-top:8px"type="text" name="quant[1]" class="form-control input-number" value="1" id="qty" min="1" max="1000" size="5"  onchange="calculateAmount(this.value)">
										  
										  
										  
										  <span class="input-group-btn">
											  <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[1]">
												  <span class="glyphicon glyphicon-plus"></span>
											  </button>
										  </span>
									  </div>
							
									  <span id="ItemsTotal"></span>
									 
								  <script type="text/javascript">
									function calculateAmount(val) {
										
										var price=document.getElementById('product_price').value;
										var qty=val;
										document.getElementById("itemQTY").value=qty;
										var tot_price = val * price;
										/*display the result*/
										//var divobj = document.getElementById('tot_amount');
										//divobj.value = tot_price;
										document.getElementById("ItemsTotal").innerHTML = "<b style='color:coral'>"+"Total:"+"</b>"+ " Tk "+tot_price;
									}
									
								  </script>
								 
										<br />
				<form action="<?php echo base_url('product/offer_add_cart');?>" method="POST" enctype="multipart/form-data">
							
										<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									
									?>
									<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
									<input type="hidden" name="offer_id"value="<?php echo$detail->offer_id;?>" />
									<input type="hidden" name="offer_name"value="<?php echo$detail->title;?>" />
									<input type="hidden"name="offer_image"value="<?php echo base_url().$imgURL;?>" />
									 <input type="hidden" name="offer_price"id="product_price" value="<?php 
													if($detail->discountPrice)
													{
													$price=$detail->discountPrice;
													}
													else 
													{
													$price=$detail->price;	
													}
													echo$price;?>" />
										<input type="hidden" name="offer_old_price" value="<?php echo$detail->price;?>"/>			
									
								<input type="hidden"name="quantity"id="itemQTY" />
								<input type="submit" name="submit"class="btn btn-primary" value="Add To Cart"/>
								
									
										 &nbsp;&nbsp;&nbsp;
										<a href="#" class="btn btn-info"> Add to Favourite</a>&nbsp;&nbsp;&nbsp;
										<a href="<?php echo base_url('checkout')?>" class="btn btn-success"> Finish Shopping</a>
									
									</form>

									
                                        
                                    </div>
                                </div>
                                
                                <br />
                               
                                
                                <div class="social-sharing">
                                    <div class="widget widget_socialsharing_widget">
                                        <h3 class="widget-title-modal"><b>Share this product</b></h3>
                                        <ul class="social-icons">
                                          <li><a href="#" target="_blank"><i class="zmdi zmdi-facebook"></i></a></li>
											
                                            <li><a target="_blank" title="Linkedin" href="#" class="linkedin social-icon"><i class="zmdi zmdi-linkedin"></i></a></li>
                                            <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="zmdi zmdi-pinterest"></i></a></li>
                                            <li><a target="_blank" title="Tumblr" href="#" class="tumblr social-icon"><i class="zmdi zmdi-tumblr"></i></a></li>
                                            <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="zmdi zmdi-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
								
                            </div><!-- .product-info -->
							
                        </div><!-- .modal-product -->
						
						
								<ul class="nav nav-tabs text-center">
									<li class="active"><a data-toggle="tab" href="#home" class="btn btn-info">Description</a></li>
									<li><a data-toggle="tab" href="#menu1" class="btn btn-success">Additional Information</a></li>
									<li><a data-toggle="tab" href="#menu2" class="btn btn-warning">Reviews</a></li>
									
								  </ul>
								

								  <div class="tab-content">
									<div id="home" class="tab-pane fade in active">
									  <br />
									
									  <?php echo $detail->productDescription;?>
									</div>
									<div id="menu1" class="tab-pane fade">
									  
									   <?php echo $detail->additionalInfo;?>
									</div>
									<div id="menu2" class="tab-pane fade">
									  
									  review...
									</div>
									
								  </div>
								  
								  
								 
						
						
                   <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">				
    <div class="product-tab-list" id="tabList">
        <span style="text-transform:uppercase;font-size:18px;"> Similar Products    
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a data-slide="prev" href="#myCarousel" class=""><i class="zmdi zmdi-chevron-left"></i></a>
		&nbsp;&nbsp;&nbsp;<a data-slide="next" href="#myCarousel" class=""><i class="zmdi zmdi-chevron-right"></i></a>
		</span>
		<span class="text-right"> 
			
					
				
		</span>		
    </div>    
    <div class="carousel slide" id="myCarousel">
        <div class="carousel-inner">
						<div class="item active">
			
									<?php 
									$this->load->model('Product_model');
									$products=$this->product_model->fetchPopularProduct1(); 
									if($products)
									{
									foreach($products as $product){
									?>	
										<div class="col-lg-3 col-sm-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"> <img src="<?php echo base_url().$product->productImage;?>" alt=""> </a>
                                                <?php 
												$att=$product->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="featured")
												{
												echo"<h5 class='sale'>Featured</h5>";	
												}else if($att=="hot")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="normal")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="new")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}
												?>
                                                
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
                                                    <li class="p_icon"><a  title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"><span class="ti-plus"></span></a></li>
                                                    <li>
													
													
													<button class="add_cart_btn" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productimage="<?php echo base_url().$product->productImage;?>" data-productprice="<?php 
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
													
												
													
													</li>
                                                    <li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									
									}
									}
									?>
			
			
              </div><!-- /Slide1 --> 
            <!-- /Slide1 --> 
           
		   
						<div class="item">
			
									<?php 
									$this->load->model('Product_model');
									$products=$this->product_model->fetchPopularProduct1(); 
									if($products)
									{
									foreach($products as $product){
									?>	
										<div class="col-lg-3 col-sm-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a  class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"> <img src="<?php echo base_url().$product->productImage;?>" alt=""> </a>
                                                <?php 
												$att=$product->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="featured")
												{
												echo"<h5 class='sale'>Featured</h5>";	
												}else if($att=="hot")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="normal")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="new")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}
												?>
                                                
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
                                                    <li class="p_icon"><a class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$product->product_id;?>"><span class="ti-plus"></span></a></li>
                                                    <li>
													
													
													<button class="add_cart_btn" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productimage="<?php echo base_url().$product->productImage;?>" data-productprice="<?php 
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
													
												
													
													</li>
                                                    <li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									
									}
									}
									?>
			
			
              </div><!-- /Slide1 -->
			
            <!-- /Slide2 --> 
            
        </div>
        
       
	   
	   <!-- /.control-box -->   
                              
    </div><!-- /#myCarousel -->
        
</div><!-- /.col-xs-12 -->          

</div><!-- /.container -->
		
		
</section>	
	
				   
				   
				   
				   
				   
					
				
				
				<?php 
			}
			?>
	  
	  
	  
	  
    </div>
                    <!-- End Left Feature -->
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        
        
        
        
        
        
         <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->