
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
				
					
				
                    <!-- Start Left Feature -->
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style" id="hidden4SearchResult">
					
					<ol class="breadcrumb">
						<li><a href="<?php echo base_url()?>">Home</a></li>
						<?php 
						$this->load->helper('url');
						$currentURL = current_url();
						
						?>
						
						<li><a href="<?php echo$currentURL;?>">Product details</a></li>       
					</ol>
					
				<?php if($this->session->flashdata('wishlistSuccess')){ ?>
				<div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('wishlistSuccess'); ?></strong>
				</div>
				<?php }
				else if($this->session->flashdata('wishlistError')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('wishlistError'); ?></strong>
				</div>
				
				<?php };?>	
                  
                        
      <?php 
	  
		
	  
	  foreach ($productDetails as $detail)
			{
		$this->load->model('Product_model');
		$get_default_photo = $this->product_model->get_default_photo($detail->product_id);
		$proImage = $get_default_photo['image_url'];
				
			$productCatId=$detail->product_parentcat_id;	
			$productSubCatId=$detail->subcat_id;	
				?>
				
				
                       
                        
                        
                         <div class="modal-product">
                            
							<!-- Lets make a simple image magnifier -->
							<div class="magnify">
								
								<!-- This is the magnifying glass which will contain the original/large version -->
								<div class="large">
								</div>
								
								<!-- This is the small image -->
								<?php //$imgURL=$detail->productImage;?>
								<img class="small" src="<?php echo base_url().$proImage;?>" width="300"/>
								
							</div>
							
							
                            <!-- end product images -->
                            <div class="product-info">
							
							<h1><?php echo $detail->title;?></h1> <br />
								<span><?php echo $detail->shortDescription;?> </span>
                               
                               
                               
                               
                                <div class="price-box-3">
                                    <div class="s-price-box">
									<span><b>Pack size :</b> <?php echo $detail->measuringType;?></span> <br />
									<b>MRP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</b> <span style="font-family: 'Times New Roman',serif;"><?php if($detail->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $detail->price;?></del> TK <?php echo$detail->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$detail->price;?>
												
												<?php 
												}
												?></span> <br />
									<span><b>Delivery &nbsp;&nbsp; : Inside Dhaka</b>-Within 6 hours </span> <br />
									<?php
									$qty=$detail->product_quantity;
									if($qty<=0)
									{
									?>
									<span> &nbsp;&nbsp;<h4 style="color:red">Product Out of stock </h4></span> <br />
									<?php 
									}
									?>
							<?php 

                            $pres=$detail->product_need_prescription;
                            $type=$detail->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
									<span style="color:red"><b>This medicine requires prescription to buy.</b></span> <br />
							<?php 
                            }
							?>		
							
							
							
							            <span> 
										  <?php 
										  /*
										  $qty=$detail->product_quantity;
										  if($qty>0)
										  {
										  echo"<span style='color:red'>".$qty." product(s) available.";
										  }
										  */
										  ?>
										  
										  </span> 
							
									 
										<div class="input-group col-md-6">
										    
										   
										  
										<span><b>Order Qty  :</b></span> <br />
										  
										
										  <span class="input-group-btn">
											  <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
												  <span class="glyphicon glyphicon-minus"></span>
											  </button>
										  </span>
										
										  <input type="hidden" id="product_price" value="<?php 
													if($detail->discountPrice)
													{
													$price=$detail->discountPrice;
													}
													else 
													{
													$price=$detail->price;	
													}
													echo$price;?>" />
													
													<?php
        									$qty=$detail->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
        									    
        									    
        					<input style="margin-top:8px"type="text" class="form-control" value="0" size="2" readonly >
        									    
        									  <?php   
        									}
        									else 
        									{
        									?>
										
										  <input style="margin-top:8px;"type="text" name="quant[1]" class="form-control input-number" value="1" id="qty" min="1" max="<?php if($detail->product_id==2664 || $detail->product_id==7406 || $detail->product_id==2664){echo"3";} else{echo"100";}?>" size="2"  onchange="calculateAmount(this.value)">
										  <?php 
        									}
										  ?>
										  
										  
										  <span class="input-group-btn">
											  <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[1]">
												  <span class="glyphicon glyphicon-plus"></span>
											  </button>
										
										  
										  </span>
								
										  
										  
									  </div>
							
									  	 <span id="ItemsTotal"></span>
									 
								  <script type="text/javascript">
									function calculateAmount(val) {
										
										var price=document.getElementById('product_price').value;
										var qty=val;
										document.getElementById("itemQTY").value=qty;
										var tot_price = val * price;
										/*display the result*/
										//var divobj = document.getElementById('tot_amount');
										//divobj.value = tot_price;
										document.getElementById("ItemsTotal").innerHTML = "<b style='color:coral'>"+"Total:"+"</b>"+ " Tk "+tot_price;
									}
									
								  </script>
								  
								  
								  
							<?php 


                    
                            $pres=$detail->product_need_prescription;
                            $type=$detail->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                            
                            
                            <div class="col-lg-3">		 
										<br />
				<form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">
							
										<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									
									?>
									<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
									<input type="hidden" name="product_id"value="<?php echo$detail->product_id;?>" />
									<input type="hidden" name="product_name"value="<?php echo$detail->title;?>" />
									<input type="hidden"name="product_image"value="<?php echo base_url().$proImage;?>" />
									 <input type="hidden" name="product_price"id="product_price" value="<?php 
													if($detail->discountPrice)
													{
													$price=$detail->discountPrice;
													}
													else 
													{
													$price=$detail->price;	
													}
													echo$price;?>" />
										<input type="hidden" name="product_old_price" value="<?php echo$detail->price;?>"/>			
									
								<input type="hidden"name="quantity"id="itemQTY" />
								
								<?php
        									$qty=$detail->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <input type="submit" name="submit"class="btn btn-primary" value="Add To Bag"/>
        									    <?php 
        									}
								
								?>
								
								</form>
							</div>
                            
                            
                            
                            <!--
                            <div class="col-lg-3">		 
										<br />
                            	<a href="#prescriptionUploadModal" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary" data-toggle="modal">Add to Bag</a>
                            
                            </div>
                            
                            -->
                            <?php 
                            }
                            else 
                            {
                            ?>	  
								  
								  
								  
								  
								 
						<div class="col-lg-3">		 
										<br />
				<form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">
							
										<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									
									?>
									<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
									<input type="hidden" name="product_id"value="<?php echo$detail->product_id;?>" />
									<input type="hidden" name="product_name"value="<?php echo$detail->title;?>" />
									<input type="hidden"name="product_image"value="<?php echo base_url().$proImage;?>" />
									 <input type="hidden" name="product_price"id="product_price" value="<?php 
													if($detail->discountPrice)
													{
													$price=$detail->discountPrice;
													}
													else 
													{
													$price=$detail->price;	
													}
													echo$price;?>" />
										<input type="hidden" name="product_old_price" value="<?php echo$detail->price;?>"/>			
									
								<input type="hidden"name="quantity"id="itemQTY" />
								
								<?php
        									$qty=$detail->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <input type="submit" name="submit"class="btn btn-primary" value="Add To Bag"/>
        									    <?php 
        									}
								
								?>
								
								</form>
							</div>
							
							<?php 
                            }
							?>
										
		<?php if($this->session->userdata('custmrLogin')){
		
		//$cus=$this->session->userdata('customr_name');
		
		?>
<div class="col-lg-3">

			
	
<br />							
	<form id="addWishList"action="<?php echo base_url('product/addToWishList');?>" method="POST" enctype="multipart/form-data">

			<?php 
		$this->load->helper('url');
		$currentURL1 = current_url();
		
		?>
		<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
		<input type="hidden" name="product_id"value="<?php echo$detail->product_id;?>" />
		<input type="hidden" name="product_name"value="<?php echo$detail->title;?>" />
		<input type="hidden"name="product_image"value="<?php echo base_url().$proImage;?>" />
		 <input type="hidden" name="product_price"id="product_price" value="<?php 
						if($detail->discountPrice)
						{
						$price=$detail->discountPrice;
						}
						else 
						{
						$price=$detail->price;	
						}
						echo$price;?>" />
			<input type="hidden" name="product_old_price" value="<?php echo$detail->price;?>"/>			
		
	<input type="hidden"name="quantity"id="itemQTY" />
	<input type="hidden"name="customer_id"value="<?php echo$this->session->userdata('active_customer')?>;" />
	<input type="submit" name="submit"class="btn btn-info" value="Add To Wishlist"/>
	
	</form> 
			 
</div>	 
										 
										 
										 
									
										
									<?php 
									}
									else 
									{
									?>
				<div class="col-lg-3">
<br />				
									<a href=""class="btn btn-info" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login or Create Account!"> Add to Wishlist</a>
									
					</div>				
									<?php 
									}
									?>
							<div class="col-lg-3">
							<br />
									<a href="<?php echo base_url('checkout')?>" class="btn btn-success"> Finish Shopping</a>
									
							</div>	
									

									
                                        
                                    </div>
                                </div>
                                
                                <br />
                                <br />
                                <br />
                               
                              <div class="col-lg-6"> 
							  <h4>Share this product on:</h4>
                               
                                   <div id="share" class="social-share-ics">
								   
								   <div class="jssocials-share jssocials-share-email"><a target="_self" href="mailto:?subject=<?php echo$detail->title;?>&amp;body=https://shombhob.com/productDetails/<?php echo$detail->product_id;?>" class="jssocials-share-link"><span class="jssocials-share-label">E-mail</span></a><div class="jssocials-share-count-box jssocials-share-no-count"><span class="jssocials-share-count"></span></div></div>
								   
								 <div class="jssocials-share jssocials-share-facebook"><a target="_blank" href="https://facebook.com/sharer.php?u=https://shombhob.com/productDetails/<?php echo$detail->product_id;?>" class="jssocials-share-link"><i class="zmdi zmdi-facebook"></i><span class="jssocials-share-label">Share</span></a><div class="jssocials-share-count-box jssocials-share-no-count"><span class="jssocials-share-count"></span></div></div>
								   
								   <!--
								   <div class="jssocials-share jssocials-share-twitter"><a target="_blank" href="https://twitter.com/share?url=https://shombhob.com/productDetails/<?php //echo$detail->product_id;?>&amp;text=<?php echo$detail->title;?>" class="jssocials-share-link"> <i class="zmdi zmdi-twitter"></i><span class="jssocials-share-label">Tweet</span></a><div class="jssocials-share-count-box jssocials-share-no-count"><span class="jssocials-share-count"></span></div></div>
								   
								   <div class="jssocials-share jssocials-share-linkedin"><a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&amp;url=https://shombhob.com/productDetails/<?php //echo$detail->product_id;?>" class="jssocials-share-link"><i class="zmdi zmdi-linkedin"></i><span class="jssocials-share-label">Share</span></a><div class="jssocials-share-count-box jssocials-share-no-count"><span class="jssocials-share-count"></span></div></div>
								   <div class="jssocials-share jssocials-share-pinterest"><a target="_blank" href="https://pinterest.com/pin/create/bookmarklet/?&amp;url=https://shombhob.com/productDetails/<?php// echo$detail->product_id;?>" class="jssocials-share-link"><i class="zmdi zmdi-pinterest"></i><span class="jssocials-share-label">Pin it</span></a><div class="jssocials-share-count-box jssocials-share-no-count"><span class="jssocials-share-count"></span></div></div>
								   
								  --> 
								   
								   
								   
								   
								   </div>
<script type="text/javascript">
	$("#share").jsSocials({
		shares: ["email", "twitter", "facebook", "googleplus", "linkedin", "pinterest"]
	});
</script>   

					<!--
                                        <ul class="social-icons">
										
                                            <li><a target="_blank" title="rss" href="#" class="rss social-icon"><i class="zmdi zmdi-rss"></i></a></li>
											
                                            <li><a target="_blank" title="Linkedin" href="#" class="linkedin social-icon"><i class="zmdi zmdi-linkedin"></i></a></li>
                                            <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="zmdi zmdi-pinterest"></i></a></li>
                                            <li><a target="_blank" title="Tumblr" href="#" class="tumblr social-icon"><i class="zmdi zmdi-tumblr"></i></a></li>
                                            <li><a target="_blank" title="Pinterest" href="#" class="pinterest social-icon"><i class="zmdi zmdi-pinterest"></i></a></li>
                                        </ul>
                                   -->
                                
                                </div>
								
                            </div><!-- .product-info -->
							
                        </div><!-- .modal-product -->
						
                        
                        
                        
                        
                        
						
						
								<ul class="nav nav-tabs text-center">
									<li class="active"><a data-toggle="tab" href="#home" class="btn btn-info">Description</a></li>
									<li><a data-toggle="tab" href="#menu1" class="btn btn-success">Additional Information</a></li>
									<li><a data-toggle="tab" href="#menu2" class="btn btn-warning">Reviews</a></li>
									
								  </ul>
								

								  <div class="tab-content">
									<div id="home" class="tab-pane fade in active">
									  <br />
									
									  <?php echo $detail->productDescription;?>
									</div>
									<div id="menu1" class="tab-pane fade">
									  
									   <?php echo $detail->additionalInfo;?>
									</div>
									<div id="menu2" class="tab-pane fade">
									  
									  review...
									</div>
									
								  </div>
								 
                   <section class="categories-slider-area bg__white">
                       
                       <br/><br/><br/>
            <div class="container-fluid">
                <div class="row">				
    <div class="product-tab-list" id="tabList">
        <span style="text-transform:uppercase;font-size:18px;"> You May Also Buy    
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a data-slide="prev" href="#myCarousel" class=""><i class="zmdi zmdi-chevron-left"></i></a>
		&nbsp;&nbsp;&nbsp;<a data-slide="next" href="#myCarousel" class=""><i class="zmdi zmdi-chevron-right"></i></a>
		</span>
		<span class="text-right"> 
			
					
				
		</span>		
    </div>    
    
    
    <div class="carousel slide" id="myCarousel">
        <div class="carousel-inner">
			 <div class="item active">
			
									<?php 
									$this->load->model('Product_model');
									$products=$this->product_model->fetchSimilarProduct($productSubCatId); 
									if($products)
									{
									foreach($products as $product){
										
										//$this->load->model('Product_model');
		$get_default_photo = $this->product_model->get_default_photo($product->product_id);
		$proImage = $get_default_photo['image_url'];
										
									?>	
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url().$product->slug;?>"> <img src="<?php echo base_url().$proImage;?>" alt="img" height="190px"></a>
                                                <?php 
												/*
												$att=$product->attribute;
												if($att=="prescription_needed")
												{
													echo"<h5 class='sale'>Prescription Needed</h5>";
												}
												else if($att=="featured")
												{
												echo"<h5 class='sale'>Featured</h5>";	
												}else if($att=="hot")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="normal")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}else if($att=="new")
												{
												echo"<h5 class='new'>Hot</h5>";	
												}
												*/
												?>
												
												<!--
                                                <h5 class='new'>Hot</h5>
                                                -->
                                                
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
                                                    <li><a  title="View" class="btn btn-success" href="<?php echo base_url().$product->slug;?>">Details</a></li>
                                                    <li>
													
													
													<?php 

                            $pres=$product->product_need_prescription;
                            $type=$product->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                           
								<br />	
                            	<a href="#prescriptionUploadModal" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary" data-toggle="modal">Add to Bag</a>
                            
                            
                            <?php 
                            }
                            else 
                            {
                            ?>
													<br />
													
													
										<?php
        									$qty=$product->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <button class="btn btn-primary add_cart_btn1" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productimage="<?php echo base_url().$proImage;?>" data-productprice="<?php 
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
        									    
        									    
        									    <?php 
        									}
								
								?>			
													
													
													
													
													
													
							<?php 
                            }
							?>					
													
													</li>
                                                    
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									
									}
									}
									?>
			
			
              </div><!-- /Slide1 --> 
            <!-- /Slide1 --> 
           
		   
		   
		   <div class="item">
			
									<?php 
									$this->load->model('Product_model');
									$products=$this->product_model->fetchSimilarProduct1($productSubCatId); 
									if($products)
									{
									foreach($products as $product){
										
										//$this->load->model('Product_model');
		$get_default_photo = $this->product_model->get_default_photo($product->product_id);
		$proImage = $get_default_photo['image_url'];
										
									?>	
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url().$product->slug;?>"> <img src="<?php echo base_url().$proImage;?>" alt="img" height="190px"> </a>
                                            
                                                
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
                                                    <li><a  title="View" class="btn btn-success" href="<?php echo base_url().$product->slug;?>">Details</a></li>
                                                    <li>
													
													
													<?php 

                            $pres=$product->product_need_prescription;
                            $type=$product->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                           
								<br />	
                            	<a href="#prescriptionUploadModal" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary" data-toggle="modal">Add to Bag</a>
                            
                            
                            <?php 
                            }
                            else 
                            {
                            ?>
													<br />
													
													
													
										<?php
        									$qty=$product->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <button class="btn btn-primary add_cart_btn1" data-productid="<?php echo $product->product_id;?>" data-productname="<?php echo $product->title;?>"data-productimage="<?php echo base_url().$proImage;?>" data-productprice="<?php 
													if($product->discountPrice)
													{
													$price=$product->discountPrice;
													}
													else 
													{
													$price=$product->price;	
													}
													echo$price;?>">Add To Cart</button>
        									    
        									    
        									    <?php 
        									}
								
								?>			
													
													
												
													
													
							<?php 
                            }
							?>					
													
													</li>
                                                    
                                                </ul>
                                                <h4><?php echo $product->title;?></h4>
                                                <h6><span>Price:</span> 
												
												<?php if($product->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $product->price;?></del> TK <?php echo$product->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$product->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
									<?php 
									
									}
									}
									?>
			
			
              </div><!-- /Slide1 --> 
            <!-- /Slide1 --> 
		   
            
        </div>
        
       
	   
	   <!-- /.control-box -->   
                              
    </div><!-- /#myCarousel -->
        
</div><!-- /.col-xs-12 -->          

</div><!-- /.container -->
		
		
</section>	
	
				   
				   
				   
				   
				   
					
				
				
				<?php 
			}
			?>
	  
	  
	  
	  
    </div>
                    <!-- End Left Feature -->
                </div>
            
			
			 <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
			
			
			
			
			</div>
        </section>
        <!-- End Feature Product -->