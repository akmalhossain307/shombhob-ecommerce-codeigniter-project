
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Terms and conditions</div>
					  <div class="panel-body">
					 
            	
					 
						<div style="text-align: justify;" class="sidebarCategory">
					 
					 <h2>Terms and Conditions</h2>
					 
					 Welcome to <a href="https://shombhob.com" title="Shombhob.com" style="color:violet"target="_blank">shombhob.com</a>. This page sets out the terms upon which you may use our <a href="https://shombhob.com" title="Shombhob.com" style="color:violet"target="_blank">www.shombhob.com</a> ("Website","Company") whether as a guest or as a customer. Please read these terms and conditions carefully before you start to use this website. By using our website, you indicate that you accept these  terms of use and that you agree to abide by them. If you do not agree to these terms of use, please abstain from using our website. 
					 
					 <br/><br/>
					 
				<h2> General </h2>
1. The Company reserves the right to amend these terms and conditions at any time. Updated changes will be effective from the time it is posted on our website. Your continued use of the website will be deemed as knowledge and acceptance of our amended terms and conditions. If you do not agree to amendments made to the terms and conditions, please refrain from accessing or using the services provided on this website. <br/>

2. All the contents on this website form an electronic record in terms of<b> তথ্য ও প্রযুক্তি আইন,২০০৬, ( Information & Communication Technology Act,2006) </b>and rules there under as applicable and as amended from time to time. 
					
					 
					 	 <br/><br/>
				
	<h2>Price and Product</h2>
3.    The Company will make every effort to make sure that the pricing and availability of Products on our Website is accurate and up to date. Prices are subject to change without prior notice.<br/>

4.    All orders are subject to acceptance by the Company and stock availability. The Company make sits best effort to ensure that products displayed are available in stock.However, if any time the stock of any ordered product is unavailable, the Company reserves the right to not accept the order for that product or offer alternate products of similar value. <br/>

5.    The prices charged are the prices on the date of the order. In case of any clerical error in noting the price on the website, we reserve the right to correct any inaccuracies or omissions related to pricing and product availability/descriptions, even after you have submitted your order, and to change or update any other information at any time without prior notice.<br/>


6.  All our product prices include all applicable statutory taxes and fees.<br/>

7. The actual size,color and dimension of the product may vary from the picture used to illustrate the product.			
				
				 <br/><br/>

<h2>Registration and Account Security</h2>
8. To register for an account with shombhob.com, you must be over eighteen (18) years of age. <br/>

9. All customers are required to register with the Company before placing an order. During the registration:<br/>

         i. You must provide accurate and up to date information.<br/>

         ii. You must carefully select and safeguard your username and password.
<br/>
         iii. You authorize us to assume that if the website is used under your username, it is you or someone authorized by you to place an order on behalf of you.<br/>

10. The Company has the right to refuse registration of a customer or to terminate the registration of a customer.<br/>

11. Customer shall be liable for every order made under your login and agrees to identify the Company for all claims, damages whatsoever made by any third party arising from the actions of a person placing orders through this website using your login.<br/>

12. Your shombhob.com account username/email and password are personal to you. You are solely responsible for any activities associated with your account. If you suspect any unauthorized use of your shombhob.com account then you are advised to notify us immediately and effectively.
<br/> <br/>


<h2>Online Order and Delivery</h2>
13. Once you have selected a product that you wish to order on www.shombhob.com, you will be shown( on the website ) the charges you must pay including taxes,if applicable, and any applicable delivery charges. <br/>

14. Customer can pay in full for the order with cash at the time of delivery, or at the time of ordering by supplying us with your credit card details from a credit card company acceptable to us, which we require in order to process your order. Alternatively, you may pay by using bKash.<br/>

15. The Company shall not be obliged to supply the product to you until we have accepted and confirmed your order. An order shall be formed and we shall be legally bound to supply the product to you when we accept your order.Acceptance shall take place when we expressly confirm your order by email to you, in the form of a document called a " Confirmation of Order" stating that we are accepting your order.<br/>

16. Until the time when the Company accepts your order, we reserve the right to refuse to process your order and you reserve the right to cancel your order.
<br/>
17. The Company shall deliver the products to the delivery address specified by you on the order form.<br/>

18. We aim to deliver within time frame indicated at the time of order but we are not able to guarantee any firm delivery time upon order and to the extent permitted by law, we shall not be liable to you for any losses , liabilities, costs, damages, charges or expenses arising out of late delivery.<br/>

19. On delivery of the product, you are required to examine the goods immediately upon collection for any deficiencies and/or damages. Upon taking delivery, if any damages are noted, you are required to notify the Company within 3 days for possible exchange or refund as per our Return and Refund Policy.<br/>

20. Please note that it might not be possible for us to deliver to some locations. If this is the case, we will inform you using the contact details you provide to us when you make your order and arrange for cancellation of the order or delivery to an alternative delivery address.<br/>

21. If you are not available to take delivery of goods ordered, an adult person taking delivery on your behalf must sign for the receipt of goods.<br/>

22. If you request for delivery, we are entitled to charge for providing the service.

<br/> <br/>



<h2>Return and Refund Policy</h2>
23. Since shombhob.com does not produce or manufacture any product, therefore we can only attempt to control the quality, but cannot give quality assurance for any. We believe the manufacturer or supplier is fully capable of assuring the quality of all products listed on the website.<br/>

24. You shall examine the goods immediately upon collection/delivery for any deficiencies and/or damages. Claims (if any) must be lodged to our customer service hotline +8801755697233 at the time of delivery; otherwise we shall have the discretion to refuse your claim.<br/>

25. You may hand any faulty or damaged goods, or incorrect items back to the delivery person at the time of delivery, we will process the refund within 10 days. If you discover any defect or damage inside the packaging after the delivery process, please inform us within 7 days, we will arrange to pick up the package as early as possible.<br/>

26. You may return or exchange the product within 7 days of delivery, or refund for the product can be arranged for the following reasons:<br/>

         i.     If the product is obviously expired/damaged at the time of delivery<br/>

         ii.    If the product is expired/damaged inside the packaging and it is discovered after delivery<br/>

         iv.   If the product ordered is different from the item delivered<br/>

         v.    If the product does not meet your expectations<br/>

        vi.    If the product was received in unsatisfactory condition<br/>


        vii.   If the product is found unusable<br/>

27. A product may not be eligible for return or replacement for the following reasons:<br/>

        i.       Product is damaged due to misuse/mishandling by customer<br/>
        ii.      A consumable product which has been used/consumed<br/>
       iii.     A product is not in its original packaging<br/>
28. We will inspect the returned product upon return by you. If one or more of the conditions in paragraph 23 above is fulfilled, you are entitled to choose between an exchange of the product if the product is available in our stock, or for a refund to be made to you.<br/>
29. Goods returned for a refund shall be refunded at the price which you had paid at the point of ordering.
<br/><br/>


<h2>Disclaimer of Warranties and Limitation of Liability</h2>

30. All information, products and services included on or otherwise made available to you through this Website are provided by Shombhob.com on an "as is" and "as available" basis, either expressed or implied, we specifically disclaim warranties of any kind to the extent allowed by the applicable law. You expressly agree that your use of this Website is at your sole risk.<br/>

31. Shombhob.com assumes no responsibility for any damages or viruses that may infect your computer equipment or other property on account of your access to, use of, or browsing in this site. <br/>

32. Shombhob.com has exerted reasonable efforts to ensure that all information published on the Website is accurate at the time of posting; however, there may be errors in such information for which we shall have no liability. We reserve the right to remove or alter any of the information contained on the Website at our sole discretion. <br/>

33. Shombhob.com does not warrant or endorse the effectiveness, quality or safety of the products available on its Website. <br/>  

34. Please note that while shombhob.com has made every effort to accurately display the colours of products on its Website, the actual colour you see will depend on your monitor. We cannot guarantee that your monitor's display of any colour will be the same as the colour of the Products delivered to you.<br/>

35. We may let you view our information and communicate with us through the Social Media services such as Facebook and Twitter. Shombhob.com explicitly disclaims any responsibility for the terms of use and privacy policies that govern these third-party websites, which are in no way associated with us. 
<br/>
36. Shombhob.com accepts no responsibility for any loss or damage suffered due to your reliance on the product reviews posted by the shombhob.com users.
<br/>
37. Shombhob.com reserves the right to modify or withdraw any part of the website or any of its content at any time without notice. 

<br/><br/>


<h2>Website Availability</h2>
38. We take all reasonable care to ensure the availability of the Shombhob.com website 24 hours every day, 365 days per year. However, the website may become temporarily unavailable due to maintenance, server or other technical issues, or for reasons beyond our control. Shombhob.com does not guarantee uninterrupted access to this Website or any linked website. However, we may, but shall not be obliged to, issue a notice when we know of scheduled maintenance of our website.<br/><br/>
<h2>Applicable Law</h2>
39. These Terms and Conditions and your use of this Website and its content will be governed by and construed in all respects in accordance with the laws of Bangladesh. <br/><br/>

<h2>Amendments to Terms and Conditions</h2>
40. We reserve the right to amend these terms and conditions from time to time without further notice. Any such amendments we make shall be effective once we post a revised version of these Terms and Conditions on the Website. It is your responsibility to review the shombhob.com Terms and Conditions regularly. Your continued use of the Website following the publication of any such changes will constitute your agreement to follow and be automatically bound by the amended terms and conditions. <br/><br/>



<h2>Force Majeure</h2>
41. We shall not be liable for any delay or failure in our performance caused by or resulting from acts of God, fire, flood, accident, riot, war, government intervention, embargoes, strikes, labour difficulties, equipment failures, or any other causes beyond our control.
<br/>

</div>
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
     <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	