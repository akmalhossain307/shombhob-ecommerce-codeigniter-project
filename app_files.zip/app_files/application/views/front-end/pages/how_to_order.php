
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">How to order</div>
					  <div class="panel-body sidebarCategory">
					 
            	<div style="text-align: justify;">
					 
					 <h2>How to order</h2>
					 
					 
					 
					 
				You can order for any product from Shombhob.com following few simple steps:<br/>
<b>Step-1: SELECT PRODUCT</b> <br/>                                                      
             Select category and then search what you are looking for in the search box or select from product category<br/>
<b>Step-2: ADD TO SHOPPING CART</b> <br/>
            Add items to your cart by clicking on the 'plus' / + button. Each click of the 'plus' button for a product will add one unit to your cart, and vice versa<br/>
<b>Step-3: VIEW OR UPDATE CART</b><br/>
           To quickly view cart items, place your mouse on the 'Shopping Cart' icon on the navbar on top right of the page. To edit cart items or view details,  click on "view cart" link.<br/>
<b>Step-4: CHECKOUT AND PLACE ORDER</b><br/>
           From cart page, apply your coupon code if available otherwise not then click on "PROCEED TO CHECKOUT" button. After that, follow instructions  and enter required information to finally placing order.	 <br/><br/>
					 
		<center>
		    <h2>Customer Order Flow Chart</h2>
		    <img src="https://shombhob.com/uploads/how_to_order.png" xss="removed" style="border: 0px; max-width: 100%; color: rgb(73, 105, 105); font-family: Arial, Helvetica, sans-serif; font-size: 14px;">
		    
		    
		</center>			 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    </div>
    </div>
    
    
    
    
    
    
    
    <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	