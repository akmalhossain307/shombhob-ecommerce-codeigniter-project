
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Frequently Asked Questions (FAQs)</div>
					  <div class="panel-body sidebarCategory">
					 
            		<div class="panel-group" id="accordion">
                   
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1">1. What is Shombhob.com ?</a>
                            </h4>
                        </div>
                        <div id="collapse1" class="panel-collapse collapse in">
                            <div class="panel-body">
                               <b>Shombhob.com</b> is an online Healthcare and Medicine Shop in Bangladesh. 
                            </div>
                        </div>
                    </div>
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse2">2. How do I order from Shombhob.com?</a>
                            </h4>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse">
                            <div class="panel-body">
                             First, select your desired product(s) by browsing or searching on our website and then place order. You let us know your delivery address, time and mobile number. Our Shombhob.com representative will then deliver your ordered product(s) right to your home or office.
                            </div>
                        </div>
                    </div>
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse3">3. How much do deliveries cost?</a>
                            </h4>
                        </div>
                        <div id="collapse3" class="panel-collapse collapse">
                            <div class="panel-body">
                            Delivery cost for an order is specified at the time of order. It may vary depending on invoice value.
                            </div>
                        </div>
                    </div>
                    
                    
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse4">4. How long do the deliveries take?</a>
                            </h4>
                        </div>
                        <div id="collapse4" class="panel-collapse collapse">
                            <div class="panel-body">
                            Initially, we are serving our customers from 9am – 12am, within 3-6 hours of placing order within certain areas of Dhaka city. You can also specify a convenient time and we will send the product(s) during that time. As we grow, our coverage area and time will also increase.
                            </div>
                        </div>
                    </div>
                    
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse5">5. Can I ask for support any time?</a>
                            </h4>
                        </div>
                        <div id="collapse5" class="panel-collapse collapse">
                            <div class="panel-body">
                                Yes, we are dedicated to ensure customer satisfaction. You can contact us anytime for support.
                            </div>
                        </div>
                    </div>
                    
                       <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse6">6. How do I pay?</a>
                            </h4>
                        </div>
                        <div id="collapse6" class="panel-collapse collapse">
                            <div class="panel-body">
                               We accept cash on delivery (COD) at the moment. Soon we will also accept online Debit/ Credit Card and Bkash, Roket mobile banking service.
                            </div>
                        </div>
                    </div>
                    
                     <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse7">7. What services does Shombhob.com provide?</a>
                            </h4>
                        </div>
                        <div id="collapse7" class="panel-collapse collapse">
                            <div class="panel-body">
                                i. We provide delivery service for healthcare products, medicines, personal care items, herbal items, nutritional products etc. <br/>

        ii. We provide customer support for ordering online through the website's live chat, Facebook, SMS, email or direct phone call.   <br/>

        iii. We provide 24/7 support to ensure customer satisfaction. 
        
       

                            </div>
                        </div>
                    </div>
                    
                       <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse8">8. Why should I buy products from Shombhob.com?</a>
                            </h4>
                        </div>
                        <div id="collapse8" class="panel-collapse collapse">
                            <div class="panel-body">
                                  i. Shombhob.com is a licensed company for selling pharmacy medicines and healthcare products. <br/>

        ii. Our medicinal products are collected/obtained directly from manufacturers or their authorized resellers.<br/>

        iii. We have a zero tolerance policy for non-compliant standards in terms of obtaining, storing, and delivering medicines.
       

                            </div>
                        </div>
                    </div>

        
    </div>

					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
   <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	