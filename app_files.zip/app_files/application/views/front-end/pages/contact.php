
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                    </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

<div class="panel panel-info">
  <div class="panel-heading"><i class="fa fa-envelope"></i> Contact Us.</div>
  <div class="panel-body sidebarCategory">
				
     <div class="row">
       <div class="col-md-8 col-lg-8 col-sm-8 col-xs-12">
           
           
          
           
           
           
          
          <?php echo validation_errors(); ?>
             
                 <form action="<?php echo base_url('contact/save');?>" method="POST">
                   
                   
                    <?php if($this->session->flashdata('cSuccess')){ ?>
				<div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('cSuccess'); ?></strong> 
				</div>
				<?php }
				elseif($this->session->flashdata('cError')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('cError'); ?></strong> 
				</div>
				
				<?php };?>
                   
                   
                   
                   
                   
                        <div class="form-group">
                            <label for="name">Name</label>
                            <?php echo form_error('name'); ?>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name" required>
                            
                        </div>
                  
                        
                   
                        <div class="form-group">
                            <label for="email">Email address</label>
                            <?php echo form_error('email'); ?>
                            <input type="email" class="form-control" name="email"id="email" placeholder="Enter email" required>
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                  
                    
                
                        <div class="form-group">
                            <label for="message">Message</label>
                            <?php echo form_error('message'); ?>
                            <textarea class="form-control" name="message" id="message" rows="6" required></textarea>
                        </div>
                   
                        
                        <div class="mx-auto">
                            <?php 
									$this->load->helper('url');
									$currentURL = current_url();
									//print_r($currentURL);
									//$totalCartAmount=number_format($this->cart->total());
								?>
                            <input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
                        <button type="submit" class="btn btn-primary text-right">Submit</button></div>
                    </form>
                
             
       </div>
       
        <div class="col-md-4 col-lg-4 col-sm-8 col-xs-12">
            <div class="card bg-light mb-3"> <br/>
                <div class="card-header bg-success text-white text-uppercase"> <i class="fa fa-globe"></i> Our Office Info</div>
                <div class="card-body">
                    <br/>
                    <!--
                    <i> 
                   <strong> Office Address:</strong> 232-234,Tejgaon Industrial Area, Dhaka-1208, Bangladesh.<br/>   <br/>
<strong>Email Address:</strong> info@shombhob.com<br/>   
<strong>Openning Hours:</strong> 24 Hours Open<br/>  
<strong>Phone: </strong>+8801755697233
                    </i>
                    
                  --> 

                </div>

            </div>
        </div>
    </div>

					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
   <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	