
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Privacy and confidentiality</div>
					  <div class="panel-body">
					 
            	<div style="text-align: justify;" class="sidebarCategory">
					 
					 <h2>Privacy Policy</h2>
			
					 
					 We are committed to protecting your privacy and ensuring that your personal data is not misused. This privacy policy applies to <a href="https://shombhom.com" title="Shombhob.com" style="color:violet"target="_blank">www.shombhob.com</a> and to personal data collected from you by Shombhob.com. By using this website you are agreeing to our privacy policy.
					 
					 <br/><br/>
					 
					 
					 When you visit this site, we will record your visit and collect and store your personal information provided by you to help serve your shopping needs better. We use cookies to collect data about your use of our site. Cookies are small computer files that can be stored on your computer for the purposes of obtaining configuration information and analyzing your browsing habits. They can save you from signing in again when re-visiting a web site and are commonly used to keep track of your preferences in relation to the subject matter of the website, and to make the shopping experience more user friendly. You may refuse to accept Cookies (by modifying the relevant Internet options or browsing preferences of your computer system), but if you do so you may not be able to utilize or activate certain available functions on our site.
					
					 
					 	 <br/><br/>
					 All personal data you provide us is secured on our website with restricted access by authorized personnel only. We maintain appropriate administrative, technical and physical safety measures to protect the personal data you provide us.
					 	 <br/><br/>
					 
					We at Shombhob.com want your shopping experience with us to be safe, easy, and pleasant. We only collect from you the personal data we need to serve your shopping needs. We do not intend to sell your personal data for marketing purposes. We may have to disclose information to comply with the law or to take action against fraudulent activity. 
					  <br/><br/>
					  
					Should you have any queries concerning our Privacy Policy, please feel free to contact our Customer Services Team at <a href="http://office.com/" target="_blank" style="box-sizing: border-box; color: rgb(51, 122, 183); text-decoration: none; transition: all 150ms ease 0s; background-color: transparent;">info@shombhob.com</a>
We guarantee that any information you provide us is important to us, including your prescription, will be preserved with security. Shombhob.com takes necessary steps to protect our Customers' personal information from unauthorized access, improper use or disclosure or unauthorized modification.   <br/><br/>

<h2>Confidentiality</h2>
We guarantee that any information you provide us is important to us, including your prescription, will be preserved with security. <b>Shombhob.com</b> takes necessary steps to protect our Customers' personal information from unauthorized access, improper use or disclosure or unauthorized modification.
<br/> </div>
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
  <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	