
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<div class="list-group">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="#" class="list-group-item">Second item</a>
                      <a href="#" class="list-group-item">Third item</a>
                </div>
				
				
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                       
                            <div class="category-heading">
                               <h3>	<span class="fa fa-flag"></span> Pages </h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>"> Order History</a>
								</li>
								
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>">Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                       
				<?php } 
				else 
				{
					echo"Customer not logged in...";
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Personal Information</div>
					  <div class="panel-body">
					  
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Name</th>
							<th>Email</th>
							<th>Mobile</th>
						  </tr>
						</thead>
						<tbody>
						
						<?php if($customerInfo){
							foreach($customerInfo as $cus)
							{?>
						  <tr>
							<td><?php echo$cus->name;?></td>
							<td><?php echo$cus->email;?></td>
							<td><?php echo$cus->mobile;?></td>
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No customer data found.";
						}
						  ?>
						  
						</tbody>
					  </table>
					  
					  </div>
					</div>
					
					
					<div class="panel panel-info">
					  <div class="panel-heading">Recent Order</div>
					  <div class="panel-body">
					  
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Order No.</th>
							<th>Order Date</th>
							<th>Grand Total</th>
							<th>Delivery Status</th>
							
						  </tr>
						</thead>
						<tbody>
						
						<?php if($customerOrderInfo){
							foreach($customerOrderInfo as $orderInfo)
							{?>
						  <tr>
							<td><?php echo$orderInfo->order_number;?></td>
							<td><?php echo$orderInfo->order_date;?></td>
							<td><?php echo$orderInfo->order_grand_total;?></td>
							<td><?php echo$orderInfo->order_delivery_status;?></td>
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							echo"You have no order yet.";
						}
						  ?>
						  
						</tbody>
					  </table>
					  
					  </div>
					</div>
					
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- Start Footer Area -->
        
            <div class="container-fluid">
                <div class="row">
                    <div class="footer__container clearfix footr">
                         <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4 col-sm-6">
                            <div class="ft__widget">
                                <div class="ft__logo">
                                    <a href="<?php echo base_url();?>">
                                        <img src="<?php echo base_url('assets/front-end')?>/images/logo/Yesbd_Logo_with_Tag_line.png" alt="footer logo">
                                    </a>
                                </div>
                                <div class="footer-address">
                                    <ul>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-pin"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>232-234,Tejgaon Industrial Area, Dhaka-1208, Bangladesh.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-email"></i>
                                            </div>
                                            <div class="address-text">
											<a href="mailto:info@yesbd.com">info@yesbd.com</a>
                                                
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-phone-in-talk"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>09612779900 </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <ul class="social__icon">
									<li><a href="https://www.facebook.com/yesbdpharmacy" target="_blank"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-twitter"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-instagram"></i></a></li>
                                    
                                    <li><a href="#"><i class="zmdi zmdi-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        
                        <div class="col-md-4 col-lg-4 col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Infomation</h2>
						<ul class="footer-categories">
						
							<li><a href="<?php echo base_url('pages');?>">FAQ</a></li>
						
							<li><a href="<?php echo base_url('pages');?>">About Us</a></li>
							<li><a href="<?php echo base_url('pages');?>">Privacy and Confidentiality</a></li>
							<li><a href="<?php echo base_url('pages');?>">Terms and Conditions</a></li>
							<li><a href="<?php echo base_url('pages');?>">Return and Refund Policy</a></li>
							<li><a href="<?php echo base_url('pages');?>">How to Order</a></li>
							<li><a href="<?php echo base_url('pages');?>">Support/Contact Us</a></li>
							<li><a href="<?php echo base_url('sitemap');?>">Sitemap</a></li>
							
							
						</ul>
                            </div>
                        </div>
                        
                        
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4  col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Newsletter</h2>
                                <div class="newsletter__form">
                                    <p>Get all the latest information on Events,
Sales and Offers. Sign up for newsletter today.</p>
                                    <div class="input__box">
                                        <div id="mc_embed_signup">
                                            <form action="<?php echo base_url('search/addSubscribe')?>" method="post">
                                                <div id="mc_embed_signup_scroll" class="htc__news__inner">
                                                    <div class="news__input">
                                                        <input type="email"  name="email" class="email" placeholder="Email Address" required>
                                                    </div>
                                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                                   
                                                    <div class="clearfix subscribe__btn"><input type="submit" title="Send"value="Send" name="subscribe" id="mc-embedded-subscribe" class="bst__btn btn--white__color">
                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>        
                                </div>
                            </div>
							<br />
						
							<img src="<?php echo base_url('assets/front-end/images/SSLCommerz-logo.png')?>" alt="ssl_images" width="100%"height="80px"/>
							
							<br/>	<br/>
							<span style="color:violet;text-align:center;">
                             
                                    © <?php echo date('Y');?> <a href="https://yesbd.com/">Yesbd.com Ltd.</a>
                                    All Right Reserved.
                             </span>
							
                        </div>
                        <!-- End Single Footer Widget -->
                       
                    </div>
                </div>
                
                
            </div><!-- Close Footer Area -->

             
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	