
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Return and refund policy</div>
					  <div class="panel-body">
					 
          <div style="text-align: justify;" class="sidebarCategory">  	
					 
					 <h2>Return And Refund Policy</h2>
					 
					 
					 
					 1. Since shombhob.com does not produce or manufacture any product, therefore we can only attempt to control the quality, but cannot give quality assurance for any. We believe the manufacturer or supplier is fully capable of assuring the quality of all products listed on the website.<br/>



2. You shall examine the goods immediately upon collection/delivery for any deficiencies and/or damages. Claims (if any) must be lodged to our customer service hotline <b>+8801755697233</b> at the time of delivery; otherwise we shall have the discretion to refuse your claim.<br/>



3. You may hand any faulty or damaged goods, or incorrect items back to the delivery person at the time of delivery, we will process the refund within 7 days. If you discover any defect or damage inside the packaging after the delivery process, please inform us within 3 days, we will arrange to pick up the package as early as possible.<br/>



4. You may return or exchange the product within 7 days of delivery, or refund for the product can be arranged for the following reasons:<br/>

         i.     If the product is obviously expired/damaged at the time of delivery<br/>

         ii.    If the product is expired/damaged inside the packaging and it is discovered after delivery<br/>

         iii.   If the product ordered is different from the item delivered<br/>

         iv.    If the product does not meet your expectations<br/>

         v.    If the product was received in unsatisfactory condition<br/>

         vi.   If the product is found unusable<br/>



5. A product may not be eligible for return or replacement for the following reasons:<br/>

        i.       Product is damaged due to misuse/mishandling by customer<br/>

        ii.      A consumable product which has been used/consumed<br/>

       iii.     A product is not in its original packaging<br/>

6. We will inspect the returned product upon return by you. If one or more of the conditions in paragraph 4 above is fulfilled, you are entitled to choose between an exchange of the product if the product is available in our stock, or for a refund to be made to you.<br/>

7. Goods returned for a refund shall be refunded at the price which you had paid at the point of ordering.


					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
			</div>		 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
     <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	