
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Pages</a></li>
										
										
										<li class="active"><?php echo$pageTitle;?></li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
					<div class="list-group sidebarCategory">
                      <a href="#" class="list-group-item active"><span class="fa fa-flag"></span> Pages</a>
                      <a href="<?php echo base_url('page/faq');?>" class="list-group-item"><span class="fa fa-question-circle"></span> FAQs</a>
                      <a href="<?php echo base_url('page/about-us');?>" class="list-group-item"><span class="fa fa-info-circle"></span> About Us</a>
                      <a href="<?php echo base_url('page/privacy-confidentiality');?>" class="list-group-item"><span class="fa fa-key"></span> Privacy and Confidentiality</a>
                      <a href="<?php echo base_url('page/terms-conditions');?>" class="list-group-item"><span class="fa fa-snowflake-o"></span> Terms and Conditions</a>
                      <a href="<?php echo base_url('page/return-refund-policy');?>" class="list-group-item"><span class="fa fa-asl-interpreting"></span> Return and Refund Policy</a>
                      <a href="<?php echo base_url('page/how-to-order');?>" class="list-group-item"><span class="fa fa-cart-plus"></span> How to Order</a>
                      <a href="<?php echo base_url('page/contact');?>" class="list-group-item"><span class="fa fa-envelope"></span> Support/Contact Us</a>
                      <a href="<?php echo base_url('page/sitemap');?>" class="list-group-item"><span class="fa fa-map"></span> Sitemap</a>
                  
                    </div>
				
				
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">About Us</div>
					  <div class="panel-body">
					 
            	<div class="sidebarCategory"style="text-align:justify">
					 
				With the dynamic growth of our economy, Bangladeshi cities are experiencing exponential growth. With this growth we are also witnessing pressure on our infrastructure and resources. Our time is more precious than ever. Thanks to technological advancements in telecommunications, we can conduct our work more efficiently.
				
				<br/><br/>
					 
					 
					 
			<b>shombhob.com</b> is an online shopping service focused on meeting the urban people’s need for healthcare items delivered right to their doorstep. Gone are the days when you have to physically go to the pharmacy to get medicines, toiletries, personal care or baby care products. <b>Shombhob.com</b> will beat the traffic and deliver medicines and other healthcare products to your door within the shortest possible time.	 
			
			
					 
					 
				</div>	 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					  </div>
					</div>
					
				
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
    
   <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	