
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Wishlist</li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        <div class="categories-menu">
                            <div class="category-heading">
                               <h3> Customer Panel</h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>">  <span class="fa fa-history"></span> Order History</a>
								</li>
									
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                        </div>
				<?php } 
				else 
				{
					echo"Customer not logged in...";
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

					<div class="panel panel-info">
					  <div class="panel-heading">Product Wishlist</div>
					  <div class="panel-body">
					 <div class="table-responsive"> 
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Product</th>
							<th>Image</th>
							<th>Price</th>
							<th>Action</th>
							
						  </tr>
						</thead>
						<tbody>
						
						<?php if($customerWishList){
							foreach($customerWishList as $wish)
							{?>
						  <tr>
							<td><a href="<?php echo base_url('productDetails/').$wish->product_id;?>"><?php echo$wish->title;?></a></td>
							
							<td><a href="<?php echo base_url('productDetails/').$wish->product_id;?>"><img src="<?php echo$wish->image;?>" width="70" height="50"alt="<?php echo$wish->title;?>" /></a></td>
							<td>TK <?php echo$wish->price;?>.00</td>
							<td>
							    
							    
							    <a href="<?php echo base_url().$wish->product_id;?>" class="btn btn-success btn-sm">Details</a>
							   
							    <?php 
							    /*
							     url_title($title, '-', TRUE);
							 function seoUrl($string) {
                    //Lower case everything
                    $string = strtolower($string);
                    //Make alphanumeric (removes all other characters)
                    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
                    //Clean up multiple dashes or whitespaces
                    $string = preg_replace("/[\s-]+/", " ", $string);
                    //Convert whitespaces and underscore to dash
                    $string = preg_replace("/[\s_]/", "-", $string);
                    return $string;
                }
							   */ 
							    ?>
							    
							    
							    
							    <a href="<?php echo base_url('product/deleteWishlistProduct/').$wish->product_id;?>" onclick="return confirm('Are you sure to delete this product from your wishlist?')" class="btn btn-danger btn-sm">Delete</a></td>
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No product in your Wishlist...";
						}
						  ?>
						  
						</tbody>
					  </table>
					 </div> 
					  </div>
					</div>
					
					<br />
					
				
            </div>
            
            </div>
            
            
            
            
            
            
            
            
            
            
           <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
            
            
            
            
            
            
            </div>
        </section>
        <!-- End Feature Product -->
        
	