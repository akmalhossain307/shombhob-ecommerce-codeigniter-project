
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            
           
            
            
   <div class="container-fluid">
                
            
                <div class="row">
				
					<br/>
                    <ol class="breadcrumb breadcrumb-arrow">
                		<li><a href="<?php echo base_url();?>"> <span class="fa fa-home"></span> Home</a></li>
                		<li class="active"><span><?php echo $page_title;?></span></li>
                	</ol>	
							
                   <div class="col-md-2"></div> 
                   <div class="col-md-8">
				   <br />
				   <br />
				   
								<?php 
								if($this->session->flashdata('emailError')){ ?>
								<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('emailError'); ?></strong>
								</div>
								<?php }
								else if($this->session->flashdata('emailSuccess')){
									?>
									<div class="alert alert-success alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('emailSuccess'); ?></strong>
								</div>
								<a href="" style="color:coral;font-size:15px;font-weight:bold" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login!"> Click here to Login</a>
								<br/><br/>
								
									<?php 
								}
								else if($this->session->flashdata('passChngError'))
								{
									?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChngError'); ?></strong>
								</div>
									
									<?php 
								}
								
								?>
				   
				   
				   
				   
				   
				   
						<div class="panel panel-info">
						  <div class="panel-heading"> <span class="fa fa-cogs"></span> Forgot Password</div>
						  <div class="panel-body">
						  
			<form action="<?php echo base_url('customer/resetCustomerPassword1')?>" method="POST">
							
							
							<span style="color:coral;font-size:12px;"><b>Dear Customer, please enter your email address below and click the send button. We will send instructions to your email regarding your password.</b></span> <br />
								  
								  <div class="form-group">
									<label for="exampleFormControlInput1">Email</label>
									<input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="enter email" required="">
									
								  </div>
								  
					   
							<div class="modal-footer">
							
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);
									
								//$cusEmailOrPhone=$this->session->userdata("customerUsername");
								
								?>
							  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
								<br />
	
							
							<center>
							  <input type="reset" class="btn btn-warning" value="Reset">
							  <input type="submit" class="btn btn-success" value="Send">
							 </center> 
							</div>
			
			</form>
						  
						  	
								
								
							
						  </div>
						</div>
						
						<br />
		<br />
		<br />
		<br />
		<br />
		<br />
				   </div> 
                   <div class="col-md-2"></div> 
                  
				
		
		
					
                </div>
                
              
                
                
                
                </div>
            
        </section>
        <!-- End Feature Product -->
        
      <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
