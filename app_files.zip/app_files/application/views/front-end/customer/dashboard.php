
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Customer Dashboard</li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        <div class="categories-menu">
                            <div class="category-heading">
                               <h3> Customer Panel</h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>">  <span class="fa fa-history"></span> Order History</a>
								</li>
									
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                        </div>
				<?php } 
				else 
				{
					echo"Customer not logged in...";
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Personal Information</div>
					  <div class="panel-body">
					  <div class="table-responsive">
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Name</th>
							<th>Email</th>
							<th>Mobile</th>
						  </tr>
						</thead>
						<tbody>
						
						<?php if($customerInfo){
							foreach($customerInfo as $cus)
							{?>
						  <tr>
							<td><?php echo$cus->name;?></td>
							<td><?php echo$cus->email;?></td>
							<td><?php echo$cus->mobile;?></td>
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No customer data found.";
						}
						  ?>
						  
						</tbody>
					  </table>
					  
					  </div>
					  
					  </div>
					</div>
					
					
					<div class="panel panel-info">
					  <div class="panel-heading">Recent Order</div>
					  <div class="panel-body">
					 <div class="table-responsive">
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Order No.</th>
							<th>Order Date</th>
							<th>Grand Total</th>
							<th>Delivery Status</th>
							
						  </tr>
						</thead>
						<tbody>
						
						<?php if($customerOrderInfo){
							foreach($customerOrderInfo as $orderInfo)
							{?>
						  <tr>
							<td><?php echo$orderInfo->order_number;?></td>
							<td><?php echo$orderInfo->order_date;?></td>
							<td><?php echo$orderInfo->order_grand_total;?></td>
							<td><?php echo$orderInfo->order_delivery_status;?></td>
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							echo"You have no order yet.";
						}
						  ?>
						  
						</tbody>
					  </table>
					 </div> 
					  </div>
					</div>
					
					<br />
					
				
            </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
     <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</div>
        </section>
        <!-- End Feature Product -->
        
	