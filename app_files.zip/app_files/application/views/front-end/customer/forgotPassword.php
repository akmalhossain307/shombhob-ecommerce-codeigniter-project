
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
							<br />
							<br />
							
							
                   <div class="col-md-2"></div> 
                   <div class="col-md-8">
				   <br />
				   <br />
				   
								<?php 
								if($this->session->flashdata('emailError')){ ?>
								<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('emailError'); ?></strong>
								</div>
								<?php }
								else if($this->session->flashdata('emailSuccess')){
									?>
									<div class="alert alert-success alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('emailSuccess'); ?></strong>
								</div>
								<a href="" style="color:coral;font-size:15px;font-weight:bold" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login!"> Click here to Login</a>
								<br/><br/>
								
									<?php 
								}
								else if($this->session->flashdata('passChngError'))
								{
									?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChngError'); ?></strong>
								</div>
									
									<?php 
								}
								
								?>
				   
			
		<br />
		<br />
		<br />
		
		
		
		
		
		
		
		
		
		
		
		
		
		  <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
				   </div> 
                   <div class="col-md-2"></div> 
                  
				
		
		
					
                </div>
                
                
                
                
                </div>
            
        </section>
        <!-- End Feature Product -->
        
        
       