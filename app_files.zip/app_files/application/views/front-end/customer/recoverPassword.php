
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
							<br />
							<br />
							
							
                   <div class="col-md-3"></div> 
                   <div class="col-md-6">
						<div class="panel panel-info">
						  <div class="panel-heading">Change Password</div>
						  <div class="panel-body">
							
								<?php 
								if($this->session->flashdata('mobileOrEmailNotExit')){ ?>
								<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('mobileOrEmailNotExit'); ?></strong>
								</div>
								<?php }
								else if($this->session->flashdata('passChngSuccess')){
									?>
									<div class="alert alert-success alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChngSuccess'); ?></strong>
									<br/>
									
								</div>
								
									<a href="" style="color:coral;font-size:15px;font-weight:bold" data-target="#myLoginRegisterModal" data-toggle="modal" title="Login!"> Click here to Login</a>
									
									<?php 
								}
								else if($this->session->flashdata('passChngError'))
								{
									?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChngError'); ?></strong>
								</div>
									
									<?php 
								}
								
								?>
								
								
								
								
	<?php 
	if(isset($_POST['user']))
	{
		//echo"User set and the email is: ".$_POST['email']." <br/>";
	
	?>
	
	
							<form action="<?php echo base_url('customer/recoverPassword')?>" method="POST">
							
								  <div class="form-group">
									<label for="exampleFormControlInput1">New Password</label>
									<input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="enter new pass" required="">
									
								  </div>
								  
					   
							<div class="modal-footer">
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);
									
								$cusEmailOrPhone=$this->session->userdata("customerUsername");
								
								?>
							  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
							  <input type="hidden" name="username" value="<?php echo$_POST['email'];?>"/>
							  <input type="reset" class="btn btn-warning" value="Clear">
							  <input type="submit" class="btn btn-success" value="Change Password">
							</div>
							</form>
							
							
							
							
							
							
							
							
							
	<?php
	}
	else 
	{
	    /*
	
		echo"<span style='color:red'>User not set or the session has expired!</span>";
		*/
		
		
		
		?>
		
		
		<form action="<?php echo base_url('customer/recoverPassword')?>" method="POST">
							
								  <div class="form-group">
									<label for="exampleFormControlInput1">New Password</label>
									<input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="enter new pass" required="">
									
								  </div>
								  
					   
							<div class="modal-footer">
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);
									
								$cusEmailOrPhone=$this->session->userdata("customerUsername");
								
								?>
							  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
							  <input type="hidden" name="username" value="<?php echo$cusEmailOrPhone;?>"/>
							  <input type="reset" class="btn btn-warning" value="Clear">
							  <input type="submit" class="btn btn-success" value="Change Password">
							</div>
							</form>
		
		
		
		
		<?php
		
		
		
	}
	
	?>			
							
						  
						  
						  </div>
						</div>
						
						<br />
		<br />
		<br />
		<br />
		<br />
		<br />
				   </div> 
                   <div class="col-md-3"></div> 
                  
				
		
		
					
                </div>
                </div>
            
        </section>
        <!-- End Feature Product -->