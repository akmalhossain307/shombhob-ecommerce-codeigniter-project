
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Order Details</li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        <div class="categories-menu">
                            <div class="category-heading">
                               <h3> Customer Panel</h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>">  <span class="fa fa-history"></span> Order History</a>
								</li>
									
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                        </div>
				<?php } 
				else 
				{
					echo"<h3>Customer not logged in...</h2>";
				
				?>	
					<script>
						//Using setTimeout to execute a function after 5 seconds.
						setTimeout(function () {
						   //Redirect with JavaScript
						   window.location.href= '<?php echo base_url();?>';
						}, 3000);
					</script>
					
				<?php	
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       

					<div class="panel panel-info">
					  <div class="panel-heading">Order Details</div>
					  <div class="panel-body">
					  
					  <?php 
				
				if($this->session->userdata('custmrLogin')==true){
				
				?>
					 
					 
							
					  
<b style="color:magenta">Order Summary</b>
		<div class="table-responsive">			  
<table class="table table-bordered table-hover">
    <?php foreach($OrderSummary as $summary){?>
		<tr>
        <th>Order No.</th>
		<td><?php echo$summary->order_number;?></td>
		
		</tr>
		
		<tr>
        <th>Payment Method</th>
		<td><?php $p_method=$summary->order_payment_method;
		if($p_method=="SSL")
		{
			echo"SSL Card Payment";
		}
		else if($p_method=="COD")
		{
			echo"Cash On Delivery";
		}
		else
		{
			echo"Cash On Delivery";
		}
		?></td>
		</tr>
		
		<tr> 
        <th>Payment Status</th>
		<td><?php echo$summary->order_payment_status;?>
		<?php 
		$sts=$summary->order_payment_status;
		if($sts=="PAID" || $sts=="Paid")
		{
		    echo" (Trnx ID:".$summary->order_payment_trnx_id.")";
		}
		
		if($sts=="CANCELLED" || $sts=="FAILED"|| $sts=="Cancel")
		{
		    ?>
		    <div class="alert alert-warning">
             <small class="text text-muted">Do you want to re-pay?</small>
              <a href="<?php echo base_url('repayment/').$summary->order_id;?>" class='btn btn-info btn-sm '><span class='fa fa-shopping-basket' style='color:magenta;background:#ddd'></span> Pay Now.</a>
		
            
             </div>
		<?php 
		}
		else if($sts=="Unpaid" || $sts=="Processing" )
		{
		    ?>
		     <a href="<?php echo base_url('repayment/').$summary->order_id;?>" class='btn btn-info btn-sm'><span class='fa fa-shopping-basket' style='color:magenta;background:#ddd'></span> Pay Now.</a>
		<?php
		}
		
		?>
		
		
		</td>
		</tr>
		
		<tr>
        <th>Order Amount(TK)</th>
		<td><?php echo$summary->order_total_amount;?></td>
		
		</tr>
		
		<tr>
        <th>Delivery Cost(TK)</th>
		<td><?php echo$summary->order_delivery_cost;?></td>
		
		
		</tr>
		
		<tr>
        <th>Order Delivery Date</th>
		<td><?php echo$summary->order_delivery_date;?></td>
		
		
		</tr>
		
		<tr>
        <th>Order Delivery slot</th>
		<td><?php echo$summary->order_delivery_slot;?></td>
		
		
		</tr>
		
		<tr>
        <th>Order Delivery Status</th>
		<td><?php echo$summary->order_delivery_status;?></td>
		
		
		</tr>
		<?php $applied_coupon=$summary->order_applied_coupon;
		if($applied_coupon){
			
		?>
		<tr>
        <th>Applied Coupon</th>
		<td><?php echo$summary->order_applied_coupon;?></td>
		</tr>
		
		<tr>
        <th>Discount(TK)</th>
		<td><?php echo$summary->order_coupon_discount;?></td>
		</tr>
		<?php 
		}
		else 
		{
			echo"";
		}
		?>
		
		<tr> 
        <th>Order Grand Total(TK)</th>
		<td><?php echo$summary->order_grand_total;?></td>
      </tr>
	<?php }?>
   
  </table>
		</div>			  
					  
					 
					  
			<b style="color:magenta">Items Details</b>		  
					  
					<div class="table-responsive">  
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Item</th>
							<th>Photo</th>
							<th>Qty</th>
							<th>Unit Price(TK)</th>
							<th>Sub-Total(TK)</th>
							<th>Action</th>
						  </tr>
						</thead>
						<tbody>
						
<?php if($cusOrderDetails){
	foreach($cusOrderDetails as $details)
	{
		$proID=$details->details_item_id;
		$product=$this->customer_model->orderProductDetailsById($proID);
		foreach($product as $pro)
		{
			$this->load->model('product_model');
			$get_default_photo = $this->product_model->get_default_photo($pro->product_id);
			$proImage = $get_default_photo['image_url'];
	
		/*
		
		
		$product=$this->customer_model->orderProductDetailsById($proID);
		if($product)
		{
			echo"Hi";
		}
		else 
		{
			echo"Nai";
		}
		
		$this->load->model('product_model');
		$product=$this->customer_model->orderProductDetailsById($proID);
		foreach($product as $pro)
		{
		$get_default_photo = $this->product_model->get_default_photo($pro['product_id']);
		$proImage = $get_default_photo['image_url'];
		}		
		*/
		
								/*
								$product=$this->customer_model->orderProductDetailsById($details->details_item_id);
									 //$this->load->model('Product_model');
									 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
									 $proImage = $get_default_photo['image_url'];
									 */
									 
								 
									 
								?>
						  <tr>
							<td><a href="<?php echo base_url().$pro->slug;?>"><?php echo$pro->title;?></a></td>
							
							
							<td> <a href="<?php echo base_url().$pro->slug;?>"><img src="<?php echo base_url().$proImage;?>" alt="" width="100px" height="70px" /></a></td>
							<td><?php echo$details->details_item_quantity;?></td>
							<td><?php echo$details->details_item_unitprice;?></td>
							<td><?php echo$details->details_item_subtotal;?></td>
							<td>
						  <form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">
							
										<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									
									?>
									<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
									<input type="hidden" name="product_id"value="<?php echo$pro->product_id;?>" />
									<input type="hidden" name="product_name"value="<?php echo$pro->title;?>" />
									<input type="hidden"name="product_image"value="<?php echo base_url().$proImage;?>" />
									 <input type="hidden" name="product_price"id="product_price" value="<?php 
													if($pro->discountPrice)
													{
													$price=$pro->discountPrice;
													}
													else 
													{
													$price=$pro->price;	
													}
													echo$price;?>" />
										<input type="hidden" name="product_old_price" value="<?php echo$pro->price;?>"/>			
									
								<input type="hidden"name="quantity"id="itemQTY" />
								
								<?php
        									$qty=$pro->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <input type="submit" name="submit"class="btn btn-primary" value="Add To Bag"/>
        									    <?php 
        									}
								
								?>
								
								</form>	
						  </td>
						  
						  </tr>
						  
						  
						  <?php 
						
						
						}
						
						
						}
						
						?>
						
						
						
						<?php
						
						}
						else 
						{
							echo"No Product details found.";
						}
						  ?>
						  
						 
						  
<form action="<?php echo base_url('product/addMultiple');?>" method="POST" enctype="multipart/form-data">
		<?php 
		$this->load->helper('url');
		$currentURL1 = current_url();

		?>	
		<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>	
		<input type="hidden"name="order_id" value="<?php echo$summary->order_id;?>"/>	
<input type="submit" name="submit"class="btn btn-primary" value="Add All To Shopping Bag"/>
        									    
	
	</form>	
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						</tbody>
					  </table>
			</div>		  
					  
					  <?php 
						}
						else 
						{
							echo"<span style='color:coral;font-size:20px'> <br /><br /><br /><br /><br />Please login to continue..<br /><br /><br /><br /><br /><br />";
						}
					?>  
					  
					  
					  </div>
					</div>
					
					<br />
					
				
            </div>
            </div>
            
        <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->
            </div>
        </section>
        <!-- End Feature Product -->
        
	