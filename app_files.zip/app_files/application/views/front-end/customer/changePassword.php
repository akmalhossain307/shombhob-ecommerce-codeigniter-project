
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Change password</li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        <div class="categories-menu">
                            <div class="category-heading">
                               <h3> Customer Panel</h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>">  <span class="fa fa-history"></span> Order History</a>
								</li>
									
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                        </div>
				<?php } 
				else 
				{
					echo"Customer not logged in...";
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12">
                       
					<div class="panel panel-info">
						  <div class="panel-heading">Change Password</div>
						  <div class="panel-body">
							
								<?php 
								if($this->session->flashdata('passChangeSuccess')){
									?>
									<div class="alert alert-success alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChangeSuccess'); ?></strong>
								</div>
									<?php 
								}
								else if($this->session->flashdata('passChangeError'))
								{
									?>
									<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('passChangeError'); ?></strong>
								</div>
									<?php 
								}
								else if($this->session->flashdata('oldPassNotMatched'))
								{
									?>
								<div class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<strong><?php echo $this->session->flashdata('oldPassNotMatched'); ?></strong>
								</div>
								<?php  } ?>
								
								
							<form action="<?php echo base_url('customer/updateNewPassword')?>" method="POST">
							
								  <div class="form-group">
									<label for="exampleFormControlInput1">Old Password</label>
									<input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="enter old pass" required="">
									
								  </div>
								  
								  <div class="form-group">
									<label for="exampleFormControlInput1">New Password</label>
									<input type="password" name="newPassword" class="form-control" id="exampleFormControlInput1" placeholder="enter new pass" required="">
									
								  </div>
								  
					   
							<div class="modal-footer">
								<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									//print_r($currentURL);
									
								$cus_id=$this->session->userdata('active_customer');
								?>
								
							  <input type="hidden" name="currentURL" value="<?php echo$currentURL1;?>"/>
							  <input type="hidden" name="customerId" value="<?php echo$cus_id;?>"/>
							  <input type="reset" class="btn btn-warning" value="Clear">
							  <input type="submit" class="btn btn-success" value="Change Password">
							</div>
							</form>
						  
						  
						  </div>
						</div>
						
					
				
            </div>
        
        </div> 
           <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->

        </div>
        
        </section>
        <!-- End Feature Product -->
        
	