
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
				
				<br />
				<br />
			<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span>Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Customer</a></li>
										
										
										<li class="active">Delivery Address</li>       
										      
				</ol>
				<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
				
				<?php 
				
				if($this->session->userdata('custmrLogin')==true){?>
                        <div class="categories-menu">
                            <div class="category-heading">
                               <h3> Customer Panel</h3>
                            </div>
							<?php 
							$cus_id=$this->session->userdata('active_customer');
							?>
							
                            <div class="category-menu-list">
                                <ul>
								
								<li> 
									<a href="<?php echo base_url('customer/dashboard');?>"> <span class="fa fa-dashboard"></span> Dashboard</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerProfile');?>"> <span class="fa fa-id-card"></span> Your Profile</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/orderHistory');?>">  <span class="fa fa-history"></span> Order History</a>
								</li>
									
								<!--
								<li> 
									<a href="<?php //echo base_url('customer/winningCoupons');?>"> Winning Coupons</a>
								</li>
								-->
								<li> 
									<a href="<?php echo base_url('customer/productWishList');?>"> <span class="fa fa-shopping-basket"></span> Wishlist</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/customerDeliveryAddress');?>"> <span class="fa fa-binoculars"></span> Delivery Address</a>
								</li>
								
								<li> 
									<a href="<?php echo base_url('customer/changePassword');?>"> <span class="fa fa-cogs"></span> Change Password</a>
								</li>
								<li> 
									<a href="<?php echo base_url('customer/logout');?>"> <span class="fa fa-sign-out"></span> Logout</a>
								</li>
								  
                                </ul>
                            </div>
                        </div>
				<?php } 
				else 
				{
					echo"Customer not logged in...";
				}?>
				
				<br />
					<br />
					<br />
				
				
                    </div>
                    <!-- End Left Feature -->
				
				
				
                    <!-- Start Left Feature -->
                    <div class="col-md-9 col-lg-9 col-sm-8 col-xs-12 ">
                       

                    <div class="panel panel-info">
					  <div class="panel-heading">Cutomer Delivery Address</div>
					  <div class="panel-body">
					  <div class="table-responsive">
					  <table class="table table-bordered table-hover">
						<thead>
						  <tr>
							<th>Name</th>
						
							<th>Address</th>
							<th>Area</th>
							<th>Phone</th>
							<th>Action</th>
						  </tr>
						</thead>
						<tbody>
						
						<?php if($addressInfo){
							foreach($addressInfo as $address)
							{?>
						  <tr>
						  
						  
						  
							<td><?php 
						  if($address->name==true){echo$address->name;}else{echo$address->address_first_name." ".$address->address_last_name;}
						  ?></td>
					
							<td><?php echo$address->address_address;?></td>
							<td><?php echo$address->address_area;?></td>
							<td><?php echo$address->address_phone;?></td>
							<td>
							<a href="<?php echo base_url('customer/editAddress/').$address->address_id;?>" class="btn btn-danger btn-sm"> Edit </a>
							
							</td>
							
							
						  </tr>
						  <?php 
						}
						}
						else 
						{
							
							?>
							
			<tr>
				<td colspan="6">
				<h4 style="color:coral">No Delivery address found. Please fill below information to add Delivery information.</h4> <br />
				</td>
			</tr>				

<form action="<?php echo base_url('checkout/saveCustomerAddress');?>" method="POST">
				
			<tr>
				<td>
					<label for="id_first_name">First name:</label></td>
				<td>
					<input class="form-control" id="id_first_name"name="address_first_name"type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_last_name">Last name:</label></td>
				<td>
					<input class="form-control" id="id_first_name" name="address_last_name"type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_phone">Phone:</label></td>
				<td>
					<input class="form-control" id="id_phone" name="address_phone" type="text" required />
				</td>
			</tr>
			<tr>
				<td style="width: 175px;">
					<label for="id_address_line_1">Address:</label></td>
				<td>
				
				<textarea name="address_address" id=""class="form-control" cols="30" rows="10"required ></textarea>
					
				</td>
			</tr>
			
			<tr>
				<td style="width: 175px;">
					<label for="id_state">Area:</label></td>
				<td>
					<select class="form-control" id="id_state" name="address_area" required>
						<option selected>Select Area</option>
						<option value="Adabor">Adabor</option>
						<option value="Aftabnagar">Aftabnagar</option>
						<option value="Agargaon">Agargaon</option>
						<option value="Azimpur">Azimpur</option>
						<option value="Badda">Badda</option>
						<option value="Banani">Banani</option>
						<option value="Banasree">Banasree</option>
						<option value="Baridhara">Baridhara</option>
						<option value="Baridhara J Block">Baridhara J Block</option>
						<option value="Basundhara RA">Basundhara RA</option>
						<option value="Bawnia">Bawnia</option>
						<option value="Cantonment">Cantonment</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dakshin Khan">Dakshin Khan</option>
						<option value="Dhaka University">Dhaka University</option>
						<option value="Dhanmondi">Dhanmondi</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Banani">DOHS Banani</option>
						<option value="DOHS Baridhara">DOHS Baridhara</option>
						<option value="DOHS Mirpur">DOHS Mirpur</option>
						<option value="DOHS Mohakhali">DOHS Mohakhali</option>
						<option value="Eskaton">Eskaton</option>
						<option value="Farmgate">Farmgate</option>
						<option value="Gabtoli">Gabtoli</option>
						<option value="Gulshan">Gulshan</option>
						<option value="Indira Road">Indira Road</option>
						<option value="Kakrail">Kakrail</option>
						<option value="Kalabagan">Kalabagan</option>
						<option value="Kallyanpur">Kallyanpur</option>
						<option value="Kalshi">Kalshi</option>
						<option value="Kamrangir Char">Kamrangir Char</option>
						<option value="Khilgaon">Khilgaon</option>
						<option value="Khilkhet">Khilkhet</option>
						<option value="Lalbagh">Lalbagh</option>
						<option value="Lalmatia">Lalmatia</option>
						<option value="Malibagh">Malibagh</option>
						<option value="Matikata">Matikata</option>
						<option value="Merul Badda">Merul Badda</option>
						<option value="Mirpur">Mirpur</option>
						<option value="Moghbazaar">Moghbazaar</option>
						<option value="Mohammadpur">Mohammadpur</option>
						<option value="Motijheel">Motijheel</option>
						<option value="Niketan">Niketan</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Nikunja">Nikunja</option>
						<option value="Paikpara">Paikpara</option>
						<option value="Pallabi">Pallabi</option>
						<option value="Paltan">Paltan</option>
						<option value="PanthaPath">PanthaPath</option>
						<option value="Pink City">Pink City</option>
						<option value="Ramna">Ramna</option>
						<option value="Rampura">Rampura</option>
						<option value="Shaymoli">Shaymoli</option>
						<option value="Tejgaon">Tejgaon</option>
						<option value="Tongi">Tongi</option>
						<option value="Uttar Khan">Uttar Khan</option>
						<option value="Uttara">Uttara</option>
						<option value="Vatara">Vatara</option>
						<option value="Wari">Wari</option>
					</select>
				</td>
			</tr>

			<tr>
				<td></td>
				<td>
				<br /> 
				
				<?php 
				if($this->session->userdata('custmrLogin'))
				{
					$custommerId=$this->session->userdata('active_customer');
				}
				$this->load->helper('url');
				$currentURL = current_url();
				//print_r($currentURL);
				?>
				
					<input type="hidden" name="currentURL" value="<?php echo$currentURL;?>"/>
					<input type="hidden" name="address_customerId" value="<?php echo$custommerId;?>" />
				
					<input type="reset" class="btn btn-danger btn-sm" value="Reset" />
					&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-primary btn-sm" value="Save Address" />
				</td>
			</tr>
										
			</form>								 
											 
		
							
							<?php 
						}
						  ?>
						  
						</tbody>
					  </table>
				</div>	  
					  </div>
					</div>
					
				
            </div>
        </div> 
          <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->

        </div>
        
        </section>
        <!-- End Feature Product -->
        
	