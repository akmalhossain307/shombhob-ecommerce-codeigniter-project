


        <!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
				
				
						
						<!-- Start Left Feature -->
                   <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12 float-left-style">
                        <!-- Start Slider Area -->
                        
                        
                        
                  
                  
                  
                  <div id="myCarousel" class="carousel slide" data-interval="3000"data-ride="carousel">	  
    <!-- Indicators -->
    <ol class="carousel-indicators">
		<?php 
			$slideCounter=0;
			//$this->load->model('dashboardSettings_model');
			//$sliders=$this->dashboardSettings_model->fetchActiveSliders();
			foreach($slider_info as $slide)
			{
				$slideCounter++;
			
			?>
			<li data-target="#myCarousel" data-slide-to="<?php echo$slideCounter;?>" class="<?php if($slideCounter=='1'){echo'active';} else {echo"";}?>"></li>
			
			<?php } ?>
			
			<!--
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
      <li data-target="#myCarousel" data-slide-to="7"></li>
      <li data-target="#myCarousel" data-slide-to="8"></li>
      <li data-target="#myCarousel" data-slide-to="9"></li>
	  -->
    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
	
			<?php 
			$slideCounter=0;
			
			foreach($slider_info as $slide)
			{
				$slideCounter++;
				$slideURL=$slide->sliderImage;
			?>

      <div class="item <?php if($slideCounter=='1'){echo'active';} else {echo"";}?> bnrSize">
          <a href="<?php echo$slide->sliderURL;?>" target="_blank">
        <img src="<?php echo base_url().$slideURL?>" class="img-fluid" alt="img" style="width:100%;">
        </a>
      </div>
	  
		<?php 
			}
		?>
      
    </div>

    <!-- Left and right controls -->
    
  </div><!-- Close Slider Area -->  
                  
                  
                  
                 
                    
  
         
        <div class="container-fluid">           
         <div class="row"><!--Body Healthcare Sub-Category area start-->
	
	
	
	
		<h2 style="text-align:center;padding-bottom:15px;margin-top:30px" class="categoryTitle">Healthcare Categories</h2>
		
		
		<?php 
	
			$this->load->model('product_model');
			$Subcategory=$this->product_model->productHealthcareSubCategories();
			foreach($Subcategory as $subCat)
			{
				
				
		?>
		<?php $imgURL=$subCat->sub_category_icon;?>
		
		
							<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 sidebarCategory">
								<center>
								<a  href="<?php echo base_url('category/').$subCat->subCategorySlug;?>">
									<img src="<?php echo base_url().$subCat->sub_category_icon;?>" class="img-circle" alt="<?php echo $subCat->subCategorySlug;?>" height="90px">
									<br /><br /></a> 
									 <b>
									<a id="catName" href="<?php echo base_url('category/').$subCat->subCategorySlug;?>"><?php echo $subCat->subCategoryName;?></a>
									</b></center>
								<br />
							</div>
		
		
		
		
		<?php 
			}
		?>
		
	</div><!--Body Healthcare Sub-Category area close-->
	</div>   
	          
                        
    <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->

                   
   </div>
					
					
					
							
					<div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 float-right-style">
                     
                     <!--   
					<div class="logo1">
							
                              <a href="<?php echo base_url();?>">
                                    
                                    
                                    <img src="https://yesbd.com/assets/front-end/images/logo/Yesbd_Logo_with_Tag_line.png" alt="logo"/>
                                    
                            </a>
								
                     </div>	
					-->	
						
						
						
	<div class="categories-menu mrg-xs">				
		<div class="nav-side-menu">
			<div class="category-heading">
                               <h3> Categories</h3>
                            </div>
		<i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list sidebarCategory">
  
            <ul id="menu-content" class="menu-content collapse out">
                <?php 
				$this->load->model('product_model');
				$cnt_offers = $this->product_model->countTotalOffers();
				?>
				
				<a href="<?php echo base_url('offers')?>">
				<li>
                 <span style="color:coral">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Offers <!--(<?php echo$cnt_offers;?>)</span>-->
                </li></a>
				
				<?php 
				$catCounter=0;
			$this->load->model('product_model');
			$category=$this->product_model->productMainCategory();
			foreach($category as $cat)
			{
				$catCounter++;
			?>
			<?php $imgURL=$cat->category_icon;?>
				

                <li  data-toggle="collapse" data-target="#<?php echo$catCounter;?>" class="collapsed">
                  <a href="#">
				<img alt="category icon" src="<?php echo base_url().$imgURL?>" width="20"height="15"> &nbsp;&nbsp;
				  <?php echo$cat->category_name;?> 
				  <span class="arrow" style="padding:0px;font-size:10px"></span>
				  </a>
                </li>
				<ul class="sub-menu collapse" id="<?php echo$catCounter;?>">
				<?php
				$category_id=$cat->category_id;
				$subCategoryByCategory=$this->product_model->productSubCategory($category_id);
				
				if($subCategoryByCategory){
						$counter=0;				
						foreach($subCategoryByCategory as $subCat){
						$counter++;
										
						
						?>
                
                    <li><a href="<?php echo base_url('category/').$subCat->subCategorySlug;?>"> <?php echo$subCat->subCategoryName;?></a></li>
                    
               
				
				<?php 
				}
				}
				echo"</ul>";
			
				}
						
				?>
				
				
            </ul>
     </div>
</div>
</div>

						
						
						
						
						
						
						
						
					 </div>
					
					
					
					
                    
                    <!-- End Left Feature -->
                </div>
            
                    <!-- End Left Feature -->
                </div>
            
		
		<br />
			
			
        </section>
        <!-- End Feature Product -->
        
		


		
		
	<!--	
		
<section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row" style="background:#77inujh;padding:15px;">		
		
		<?php 
		/*
			$this->load->model('DashboardSettings_model');
			$banner_info=$this->DashboardSettings_model->fetchBannerByIdAndStatus();
			foreach($banner_info as $banner)
			{
			    */
				?>
				<a href="<?php //echo base_url('productDetails/7404')?>"><img src="<?php //echo base_url().$banner->bannerImage;?>" alt="banner image..."></a>
				<?php 
			//}
			
			?>
		
				</div>
			</div>
			<br />
			<br />
			
</section>			

	-->	
		
		
		
		
		
	<!-- Start Our Product Area -->
        
       
       
       
    <!-- End Our Product Area -->
       	
		

        
       
        
        