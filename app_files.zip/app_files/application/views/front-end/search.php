 <!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
                   
					
					
					  <!-- Start Left Feature -->
                    <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12 float-left-style">
                        
						
                            <div class="categories_product_area">
                                
								<div class="row">
		<?php 	
if(@$emptyKeyword)
{
	echo"<span style='color:red;font-size:16px'>$emptyKeyword</span> <br /><br /><br /><br /><br /><br />";
}
		
		else if(@$searchedProducts)
		  {
		   foreach($searchedProducts as $row)
		   {
			   
			   $this->load->model('Product_model');
									
									
			 //$this->load->model('Product_model');
			 $get_default_photo = $this->product_model->get_default_photo($row->product_id);
			 $proImage = $get_default_photo['image_url'];
			   
			   
			   if($row->product_status==0)
			   {
			       echo"";
			   }
			   else 
			   {
			   
			   
			   
		
			?>
			
			
			
			
			
			
						<div class="col-lg-2 col-sm-4 col-md-2 col-xs-6">
                                        <div class="l_product_item">
                                            <div class="l_p_img">
											<a title="Click to View Details" class="view_detail quick-view modal-view detail-link" href="<?php echo base_url().$row->slug;?>"> <img src="<?php echo base_url().$proImage;?>" alt="<?php echo $row->title;?>" height="190px"> </a>
                                                
												
												
                                            </div>
                                            <div class="l_p_text">
                                               <ul>
											   <!--
											   <li> <a href=""class="viewTest" id="test">Test</a></li>
											   -->
											  
                                                    <li> <a href="<?php echo base_url().$row->slug;?>" class="btn btn-success">Details</a></li>
                                                    <li>
													
													
							<?php 

                            $pres=$row->product_need_prescription;
                            $type=$row->type;
                            
                            if($pres==1 OR $type=="prescribed")
                            {
                            ?>
                            
								<br/>		
                            	<a href="#prescriptionUploadModal" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary" data-toggle="modal">Add to Bag</a>
                            
                            
                            <?php 
                            }
                            else 
                            {
                            ?>
											
											
											
											
											
									<?php
        									$qty=$row->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
        									    <br/>
								<input type="text" name="submit"class="btn btn-primary disabled" value="Add To Bag"/>
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									    <br/>
        									    <button class=" btn btn-primary add_cart_btn1" data-productid="<?php echo $row->product_id;?>" data-productname="<?php echo $row->title;?>"data-productimage="<?php echo base_url().$proImage;?>" data-productprice="<?php 
													if($row->discountPrice)
													{
													$price=$row->discountPrice;
													}
													else 
													{
													$price=$row->price;	
													}
													echo$price;?>">Add To Bag</button>
        									    
        									    
        									  
        									    <?php 
        									}
								
								?>		
											
													
													
							<?php }?>					
													
													</li>
                                                </ul>
                                                <h4><?php echo $row->title;?></h4>
												<p><?php echo$row->measuringType;?></p>
                                                <h6><span>Price:</span> 
												
												<?php if($row->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $row->price;?></del> TK <?php echo$row->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$row->price;?>
												
												<?php 
												}
												?>
												
												</h6>
                                            </div>
                                        </div>
                                    </div>
									
			
			
			
			
			<?php 
			
			
		   }
		  }
		  }
		  else
		  {
		   //echo"No product found matching your search criteria.<br/><br/><br/>";
		   
		   ?>
		   
		   <div class="row"> 
		   <div class="col-md-1"> </div>
			<div class="col-md-9 col-sm-10 col-xs-12"> 
			
			<span style="color:coral;font-size:16px"> No product found matching your search criteria.</span> <br /><br />
			
			
			<h2 class="text text-info" style="text-decoration:underline">Send Product Request</h2> 
				<form action="<?php echo base_url('search/productRequest')?>" method="POST">
				  <div class="form-group">
					<label for="exampleFormControlInput1">Name</label>
					<input type="text" name="name"class="form-control" id="exampleFormControlInput1" placeholder="enter your name" required>
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1">Phone Number</label>
					<input type="text" name="phone"class="form-control" id="exampleFormControlInput1" placeholder="enter your phone number" required >
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1">Email(Optional)</label>
					<input type="email" name="email"class="form-control" id="exampleFormControlInput1" placeholder="enter email">
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Address</label>
					<textarea class="form-control" name="address"id="exampleFormControlTextarea1" rows="1" required></textarea>
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Product Request</label>
					<textarea class="form-control" name="productName"id="exampleFormControlTextarea1"rows="1" required > </textarea>
				  </div>
				  
				  <div class="text-left"> 
				  <input type="submit" class="btn btn-success btn-lg" value="Send Request" />
				  </div>
				</form>
				<br />
				<br />
				
				
					
			
				
			</div>
			<div class="col-lg-2"></div>
			
			
			
			
			
			
			
			
		   </div>
		   
		   <?php
		   
		  }
			?>					
								
                                   
                                </div>
                              </div>
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
           <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->     
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                              
                     
                    </div>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
						<div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 float-right-style">
                        
						
	<div class="categories-menu mrg-xs">				
		<div class="nav-side-menu">
			<div class="category-heading">
                               <h3> Categories</h3>
                            </div>
		<i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <?php 
				$this->load->model('product_model');
				$cnt_offers = $this->product_model->countTotalOffers();
				?>
				
				<a href="<?php echo base_url('offers')?>">
				<li>
                 <span style="color:coral">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Offers (<?php echo$cnt_offers;?>)</span>
                </li></a>
				
				<?php 
				$catCounter=0;
			$this->load->model('product_model');
			$category=$this->product_model->productMainCategory();
			foreach($category as $cat)
			{
				$catCounter++;
			?>
			<?php $imgURL=$cat->category_icon;?>
				

                <li  data-toggle="collapse" data-target="#<?php echo$catCounter;?>" class="collapsed">
                  <a href="#">
				<img alt="category icon" src="<?php echo base_url().$imgURL?>" width="20"height="15"> &nbsp;&nbsp;
				  <?php echo$cat->category_name;?> 
				  <span class="arrow" style="padding:0px;font-size:10px"></span>
				  </a>
                </li>
				<ul class="sub-menu collapse" id="<?php echo$catCounter;?>">
				<?php
				$category_id=$cat->category_id;
				$subCategoryByCategory=$this->product_model->productSubCategory($category_id);
				
				if($subCategoryByCategory){
						$counter=0;				
						foreach($subCategoryByCategory as $subCat){
						$counter++;
										
						
						?>
                
                    <li><a href="<?php echo base_url('category/').$subCat->subCategorySlug;?>"> <?php echo$subCat->subCategoryName;?></a></li>
                    
               
				
				<?php 
				}
				}
				echo"</ul>";
			
				}
						
				?>
				
				
            </ul>
     </div>
</div>
</div>

						
						
						
						
						
						
						
						
					 </div>
					
					
					
                    
                    <!-- End Left Feature -->
                </div>
            
					
					
				
					
					
					
		
					
					
                    
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        	  

