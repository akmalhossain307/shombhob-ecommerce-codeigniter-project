




 <!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
                   
					
					
					  <!-- Start Left Feature -->
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style">
                        
						<br/><br/><br/><br/>
                    <div class="page-wrap d-flex flex-row align-items-center">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-md-12 text-center">
                                    <span class="display-1 d-block"><h2>404</h2></span>
                                    <div class="mb-4 lead">The page you are looking for was not found.</div>
                                    Call us for help: <i>+8801755697233</i>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    		<br/><br/><br/><br/>		<br/><br/><br/><br/>
                          
                    </div>
					
					
					
					
					
					
                    
                    <!-- End Left Feature -->
                </div>
            
					
					
				
					
					
		 <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
					
                    
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        	  

