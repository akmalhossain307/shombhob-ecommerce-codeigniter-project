			
		<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
                    <!-- Start Left Feature -->
                    <!-- Start Left Feature -->
					<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style">
						<div id="searchResult"></div> <!--Search result will be listed here-->
					</div>
					
                    <!-- Start Left Feature -->
                  
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style" id="hidden4SearchResult">
                        
						<br />
						
						
						
						
						
						
<div class="panel panel-info">
	<div class="panel-heading">Order Information!</div>
		<div class="panel-body">
		
		
		<?php 
		if($orderInfo)
		{
			foreach($orderInfo as $order)
			{
				$order_status=$order->order_delivery_status;
				if($order_status=="On Delivery")
				{
					
					?>
					<div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>  
							
						</button>
<i>Dear customer, your delivery is on the way. Our delivery agent will call you very soon,please keep your contact number active.</i>
					</div>
					<?php
				}
				else if($order_status=="Delivered")
				{
					
					?>
					<div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>  
							
							
						</button>
<i>Dear customer, this order has been <b>delivered. Please contact our helpline for more details.</b></i>
					</div>
					<?php
				}
				
				else if($order_status=="Cancelled")
				{
					
					
					?>
					<div class="alert alert-warning alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>  
						
						
						</button>
<i>Dear customer, this order has been <b>cancelled.</b> Please contact our helpline for more details.</i> 
					</div>
					<?php 
				}
				
				else if($order_status=="Pending")
				{
					?>
					<div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>  
						
						</button>
<i>Dear customer, we are proceccing your order. We will inform you once the order processed.
						Thanks for staying with us.</i>
					</div>
					<?php 
					
				}
			}
		}
		else 
		{
			?>
			<div class="alert alert-danger alert-dismissible" role="alert">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>  
			
			</button>
			The order number you entered is invalid.

			</div>
			<?php 
			
		}
		?>
		
		

	
		



		</div>
</div>
						
						
						
						
					
					
                           
                     	<br />
						<br /><br />
						<br />
						
                    </div>
                  
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
         <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
