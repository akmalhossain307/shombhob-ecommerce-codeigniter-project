
<!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container">
                <div class="row">
                  
					
                    <!-- Start Left Feature -->
                  
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 " id="hidden4SearchResult">
                  <ol class="breadcrumb">
						<li><a href="<?php echo base_url()?>">Home</a></li>
						<?php 
						$this->load->helper('url');
						$currentURL = current_url();
						
						?>
						
						<li><a href="<?php echo$currentURL;?>">Empty Bag</a></li>       
					</ol>
                        <br /> 
                        <br /> 
                        <br /> 
      <h2 style="color:coral">Your shopping Bag is empty. Please buy some product and then proceed to checkout.</h2> <br />
	  <a href="<?php echo base_url();?>" class="btn btn-success">Continue Shopping</a>
	  
						
						
					<br />	
					<br />	
						
			 <!-- Start Footer Area -->
        <?php 
            $this->load->view('front-end/templates/footer_part');
            //require_once(APPPATH."views/front/footer.php");
        ?>
    
    <!-- Close Footer Area -->	
					
						
						
						
	  
					</div>
                    <!-- End Left Feature -->
                </div>
            </div>
			
        </section>
        <!-- End Feature Product -->