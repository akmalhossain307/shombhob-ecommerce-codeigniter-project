




 <!-- Start Feature Product -->
        <section class="categories-slider-area bg__white">
            <div class="container-fluid">
                <div class="row">
                   
					
					
					  <!-- Start Left Feature -->
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 float-left-style">
                        
						<br />
				<br />
				
				<ol class="breadcrumb">
										<li><a href="<?php echo base_url()?>"> <span class="fa fa-home"></span> Home</a></li>
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>
										<li><a href="<?php echo$currentURL;?>">Re-Payment</a></li>
										
										
										<li class="active">Checkout</li>       
										      
				</ol>	<br />
				
				
				
				
				
					<?php if($this->session->flashdata('sdlSuccess')){ ?>
				<div class="alert alert-success alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('sdlSuccess'); ?></strong>
					<script>
						//Using setTimeout to execute a function after 5 seconds.
						setTimeout(function () {
						   //Redirect with JavaScript
						   window.location.href= '<?php echo$currentURL?>';
						}, 4000);
					</script>
				</div>
				
				<?php 
				}
				elseif($this->session->flashdata('sdlError')){ ?>
				
				<div class="alert alert-danger alert-dismissible" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<strong><?php echo $this->session->flashdata('sdlError'); ?></strong>
				</div>
				
				<?php };?>
				
				
				
				
				
                    <div class="page-wrap d-flex flex-row align-items-center">
                        <div class="container">
                            
                          <?php if($this->session->userdata('custmrLogin')==true){ ?> 
                            
                            <div class="panel panel-info">
			  <div class="panel-heading"><h4>Order Summary</h4></div>
			  <div class="panel-body">
							
						
						
						
						<div class="col-md-12"> 
							<div class="panel panel-default">
									<div class="panel-heading">
									<h1 class="panel-title"><b>Set Preferred Delivery Schedule</b></h1>
									</div>
									<div class="panel-body">
											<form action="<?php echo base_url('Checkout/updateDeliverySchedule');?>" method="POST">
											<div class="col-lg-3"> 
											<p>Date: <input style="background:white" type="text" name="deliveryDate" value=""class="form-control Datepicker" id="datepicker" autocomplete="off" readonly=""></p>
										
										
									
											
<script>
  $( function() {
    $( "#datepicker" ).datepicker({ minDate:0, maxDate: "6D",dateFormat: 'dd/mm/yy' });
  } );
  </script>										
											
<script> 
											
	$(function() {
    //$("#datepicker").datepicker();
    $("#datepicker").change(function() {
		
        var selectedDate = $(this).val();
		//alert(selectedDate);
		
		
		
var d = new Date();
var hours=d.getHours();
var date = d.getDate();
var month = d.getMonth() + 1; // Since getMonth() returns month from 0-11 not 1-12
var year = d.getFullYear();
 
var dateStr ="0"+date+"/"+month+"/"+year;

//var inputDate="10/12/2019";

//alert(dateStr);

if(selectedDate==dateStr)
{
//	alert("Inside...Date matched");
	//document.write("Date matched");
	
	if(hours>=9 && hours<=10)
	{
	
		var data="<option value='11to1' selected > 11:00 AM - 1:00 PM</option><option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5'> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=11 && hours<=12)
	{
	
		var data="<option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5'> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=13 && hours<=14)
	{
	
		var data="<option value='3to5' selected> 3:00 PM - 5:00 PM</option><option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	
	else if(hours>=15 && hours<=16)
	{
	
		var data="<option value='5to7' > 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=17 && hours<=18)
	{
		var data="<option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	else if(hours>=19 && hours<=20)
	{
		var data="<option value='7to9' > 7:00 PM - 9:00 PM</option>";
		document.getElementById("deliverySlot").innerHTML=data;
	}
	
	
}
else 
{	
    
    //var data="<option value='9to11' selected >input date not matched with system date</option>";
	var data="<option value='9to11' selected >9:00 AM - 11:00 AM</option><option value='11to1' > 11:00 AM - 1:00 PM</option><option value='1to3' > 1:00 PM - 3:00 PM</option><option value='3to5' > 3:00 PM - 5:00 PM</option><option value='5to7'> 5:00 PM - 7:00 PM</option><option value='7to9' > 7:00 PM - 9:00 PM</option>";
	//$("#deliverySlot").text(data);
	document.getElementById("deliverySlot").innerHTML=data;	
}
});
	
});					

</script>
											
</div>							
									
									
										<div class="col-lg-3"> 
										<span>Schedule</span> 
											<select class="form-control" name="deliverySlot" id="deliverySlot"> 
								
											
											</select>
										</div>
											
											
											
										
										<div class="col-lg-3"> 
										<br>
										<?php 
									$this->load->helper('url');
									$currentURL1 = current_url();
									$order_id=$orderInfo['order_id'];
									?>
									<input type="hidden"name="currentURL" value="<?php echo$currentURL1;?>"/>
									<input type="hidden"name="order_id" value="<?php echo$order_id;?>"/>
										<input type="submit" class="btn btn-primary" name="schedule" value="Update Schedule">
										
										
						
										
										
										
										
										
										
										
										
										</div>
								</form>
								
									</div>
									<br>
									
							</div>	
						</div>	
						
						
						


			
							
									<br>
								<h2>Order Summary</h2> <br>
								
								<div class="table-responsive">
								
								
								<table class="table table-bordered">
								<thead>
								  <tr style="background:#923EFF;color:white">
									<th>Item(s)</th>
									<th>Image</th>
									<th>Unit Price</th>
									<th>Qty</th>
									<th>Sub Total</th>
								  </tr>
								</thead>
										<tbody>
										    
										    
									<?php 
									if($cusOrderDetails){
									    $itemCount=0;
                                    	foreach($cusOrderDetails as $details)
                                    	{
                                    	    $itemCount++;
                                    	    $this->load->model('customer_model');
                                    		$proID=$details->details_item_id;
                                    		$product=$this->customer_model->orderProductDetailsById($proID);
                                    		foreach($product as $pro)
                                    		{
                                    			$this->load->model('product_model');
                                    			$get_default_photo = $this->product_model->get_default_photo($pro->product_id);
                                    			$proImage = $get_default_photo['image_url'];
			
									?>		   
										   
										    
									<tr> 
									
									
    									<td><?php echo$pro->title;?></td>
    									
    									<td><img src="<?php echo base_url().$proImage;?>" alt="" width="90px" height="70px" /></td>
    									
    							        <td><?php echo$details->details_item_unitprice;?></td>
    							        <td><?php echo$details->details_item_quantity;?></td>
    							        <td>TK <?php echo$details->details_item_subtotal;?></td>
						
							        </tr>
								<?php 
                                    		}
                                    	}
									}
								?>
								
															<tr> 
									
									<td colspan="4" align="right"><b>Sub-Total</b></td>
									<td>TK <?php echo$orderInfo['order_total_amount'];?></td>
								</tr>
								
								
								
								<?php if($orderInfo['order_applied_coupon']){?>
    								<tr> 
    									<td colspan="4" align="right"><b>Applied Coupon</b></td>
                    					<td><?php echo$orderInfo['order_applied_coupon'];?></td>
                    				</tr>
                    				<tr> 
                    									
                    					<td colspan="4" align="right"><b>Coupon Discount</b></td>
                    					<td>TK <?php echo$orderInfo['order_coupon_discount'];?></td>
                    				</tr>
								<?php }?>
								<tr> 
									
									<td colspan="4" align="right"><b>Delivery Charge</b></td>
									<td>TK <?php echo$orderInfo['order_delivery_cost'];?></td>
								</tr>
								
											
								
								
								<tr> 
									
									<td colspan="4" align="right"><b>Order Total</b></td>
									<td>TK <?php echo$orderInfo['order_grand_total'];?></td>
								</tr>
			
								
								
								</tbody>
							  </table>
							  
							  
					</div>		  
							  
							  
							  
							  
							  
							  
							  
							  
							  
							  <!--	<form action="" method="POST">     -->
						<div class="row"> 
							<div class="col-md-7"> 
							
								<div class="panel panel-primary">
								<div class="panel-heading">
								<h1 class="panel-title">Delivery Information</h1>
								</div>
								<div class="panel-body">
								    <?php foreach($addressInfo as $address){?>
								    
								<strong>Name: </strong><?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?><br> 
								<strong>Contact: </strong><?php echo$address->address_phone;?>  <br> 
								<strong>Address: </strong>  <?php echo$address->address_address;?> <br> 
								<strong>Area: </strong> <?php echo$address->address_area;?><br> 
								
								<?php 
								    }
								?>
								<strong>Preferred Delivery Schedule:</strong> 
								<input type="hidden" name="address_id" value="225">
								
								<?php 
								if($orderInfo['order_delivery_date'])
								{
								echo$orderInfo['order_delivery_date']." <strong>within</strong> ".$orderInfo['order_delivery_slot'];
								}
								else 
								{
								    echo"Not specified.";
								}
								?>
								
								<br> 
								 
								<input type="hidden" name="deliveryDate" value="">
								<input type="hidden" name="deliverySlot" value="">
								</div>
								</div>
							</div>
							<div class="col-md-5"> 
								<div class="panel panel-primary">
								<div class="panel-heading">
								<h1 class="panel-title">Payment Information</h1>
								</div>
								<div class="panel-body">
								    <?php 
											$payMethod=$orderInfo['order_payment_method'];
								    ?>
									<strong><?php if($payMethod=="COD"){echo"Your Previously Selected Payment Method:";} else if($payMethod=="SSL"){echo"Payment Method:";}?> </strong><br><table class="table table-bordered">
										<tbody>
										     
																							
										<?php 
											$payMethod=$orderInfo['order_payment_method'];
											if($payMethod=="COD")
											{
												?>
												<img src="<?php echo base_url()?>/assets/front-end/images/cod.png" alt="Cash on Delivery payment" width="200px" height="100px">
											
											<?php 
											}
											else if($payMethod=="SSL")
											{
												?>
												<img src="<?php echo base_url()?>/assets/front-end/images/ssl.png" alt="Card payment" width="200px" height="100px">
												<?php 
											}												
												
											?>	
																						
										
										
											
										
										  
										</tbody>
									  </table>
								
								
								
								</div>
								</div>
							</div>
							
							<br>
							<br>
							
							
							
						</div>	
							  
							  
							  
							  
							  
							  
						 <?php 
											
							if($payMethod=="SSL" || $payMethod=="COD")
							{
							?>
							<h2 style="color:coral">Do you want to pay now?</h2> <br />
							
							<form action="<?php echo base_url()?>requestssl1" method="POST">
							    
							
							<img src="<?php echo base_url()?>assets/front-end/images/SSLCommerz-logo.png" width="35%"alt="ssl payment channels">
							
							<br />
							<br/>
							<br/>
						
							
							<table>
                				<tr>
                				
                					<td><input type="hidden" name="fname" required class="tbox" autofocus placeholder="Name" value="<?php if($address->name==false){?> <?php echo$address->address_first_name;?> <?php echo$address->address_first_name;?> <?php } else { echo$address->name;}?>"></td>
                				</tr>
                				<?php 
                				
                				$this->load->model('customer_model');
								$cust_id=$orderInfo['order_customerid'];
		
								$customer_info=$this->customer_model->fetchCustomerById($cust_id);
								 foreach($customer_info as $cus)
								 {
                				?>
                				
                				<tr>
                				
                					<td><input type="hidden" name="email" required class="tbox" placeholder="Email" value="<?php echo $cus->email; ?>"></td>
                				</tr>
                				<?php 
								 }
                				?>
                				
                				<tr>
                			
                					<td><input type="hidden" name="phone" required class="tbox" placeholder="Phone" value="<?php echo$address->address_phone;?>"></td>
                				</tr>
                				
                				
                			<!--
                				<tr>
                				
                					<td><input type="text" name="amount" required value="5.00" class="tbox" placeholder="Amount"></td>
                				</tr>
                			-->
                				
                				<tr>
                				
                					<td><input type="hidden" name="country" required class="tbox" placeholder="Country" value="Bangladesh"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="address" required class="tbox" placeholder="Address" value="<?php echo$address->address_address;?>"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="street" required class="tbox" placeholder="Street Address" value="<?php echo$address->address_area;?>"></td>
                				</tr>
                				<tr>
                				
                					<td><input type="hidden" name="state" required class="tbox" placeholder="State" value="<?php echo$address->address_area;?>"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="city" required class="tbox" placeholder="City" value="Dhaka"></td>
                				</tr>
                				<tr>
                					
                					<td><input type="hidden" name="postcode" required class="tbox" placeholder="Post Code" value="1208"></td>
                				</tr>
                			
                			</table>
                			
                			
    <?php //echo$this->cart->total_items()?>
     <input type="hidden" name="order_number" value="<?php echo$orderInfo['order_number'];?>"/>   
      <input type="hidden" name="order_id" value="<?php echo$orderInfo['order_id'];?>"/>
     <input type="hidden" name="address_id" value="<?php echo$address->address_id;?>"/>			
    <input type="hidden" name="deliveryDate" value="<?php echo@$orderInfo['order_delivery_date'];?>" />
	<input type="hidden" name="deliverySlot" value="<?php echo@$orderInfo['order_delivery_slot'];?>" />           			
    <input type="hidden"name="cartTotal" value="<?php echo@$orderInfo['order_total_amount'];?>" />
	<input type="hidden"name="delivery_cost" value="<?php echo@$orderInfo['order_delivery_cost'];?>" />
	<input type="hidden"name="coupon_code" value="<?php echo@$orderInfo['order_applied_coupon'];?>" />
	<input type="hidden"name="coupon_discount_amount" value="<?php echo@$orderInfo['order_coupon_discount'];?>" />
	<input type="hidden"name="grandTotal" value="<?php echo $orderInfo['order_grand_total'];?>" />
<!--	<input type="hidden"name="grandTotal" value="10" /> -->
	 <input type="hidden" name="items" value="<?php echo$itemCount;?>"/> 					
							
	
	
	<div class="text-center">
	
	 <?php 
	 if($orderInfo['order_grand_total']<260)
	 {
		 ?>
		 <span style="color:red;font-size:15px">Minimum order Amount is: 200Tk </span>
		 <input type="button" value="Pay & confirm Order Now" class="btn btn-primary btn-block disabled">
		 <?php 
	 }
	 else 
	 {
	 ?>
							
	<input type="submit" name="submit" value="Pay & confirm Order Now" class="btn btn-primary ">
	
	<?php 
	 }
	?>
	</div>
	
	
	
	
	<!--<a href="<?php //echo base_url()?>requestssl" class="btn btn-danger btn-block">Pay & confirm Order Now</a> -->
							
				
							
							</form>
							
							
							<?php 
							    
							    
							}   
							else 
							{
							    
							    echo"<strong>Something went wrong with selecting payment method. Please check and then try again. </strong>";
							
							?>
							   
							  
			
					
			<?php 
							}
			
			?>	  
							  
							  
					
					<br>
					<br>
					<br>
					<br>
					
					
					
                </div>
			
                </div>
                            
                          
                           <?php  
                          }
                          else 
                          {
                              echo"<div class='alert alert-warning'>
    <strong>Warning!</strong> Dear customer, you are logged out. Please login to continue.
  </div>";
                          }
                           ?> 
                            
                        </div>
                    </div>
                    	
                          
                    </div>
					
					
					
					
					
					
                    
                    <!-- End Left Feature -->
                </div>
            
					
					
				
					
					
					
			 <!-- Start Footer Area -->
        
            <div class="container-fluid">
                <div class="row">
                    <div class="footer__container clearfix footr">
                         <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4 col-sm-6">
                            <div class="ft__widget">
                                <div class="ft__logo">
                                    <a href="<?php echo base_url();?>">
                                        <img src="<?php echo base_url('assets/front-end')?>/images/logo/Yesbd_Logo_with_Tag_line.png" alt="footer logo">
                                    </a>
                                </div>
                                <div class="footer-address">
                                    <ul>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-pin"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>232-234,Tejgaon Industrial Area, Dhaka-1208, Bangladesh.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-email"></i>
                                            </div>
                                            <div class="address-text">
											<a href="mailto:info@yesbd.com">info@yesbd.com</a>
                                                
                                            </div>
                                        </li>
                                        <li>
                                            <div class="address-icon">
                                                <i class="zmdi zmdi-phone-in-talk"></i>
                                            </div>
                                            <div class="address-text">
                                                <p>09612779900 </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <ul class="social__icon">
									<li><a href="https://www.facebook.com/yesbdpharmacy" target="_blank"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-twitter"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-instagram"></i></a></li>
                                    
                                    <li><a href="#"><i class="zmdi zmdi-google-plus"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- End Single Footer Widget -->
                        
                        <div class="col-md-4 col-lg-4 col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Infomation</h2>
							<ul class="footer-categories">
						
							<li><a href="<?php echo base_url('page/faq');?>" target="_blank">FAQ</a></li>
						
							<li><a href="<?php echo base_url('page/about-us');?>" target="_blank">About Us</a></li>
							<li><a href="<?php echo base_url('page/privacy-confidentiality');?>" target="_blank">Privacy and Confidentiality</a></li>
							<li><a href="<?php echo base_url('page/terms-conditions');?>" target="_blank">Terms and Conditions</a></li>
							<li><a href="<?php echo base_url('page/return-refund-policy');?>" target="_blank">Return and Refund Policy</a></li>
							<li><a href="<?php echo base_url('page/how-to-order');?>" target="_blank">How to Order</a></li>
							<li><a href="<?php echo base_url('page/contact');?>" target="_blank">Support/Contact Us</a></li>
							<li><a href="<?php echo base_url('page/sitemap');?>" target="_blank">Sitemap</a></li>
							
							
						</ul>
                            </div>
                        </div>
                        
                        
                        <!-- Start Single Footer Widget -->
                        <div class="col-md-4 col-lg-4  col-sm-6 smt-30 xmt-30">
                            <div class="ft__widget">
                                <h2 class="ft__title">Newsletter</h2>
                                <div class="newsletter__form">
                                    <p>Get all the latest information on Events,
Sales and Offers. Sign up for newsletter today.</p>
                                    <div class="input__box">
                                        <div id="mc_embed_signup">
                                            <form action="<?php echo base_url('search/addSubscribe')?>" method="post">
                                                <div id="mc_embed_signup_scroll" class="htc__news__inner">
                                                    <div class="news__input">
                                                        <input type="email"  name="email" class="email" placeholder="Email Address" required>
                                                    </div>
                                                    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                                   
                                                    <div class="clearfix subscribe__btn"><input type="submit" title="Send"value="Send" name="subscribe" id="mc-embedded-subscribe" class="bst__btn btn--white__color">
                                                        
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>        
                                </div>
                            </div>
							<br />
						
							<img src="<?php echo base_url('assets/front-end/images/SSLCommerz-logo.png')?>" alt="ssl_images" width="100%"height="80px"/>
							
							<br/>	<br/>
							<span style="color:violet;text-align:center;">
                             
                                    © <?php echo date('Y');?> <a href="https://yesbd.com/">Yesbd.com Ltd.</a>
                                    All Right Reserved.
                             </span>
							
                        </div>
                        <!-- End Single Footer Widget -->
                       
                    </div>
                </div>
                
                
            </div><!-- Close Footer Area -->		
					
					
					
					
                    
                </div>
            </div>
        </section>
        <!-- End Feature Product -->
        
        
        
        	  

