<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12 float-right-style">
                        <div class="categories-menu mrg-xs">
                            <div class="category-heading">
                               <h3> Browse Categories</h3>
                            </div>
							
							<div class="category-menu-list sidebarCategory">
                                <ul>
								<li> 
								<?php 
								$this->load->model('product_model');
										$cnt_offers = $this->product_model->countTotalOffers();
									?>
									
									<a href="<?php echo base_url('offers')?>"> Offers <!-- <span style="color:coral"> (<?php //echo$cnt_offers;?>)</span>--></a>
								</li>
								
                                    
									<?php 
										$this->load->model('product_model');
										$category=$this->product_model->productMainCategory();
										foreach($category as $cat)
										{
									?>
									<?php $imgURL=$cat->category_icon;?>
									<li><a href="<?php echo base_url('products/category/').$cat->category_id;?>"><img alt="" src="<?php echo base_url().$imgURL?>"> <?php echo$cat->category_name;?><i class="zmdi zmdi-chevron-right"></i></a>
									
									<?php
									$category_id=$cat->category_id;
									$subCategoryByCategory=$this->product_model->productSubCategory($category_id);
									
									if($subCategoryByCategory){
											$counter=0;
											?>
										
									
									<div class="category-menu-dropdown">
									
									
										<div class="row"> 
											<div class="col-md-12">
											<h3 class="btn btn-primary btn-block">SUB CATEGORIES</h3> <br />
											<ul id="subCategory" class="nav nav-tabs nav-pills" >
												
												<?php 
											
											foreach($subCategoryByCategory as $subCat){
											$counter++;
											?>
											<div class="col-lg-4">
                                                       <li > <a href="<?php echo base_url('products/sub-category/').$subCat->subcat_id;?>"> <?php echo$subCat->subCategoryName;?></a>
														</li>
											</div>			
                                             <?php 	
											}
											?>
											
												
											</ul>
											
											</div>
										</div>	
									  
                                        </div>
									<?php 
											}
											else 
											{
												echo"";
											}	
                                             ?>	
										
										
									</li>
					<?php }?>
									
                                </ul>
                            </div>
                        
							
							
							
						</div>
                    </div>
					