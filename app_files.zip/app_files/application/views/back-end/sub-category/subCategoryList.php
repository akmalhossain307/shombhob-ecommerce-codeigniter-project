<!-- Modal -->
				<div class="modal fade" id="addSubCategoryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Add Sub-Category</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
					   <form action="<?php echo base_url('admin/subCategory/create')?>" method="POST">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Sub-Category Name</strong></label>
							<input type="text" name="subCategoryName"class="form-control" placeholder="sub category name" required>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Main Category</strong></label>
							<select class="form-control" name="mainCategoryName" required >
							<?php foreach($categories as $cat){?>
							  <option value="<?php echo$cat->category_name;?>"><?php echo$cat->category_name;?></option>
							<?php }?>
							  
							</select>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
							</select>
						  </div>
					 
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
						<button type="submit"class="btn btn-primary btn-sm">Save</button>
					  </div>
					    
					   </form>
					</div>
				  </div>
				</div>
	
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
					 
					<?php } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
				
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Sub-Category</h4>
                  <div class="text-right"> 
				  
				  <a href="<?php echo base_url('admin/subCategory/create')?>" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Add New</a>
				   
				  </div>
				  
				  <div class="row">
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                              <th>SL No#</th>
                              <th>Sub-Category</th>
                              <th>Main-Category</th>
                              <th>Status</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$sl=0;
						if($subCategories)
						{
						foreach ($subCategories as $category){
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><img src="<?php echo base_url().$category->sub_category_icon;?>" alt="" /> <?php echo$category->subCategoryName?></td>
                              <td>
							  
							  <?php 
							  $this->load->model('dashboardCategory_model');
							  $mainCat=$this->dashboardCategory_model->fetchMainCatBySubCat($category->category_id);
							  echo$mainCat['category_name'];?>
							  
							  </td>
                              <td>
							  <?php $status=$category->status;
							  if($status==1){
							  ?>
                                <a href="<?php echo base_url('DashboardCategory/deactivateSubCategory/').$category->subcat_id;?>" class="badge badge-success" title="Deactivate Now!">Active</a>
							  <?php } 
							  else 
							  {?>
						  <a href="<?php echo base_url('DashboardCategory/activateSubCategory/').$category->subcat_id;?>" class="badge badge-danger" title="Activate Now!">Inactive</a>
							  <?php }?>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                <a href="<?php echo base_url('admin/subCategory/view/').$category->subcat_id;?>">  <i class="mdi mdi-pencil text-primary"></i>Edit</a>
                                </button>
                                <button class="btn btn-light">
                                 <a href="<?php echo base_url('admin/subCategory/delete/').$category->subcat_id;?>" onclick="return confirm('Are you sure to delete this sub-category?')"> <i class="mdi mdi-close text-danger"></i>Remove </a>
                                </button>
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No sub-category found.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
				  
				  
				  
				  
               </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        