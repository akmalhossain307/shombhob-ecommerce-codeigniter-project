
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
             
				<div class="row"> 
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="fa fa-plus-square text-success"></i> Create Sub-Category</strong>
					  </div>
					  <div class="card-body text-success">
					  
					  <form action="<?php echo base_url('admin/subCategory/save')?>" method="POST" enctype="multipart/form-data" >
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Sub-Category Name</strong></label>
							<input type="text" name="subCategoryName"class="form-control" placeholder="sub category name" required>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Sub-Category Icon</strong></label>
							
							<input type="file" name="sub_category_icon"class="form-control">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Main Category</strong></label>
							<select class="form-control" name="mainCategoryName" required >
							<?php foreach($categories as $cat){?>
							  <option value="<?php echo$cat->category_id;?>"><?php echo$cat->category_name;?></option>
							<?php }?>
							  
							</select>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
							</select>
						  </div>
					 
						<input type="submit" class="btn btn-info btn-sm" value="Create" />
						  <a href="<?php echo base_url('admin/subCategoryList')?>" class="btn btn-warning btn-sm">Back</a>
					 
					 
					  </div>
					 
					    
					   </form>
					  
					  
					  </div>
					</div>
				
				</div>
				<div class="col-md-2"></div>
				</div>
				
				<br />
				<br />
				
				
				
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        