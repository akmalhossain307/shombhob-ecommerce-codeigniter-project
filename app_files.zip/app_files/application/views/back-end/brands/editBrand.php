		
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
             
				<div class="row"> 
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="card">
					  <div class="card-header">
						<strong> Update Brand</strong>
					  </div>
					  <div class="card-body">
					  <?php if($brand){
						  foreach($brand as $bra)
						  {
					  
					  ?>
					  
						<form action="<?php echo base_url('admin/brand/update/').$bra->brand_id;?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Brand Name</strong></label>
							<input type="text" name="brand_name"class="form-control" value="<?php echo$bra->brand_name;?>" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Brand Logo</strong></label>
							<?php $imgURL=$bra->brand_logo;?>
							  <img src="<?php echo base_url().$imgURL?>" class="rounded-circle" alt="brang logo" width="70"height="60"/>
							<input type="file" name="brand_logo"class="form-control">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <?php 
							  $sts=$bra->status;
							  if($sts==1)
							  {
								  echo" <option value='1' selected>Active</option>";
								  echo" <option value='0'>Inactive</option>";
							  }
							  else 
							  {
								 echo" <option value='0' selected>Inactive</option>";
								 echo" <option value='1'>Active</option>";								 
							  } 
							 
							  ?>
							 
							</select>
						  </div>
						  <input type="submit" class="btn btn-info btn-sm" value="Update" />
						  <a href="<?php echo base_url('admin/brandList')?>" class="btn btn-warning btn-sm">Back</a>
						</form>
						
					  <?php } }?>
					  </div>
					</div>
				
				</div>
				<div class="col-md-3"></div>
				</div>
				
				<br />
				<br />
				
				
				
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        