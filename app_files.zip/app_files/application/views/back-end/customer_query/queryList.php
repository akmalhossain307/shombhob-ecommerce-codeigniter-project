	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
					<?php 
				}
				
					elseif($this->session->flashdata('categoryExist')){ ?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('categoryExist'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					  
					  
					<?php } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
					
					
				<div class="text-right"> 
				 <a target="_blank"href="<?php echo base_url('customer/customerList');?>" class="btn btn-info btn-sm">Print customer query list</a> 
				 </div>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Query List</h4>
                 
                  <div class="row">
                    <div class="col-12 table table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                              <th>SL No#</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Message</th>
                               <th>Query Date</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$sl=0;
						if($query)
						{
						foreach ($query as $q){
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><?php echo$q->name;?></td>
							  
                              <td><?php echo$q->email;?></td>
                             <td><?php echo$q->message;?></td>
                               <td><?php echo$q->entry_date;?></td>
                              <td>
                                
                                <a href="<?php echo base_url('admin/query/view/').$q->id;?>" class="btn btn-light">  <i class="mdi mdi-eye text-primary"></i>Deatils</a> &nbsp;&nbsp;
								<a href="<?php echo base_url('admin/query/delete/').$q->id;?>" onclick="return confirm('Are you sure to delete this query?')"  > <i class="mdi mdi-close text-danger"></i>Remove </a>
								
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No customer found.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        