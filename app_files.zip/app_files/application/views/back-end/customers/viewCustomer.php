		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					<div class="card">
					  <div class="card-header">
						<strong> <i class=" link-icon fa fa-eye"></i> View Customer Details</strong>
					  </div>
					  <div class="card-body">
					  
						<table class="table table-bordered table-hover">
						  
						  
						  <tbody>
						  
						  <?php foreach($customer as $cus){?>
							<tr>
							  <th colspan="2">Name</th>
							  <td colspan="4"><?php echo$cus->name;?></td>
							</tr>
							<tr>
							  <th colspan="2">Photo</th>
							  <td colspan="4"><img id="img" src="<?php echo base_url('assets/uploads/preview.png')?>" alt="product image" /></td>
							</tr>
							<tr>
							  <th colspan="2">Email</th>
							  <td colspan="4"><?php echo$cus->email;?></td>
							</tr>
							<tr>
							  <th colspan="2">Phone</th>
							  <td colspan="4"><?php echo$cus->mobile;?></td>
							</tr>
							
							
						  <?php } ?>
							
						  </tbody>
						</table>
						<br />
							<br />
							<br />
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						
						<a href="<?php echo base_url('admin/customerList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        