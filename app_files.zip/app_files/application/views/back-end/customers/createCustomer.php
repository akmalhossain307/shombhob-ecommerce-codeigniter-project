		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					<div class="card">
					  <div class="card-header">
						<strong> <i class=" link-icon fa fa-pencil"></i> Create New Product</strong>
					  </div>
					  <div class="card-body">
					  
						<form action="<?php echo base_url('admin/product/save');?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Product Title</strong></label>
							<input type="text" name="title"class="form-control" placeholder="title" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Short Description</strong></label>
							<input type="text" name="shortDescription"class="form-control" placeholder="short description" >
						  </div>
						  <div class="row"> 
						  <div class="col-md-6">
							<div class="form-group">
						
							<label for="exampleFormControlSelect2"> <strong> Select  Category</strong></label>
							<select class="form-control" name="mainCategory"id="mainCategory" required >
							  <option>Select Category</option>
							  <?php foreach($categories as $category){
								?>
							  <option value="<?php echo$category->category_name;?>"><?php echo$category->category_name;?></option>
							  <?php }?>
							  
							</select>
						  </div>
						  </div>
						  <div class="col-md-6">
						  <div class="form-group">
						  
							<label for="exampleFormControlSelect2"><strong>Select Sub-category</strong></label>
							<select class="form-control" name="subCategory"id="subCategory" required >
							  
							</select>
						  </div>
						  </div>
						  </div>
						  
						<div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Select Brand(If have)</strong></label>
							<select class="form-control" name="brand"id="exampleFormControlSelect2">
							  <?php foreach($brands as $brand){?>
							  <option value="<?php echo$brand->brand_name;?>"><?php echo$brand->brand_name;?></option>
							  <?php 
							  }
							  ?>
							</select>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Product Attribute</strong></label>
							<select class="form-control" name="attribute" id="exampleFormControlSelect2">
							  <option value="normal">Normal</option>
							  <option value="prescription_needed">Need Prescription</option>
							  <option value="featured">Featured</option>
							  <option value="new">New</option>
							  <option value="hot">Hot</option>
							</select>
						  </div>
						  <div class="form-group">
						  <div class="text-right"> 
								<img id="img" src="<?php echo base_url('assets/uploads/preview.png')?>" alt="product image" />
							</div>
							<label for="exampleFormControlSelect2"><strong>Product Picture</strong></label>
							<input type='file' name="productImage"class="form-control"onchange="readURL(this);" />
							
							
							
						  </div> 

						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Original Price</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">TK</span>
                          </div>
                          <input type="text" name="price"class="form-control" aria-label="Amount (to the nearest dollar)" placeholder="original price" required >
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
						</div>
						
						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Discount Price</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">TK</span>
                          </div>
                          <input type="text" name="discountPrice"class="form-control" aria-label="Amount (to the nearest dollar)" placeholder=" Discount price if have">
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
						</div>
						
						<div class="row"> 
						  
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Stock Qty</strong></label>
							<input type="number" name="stockQty"class="form-control" placeholder="quantity"required >
						  </div>
						  </div>
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Min Order Qty</strong></label>
							<input type="number" name="minOrderQty"class="form-control" placeholder="e.g. 2" required >
						  </div>
						  </div>
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Measuring Type</strong></label>
							<input type="text" name="measuringType"class="form-control"  placeholder="e.g. ml,kg,piece,set..."required >
						  </div>
						  </div>
						  
						</div>
						<div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  
							 <option value='1' selected >Published</option>
							 <option value='0'>Unpublished</option>
							</select>
						  </div>
						<label for="exampleFormControlSelect2"><strong>Product Description</strong></label>
						
						<textarea name="productDescription" id="summernoteExample" cols="30" rows="10"></textarea>
						
						<label for="exampleFormControlSelect2"><strong>Additional Info</strong></label>
						
						  <textarea id="simpleMde" name="additionalInfo"style="display: none;">     </textarea>
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Meta Keywords</strong></label>
							<textarea name="metaKeywords" id="" class="form-control" cols="30" rows="10"></textarea>
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Meta Description</strong></label>
							<textarea name="metaDescription" class="form-control"id="" cols="30" rows="10"></textarea>
						  </div>
						  
					
					
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Save" />
					 
						<a href="<?php echo base_url('admin/productList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        