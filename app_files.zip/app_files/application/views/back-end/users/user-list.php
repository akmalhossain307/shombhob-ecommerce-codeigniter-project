	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
					<?php 
				}
				
					elseif($this->session->flashdata('categoryExist')){ ?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('categoryExist'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					  
					  
					<?php } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
					
					
				<div class="text-right"> 
				  
				 </div>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage User</h4>
                 
                  <div class="row">
                    <div class="col-12 table table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light">
                              <th>SL No#</th>
                              <th>Name</th>
                              <th>User name</th>
                              <th>User Role</th>
                              <th>Status</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$sl=0;
						if($userInfo)
						{
						foreach ($userInfo as $user){
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><?php echo$user->name?></td>
                              <td><?php echo$user->user_name?></td>
                              <td>
                                  
                                 <?php if($user->user_role=="admin")
                                 {
                                     echo"Admin";
                                 }
                                 else 
                                 {
                                     echo"General User";
                                 }
                                 
                                 ?>
                              
                              
                              </td>
                              <td><?php $sts=$user->status;
							  if($sts==1)
							  {
								 echo"<span style='color:blue;background:#ddd;font-weight:20px;'>Active</span>";  
							  }
							  else 
							  {
								 echo"<span style='color:red;background:#ddd;font-weight:20px;'>Inactive</span>"; 
							  }
							  ?></td>
                             
                              <td>
                               
								<a href="<?php echo base_url('admin/delete-user/').$user->id;?>" onclick="return confirm('Are you sure to delete this user?')"  > <i class="mdi mdi-close text-danger"></i>Remove </a>
								
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No user found.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        