		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					
					
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>	
					  
				<form action="<?php echo base_url('admin/change-password');?>" method="POST" enctype="multipart/form-data">
				
				  <div class="form-group">
					
					<div class="card border-success">
					
						  <div class="card-header" style="background:#dfe8fb"><i class="fa fa-pencil-square-o bigfonts" aria-hidden="true"></i><b> Change User Password</b></div>
						  <div class="card-body text-success">
						  
						  <?php echo validation_errors(); ?> <br /> 
						  
					
							  <div class="form-group">
								<label for="exampleInputEmail1"><h5>User Name</h5></label>
									<input type="email"class="form-control" name="user_name"value="<?php echo set_value('user_name');?>" placeholder="Enter username" />
								
							  </div>
							  
							  <div class="form-group">
								<label for="exampleInputEmail1"><h5>Old Password</h5></label>
									<input type="password"class="form-control" value="<?php echo set_value('old_password');?>" name="old_password" placeholder="Enter password" />
								
							  </div>
							  <div class="form-group">
								<label for="exampleInputEmail1"><h5>New Password</h5></label>
									<input type="password"class="form-control" value="<?php echo set_value('new_password');?>" name="new_password" placeholder="New password" />
								
							  </div>
						  
						  <br /> <br /> <br /> <br /> <br /> <br /> <br /> 
							
						  </div>
					
					</div>
				  </div>
				  
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<button type="submit" class="btn btn-success btn-sm">Change Password</button>
						<button type="reset" class="btn btn-danger btn-sm">Reset</button>
					 <br />
					 <br />
					</div>
					
				</div>
				
					</form>
			
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        