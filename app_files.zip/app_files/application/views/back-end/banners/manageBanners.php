		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-12">
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
					<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
					<div class="card card-center border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="link-icon mdi mdi-flag-outline"></i> Manage Banners</strong>
					  </div>
							 <div class="text-left" style="margin-left:30px;margin-top:15px;margin-bottom:-15px"> 
							   <a href="<?php echo base_url('admin/banner/create')?>" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Add New</span></a>
							  </div>
					  
					  <div class="card-body">
					  
						<table class="table table-bordered table-hover">
						  
						  
						  <tbody>
						  
						  
							<tr>
							  <th>Sl No#</th>
							  <th colspan="4">Banner Image</th>
							  <th>Status</th>
							  <th colspan="2">Action</th>
							</tr>
							<?php if($banners){
								$sl=0;
								foreach($banners as $banner){
									$sl++;
									?>
							<tr>
							  <td><?php echo$sl;?></td>
							  <td colspan="4"><?php $imgURL=$banner->bannerImage;
							  ?> <img src="<?php echo base_url().$imgURL;?>" alt="banner image" id="bannerImage"/></td>
							  <td><?php $sts=$banner->status;
							  if($sts==1)
							  {
								 echo"<label class='badge badge-success'>Published</label>" ;
							  }
							  else 
							  {
								  echo"<label class='badge badge-danger'>Unpublished</label>";
							  }?>
							  </td>
							  <th colspan="2">
								<a href="<?php echo base_url('admin/banner/edit/').$banner->banner_id;?>" class="btn btn-light" >  <i class="mdi mdi-pencil text-primary"></i>Edit</a>&nbsp;&nbsp; 
								<a href="<?php echo base_url('admin/banner/delete/').$banner->banner_id;?>" onclick="return confirm('Are you sure to delete this Banner?')"  > <i class="mdi mdi-close text-danger"></i>Remove </a>
							  
							  </th>
							</tr>
							<?php } }?>
							
						  </tbody>
						</table>
						
					  </div>
					</div>
				
				</div>
				
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        