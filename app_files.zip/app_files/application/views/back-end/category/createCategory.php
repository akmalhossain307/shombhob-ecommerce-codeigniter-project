
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
             
				<div class="row"> 
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="fa fa-plus-square text-success"></i> Create Category</strong>
					  </div>
					  <div class="card-body text-success">
					  
						<form action="<?php echo base_url('admin/category/create')?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Name</strong></label>
							<input type="text" name="category_name"class="form-control"  required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Icon</strong></label>
							
							<input type="file" name="category_icon"class="form-control">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
							</select>
						  </div>
						  <input type="submit" class="btn btn-info btn-sm" value="Create" />
						  <a href="<?php echo base_url('admin/categoryList')?>" class="btn btn-warning btn-sm">Back</a>
						</form>
						<br />
						<br />
						<br />
						<br />
					  </div>
					</div>
				
				</div>
				<div class="col-md-2"></div>
				</div>
				
				<br />
				<br />
				
				
				
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        