		<!-- Modal -->
				<div class="modal fade" id="addCategoryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header ">
						<h5 class="modal-title" id="exampleModalLabel">Add New Category</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body text-success">
					   <form action="<?php echo base_url('admin/category/create')?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Name</strong></label>
							<input type="text" name="category_name"class="form-control" placeholder="category name" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Icon</strong></label>
							<input type="file" name="category_icon"class="form-control" required>
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
							</select>
						  </div>					   
				
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary btn-sm">Save </button>
					  </div>
				</form> 
					  
					</div>
				  </div>
				</div>
	
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
             
				<div class="row"> 
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="fa fa-pencil text-success"></i> Update Category</strong>
					  </div>
					  <div class="card-body text-success">
					  <?php if($category){
						  foreach($category as $cat)
						  {
					  
					  ?>
					  
						<form action="<?php echo base_url('admin/category/update/').$cat->category_id;?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Name</strong></label>
							<input type="text" name="category_name"class="form-control" value="<?php echo$cat->category_name;?>" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Category Icon</strong></label>
							<?php $imgURL=$cat->category_icon;?>
							  <img src="<?php echo base_url().$imgURL?>" class="rounded-circle" alt="category icon" width="70"height="60"/>
							<input type="file" name="category_icon"class="form-control">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <?php 
							  $sts=$cat->status;
							  if($sts==1)
							  {
								  echo" <option value='1' selected>Active</option>";
								  echo" <option value='0'>Inactive</option>";
							  }
							  else 
							  {
								 echo" <option value='0' selected>Inactive</option>";
								 echo" <option value='1'>Active</option>";								 
							  } 
							 
							  ?>
							 
							</select>
						  </div>
						  <input type="submit" class="btn btn-info btn-sm" value="Update" />
						  <a href="<?php echo base_url('admin/categoryList')?>" class="btn btn-warning btn-sm">Back</a>
						</form>
						
					  <?php } }?>
					  
					  <br />
					  <br />
					  
					  </div>
					</div>
				
				</div>
				<div class="col-md-3"></div>
				</div>
				
				<br />
				<br />
				
				
				
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        