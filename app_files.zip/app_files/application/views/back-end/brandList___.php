<!-- Modal -->
				<div class="modal fade" id="addBrandModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog" role="document">
					<div class="modal-content">
					  <div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Add New Brand</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
					   <form action="" method="POST">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Brand Name</strong></label>
							<input type="text" class="form-control" placeholder="category name">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Brand Logo</strong></label>
							<input type="file" class="form-control">
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status">
							  <option value="1">Active</option>
							  <option value="0">Inactive</option>
							</select>
						  </div>
					   
					   </form>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary btn-sm">Save changes</button>
					  </div>
					</div>
				  </div>
				</div>
	
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Brand</h4>
                  <div class="text-right"> 
				  
				  
				   <a href="" data-toggle="modal" data-target="#addBrandModal" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Add New</span></a>
				  </div>
				  
                  <div class="row">
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center">
                              <th>SL No#</th>
                              <th>Title</th>
                              <th>Thumbnail</th>
                              <th>Status</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                              <td>01</td>
                              <td>category One</td>
                              <td>thumbnail</td>
                              <td>
                                <label class="badge badge-success">Open</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-62</td>
                              <td>Doe</td>
                              <td>Brazil</td>
                            
                              <td>
                                <label class="badge badge-danger">Closed</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-63</td>
                              <td>Sam</td>
                              <td>Tokyo</td>
                             
                              <td>
                                <label class="badge badge-success">Closed</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-64</td>
                              <td>Joe</td>
                              <td>Netherland</td>
                             
                              <td>
                                <label class="badge badge-warning">Open</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-65</td>
                              <td>Edward</td>
                              <td>Indonesia</td>
                              
                              <td>
                                <label class="badge badge-success">Closed</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-66</td>
                              <td>Stella</td>
                              <td>Japan</td>
                              
                              <td>
                                <label class="badge badge-info">On hold</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-67</td>
                              <td>Jaqueline</td>
                              <td>Germany</td>
                             
                              <td>
                                <label class="badge badge-success">Closed</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
                          <tr>
                              <td>WD-68</td>
                              <td>Tim</td>
                              <td>Italy</td>
                              
                              <td>
                                <label class="badge badge-warning">Open</label>
                              </td>
                              <td class="text-right">
                                <button class="btn btn-light">
                                  <i class="mdi mdi-eye text-primary"></i>View
                                </button>
                                <button class="btn btn-light">
                                  <i class="mdi mdi-close text-danger"></i>Remove
                                </button>
                              </td>
                          </tr>
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        