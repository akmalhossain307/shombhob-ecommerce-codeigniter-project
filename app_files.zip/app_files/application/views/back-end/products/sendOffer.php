		
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
			
			
			
			
			
			
			
			
				
				<div class="col-md-9">
				    
				    
				    
				    
				    <?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				    
				    
				    
				    
				    
				    
				    
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="fa fa-plus-square text-success"></i> Create New Product</strong>
					  </div>
					  <div class="card-body text-success">
					  
						<form action="<?php echo base_url('admin/product/save');?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Product Title</strong></label>
							<input type="text" name="title"class="form-control" placeholder="title" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Short Description</strong></label>
							<input type="text" name="shortDescription"class="form-control" placeholder="short description" >
						  </div>
						 
						  
						

					
						
						
						<div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  
							 <option value='1' selected >Published</option>
							 <option value='0'>Unpublished</option>
							</select>
						  </div>
						  
						  
						
						
						<div id="summernote"></div>
						
						
						
						<label for="exampleFormControlSelect2"><strong>Product Description</strong></label>
						
						  <textarea id="simpleMde" name="productDescription"style="min-height: 500px;">     </textarea>
						
						
						
						
						
						
					
						  
					
					
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center border-info">
				  <div class="card-header" style="background:#dfe8fb">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Save" />
					 
						<a href="<?php echo base_url('admin/productList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        