		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Requested Product</h4>
                  <div class="text-right"> 
				  
				  
				   
				  </div>
				  
                  <div class="row">
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                              <th>SL No#</th>
                              <th>Name</th>
                              <th>phone</th>
                              <th>Email</th>
                              <th>Address</th>
                              <th>Product Name</th>
                              <th>Request date</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$sl=0;
						if($requestedProducts)
						{
						foreach ($requestedProducts as $product){
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><?php echo$product->name;?></td>
                              <td><?php echo$product->phone;?></td>
                              <td><?php echo$product->email;?></td>
                             
                              <td><?php echo$product->address;?></td>
                              <td><?php echo$product->productName;?></td>
                              <td><?php echo$product->requestDate;?></td>
                              
                              <td class="text-right">
                                
								<a href="<?php echo base_url('admin/product/requestedProduct/delete/').$product->id;?>" onclick="return confirm('Are you sure to delete this item?')"  > <i class="mdi mdi-close text-danger"></i>Remove </a>
								
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No requested product found.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
				  
				  <br />
				  <br />
				  <br />
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        