		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Re-stock Requested Product</h4>
                  
				  
                  <div class="row">
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                              <th>SL No#</th>
                              <th>Title</th>
                              <th>Picture</th>
                              <th>Status</th>
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$sl=0;
						if($restockRequestedProductInfo)
						{
						foreach ($restockRequestedProductInfo as $product){
						    
						     $get_default_photo = $this->dashboardProduct_model->get_default_photo($product['product_id']);
									 $proImage = $get_default_photo['image_url'];
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><?php echo$product['title']?></td>
                              <td>
							 
							  <img src="<?php echo base_url().$proImage?>" alt="" /></td>
                              <td>
							  <?php $status=$product['product_status'];
							  if($status==1){
							  ?>
                                <label class="badge badge-success">Published</label>
							  <?php } 
							  else 
							  {?>
						  <label class="badge badge-danger">Unpublished</label>
							  <?php }?>
                              </td>
                              <td class="text-right">
                                
								<a href="<?php echo base_url('admin/product/edit/').$product['product_id'];?>" class="btn btn-light">  <i class="mdi mdi-pencil text-primary"></i>Stock In Now</a> &nbsp;&nbsp;
							
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No product currently requested for re-stock!.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
				  
				  <br />
				  <br />
				  <br />
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        