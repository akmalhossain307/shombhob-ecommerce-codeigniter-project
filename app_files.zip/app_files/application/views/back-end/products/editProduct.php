		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					<div class="card">
					  <div class="card-header">
						<strong><i class=" link-icon fa fa-pencil"></i> Update Product</strong>
					  </div>
					  <div class="card-body">
					  <?php foreach($product as $pro){?>
						<form action="<?php echo base_url('admin/product/saveUpdate/').$pro->product_id;?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Product Title</strong></label>
							<input type="text" name="title"class="form-control" value="<?php echo $pro->title;?>" required >
						  </div>
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Short Description</strong></label>
							<input type="text" name="shortDescription"class="form-control" value="<?php echo $pro->shortDescription;?>" >
						  </div>
						  <div class="row"> 
						  <div class="col-md-6">
							<div class="form-group">
							<label for="exampleFormControlSelect2"> <strong> Select  Category</strong></label>
							<select class="form-control" name="mainCategory"id="mainCategory" required >
							  <option>Select Category</option>
							  <?php 
							  $thisCat=$pro->product_parentcat_id;
							  foreach($categories as $category){
								  
								  $cat=$category->category_id;
								  if($thisCat==$cat)
								  {
								?>
							  <option value="<?php echo$thisCat;?>" selected ><?php echo$category->category_name;?></option>
							  <?php }
							  else 
							  {?>
						  <option value="<?php echo$cat?>"><?php echo$category->category_name;?></option>
							  <?php 
							  }
							  }
							  ?>
							  
							</select>
						  </div>
						  </div>
						  <div class="col-md-6">
						  <div class="form-group">
						  
							<label for="exampleFormControlSelect2"><strong>Select Sub-category</strong></label>
							<select class="form-control" name="subCategory"id="subCategory" required >
							    <?php 
							  $thisSubCat=$pro->subcat_id;
							  foreach($subCategories as $sub){
								  
								  $subcat=$sub->subcat_id;
								  if($thisSubCat==$subcat)
								  {
								?>
							
							  <option value="<?php echo$thisSubCat;?>" selected ><?php echo$sub->subCategoryName;?></option>
							  <?php 
								  }
								  }
							  ?>
							  
							</select>
						  </div>
						  </div>
						  </div>
						  
						<div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Select Brand(If have)</strong></label>
							<select class="form-control" name="brand"id="exampleFormControlSelect2">
							  <?php foreach($brands as $brand){
								  $thisBrand=$pro->brand;
								  $Brand=$brand->brand_name;
								  if($thisBrand==$Brand)
								  {
								  ?>
							  <option value="<?php echo$brand->brand_id;?>" selected ><?php echo$brand->brand_name;?></option>
							  <?php 
							  }
							  else 
							  {
								  ?>
								  <option value="<?php echo$brand->brand_id;?>"  ><?php echo$brand->brand_name;?></option>
								  <?php 
							  }
							  }
							  ?>
							</select>
						  </div>
						  
						  
						  
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Product Attribute</strong></label>
							<select class="form-control" name="attribute" id="exampleFormControlSelect2">
							<?php $att=$pro->attribute;
							
							if($att=="")
							{
								echo"<option value='' selected >No product attribute found.</option>";
							}
							else 
							{
							  echo"<option value='$att' selected >$att</option>";
							}
							  ?>
							  <option value="prescription_needed">Need Prescription</option>
							  <option value="featured">Featured</option>
							  <option value="normal">Normal</option>
							  <option value="new">New</option>
							  <option value="hot">Hot</option>
							</select>
						  </div>
						  
						  
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Product Type(For Medicine Only)</strong></label>
							<select class="form-control" name="type" id="exampleFormControlSelect2">
							<?php $type=$pro->type;
							
							if($type=="")
							{
								echo"<option value='' selected >No product type found.</option>";
							}
							else 
							{
							  echo"<option value='$type' selected >$type</option>";
							}
							  ?>
							
							  <option value="otc">OTC</option>
							  <option value="prescribed">Need Prescription</option>
							  <option value="essential">Essential</option>
							  <option value="featured">Featured</option>
							</select>
						  </div>
						  
						  
						  
						  <div class="form-group">
						  <div class="text-right"> 
<?php 
$get_default_photo = $this->dashboardProduct_model->get_default_photo($pro->product_id);
$proImage = $get_default_photo['image_url'];
?>
						
								<img id="img" src="<?php echo base_url().$proImage;?>" alt="product image" />
								
							</div>
							<label for="exampleFormControlSelect2"><strong>Product Picture</strong></label>
							<input type='file' name="productImage"class="form-control"onchange="readURL(this);" />
							
							
							
						  </div> 

						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Original Price</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">TK</span>
                          </div>
                          <input type="text" name="price"class="form-control" aria-label="Amount (to the nearest dollar)" value="<?php echo$pro->price;?>" required >
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
						</div>
						
						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Discount Price</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">TK</span>
                          </div>
                          <input type="text" name="discountPrice"class="form-control" aria-label="Amount (to the nearest dollar)" value="<?php echo$pro->discountPrice;?>">
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
						</div>
						
						<div class="row"> 
						  
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Stock Qty</strong></label>
							<input type="number" name="stockQty"class="form-control" value="<?php echo$pro->product_quantity;?>"required >
						  </div>
						  </div>
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Min Order Qty</strong></label>
							<input type="number" name="minOrderQty"class="form-control" value="<?php echo$pro->product_minorder_qty;?>" required >
						  </div>
						  </div>
						  <div class="col-md-4">
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Measuring Type</strong></label>
							<input type="text" name="measuringType"class="form-control"  value="<?php echo$pro->measuringType;?>"required >
						  </div>
						  </div>
						  
						</div>
						<div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="status" required>
							  <?php $sts=$pro->product_status;
							  if($sts==1)
							  {
								echo"<option value='1' selected >Published</option>";
								echo"<option value='0'>Unpublished</option>";  
							  }
							  else 
							  {
								echo"<option value='1'>Published</option>";
								echo"<option value='0' selected>Unpublished</option>"; 
							  }
								  ?>
							 
							</select>
						  </div>
						
						
						<label for="exampleFormControlSelect2"><strong>Product Description</strong></label>
						
						  <textarea id="simpleMde" name="productDescription"style="display: none;">   <?php echo$pro->productDescription;?>  </textarea>
						  
						  
						  
						  
						  <label for="exampleFormControlSelect2"><strong>Additional Info</strong></label>
						
						<textarea name="additionalInfo" cols="30" rows="10" class="form-control"><?php echo$pro->additionalInfo;?></textarea>
						  
						  
						  
						  	<!--<label for="exampleFormControlSelect2"><strong>Additional Info</strong></label>
						
						  <textarea id="simpleMde" name="additionalInfo"style="display: none;">   <?php //echo$pro->additionalInfo;?>  </textarea>
						  -->
						  
						  
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Meta Keywords</strong></label>
							<textarea name="metaKeywords" id="" class="form-control" cols="30" rows="10"><?php echo$pro->product_meta_keywords;?></textarea>
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Meta Description</strong></label>
							<textarea name="metaDescription" class="form-control"id="" cols="30" rows="10"><?php echo$pro->product_meta_descriptions;?></textarea>
						  </div>
						  
					
					
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Update" />
					 
						<a href="<?php echo base_url('admin/productList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
					  <?php } ?>
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        