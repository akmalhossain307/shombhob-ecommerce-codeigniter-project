		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Customer viewed products</h4>
                  
				  
                  <div class="row">
                   
                  </div>
				  
				 
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>SL No.</th>
                <th>Product Title</th>
                <th>Picture</th>
                <th>View Date</th>
            </tr>
        </thead>
        <tbody>
		
		
		
		<?php 
						
						if($viewedProductsInfo)
						{
						    $c=0;
						foreach ($viewedProductsInfo as $product){
							$c++;
							//$this->load->model('Product_model');
									 $get_default_photo = $this->dashboardProduct_model->get_default_photo($product['product_id']);
									 $proImage = $get_default_photo['image_url'];
							
							?>
                          <tr>
                              
                              <td><?php echo$c;?></td>
                              <td><?php echo$product['title'];?></td>
                             
                              <td>
							    <img src="<?php echo base_url().$proImage?>" alt="<?php echo$product['title'];?>" />
							  </td>
							  <td><?php echo$product['view_date'];?></td>
                             
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No viewed product found.";
						}
						  ?>
		
		
		
        </tbody>
        
    </table>
				  
				  
				  
				  
			 
				  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        