		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Coupons</h4>
                  <div class="text-right"> 
				  
				  
				   <a href="<?php echo base_url('admin/product/createCoupon')?>" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Create New</span></a>
				  </div>
				  
                  <div class="row">
                   
<table class="table table-bordered table-responsive table-hover">
    <thead>
      <tr style="background:#CCE8FF">
        <th>Title</th>
        <th>Type</th>
        <th>Discount Type</th>
        <th>Percent(%)</th>
        <th>Amount(TK)</th>
        <th>Code</th>
        <th>Create Date</th>
        <th>Expire Date</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
	
	<?php if($coupons)
	foreach($coupons as $coupon)
	{
	?>
      <tr>
        <td><?php echo $coupon->coupon_title;?></td>
        <td><?php if($coupon->coupon_type==1)
		{echo"Bulk";}else{echo"Individual";};?></td>
	
	<td><?php if($coupon->coupon_discount_type==1)
		{echo"Amount";}else{echo"Percentage";};?></td>
		<td><?php echo $coupon->coupon_discount_price;?></td>
		<td><?php echo $coupon->coupon_discount_amount;?></td>
		<td><?php echo $coupon->coupon_code;?></td>
		<td><?php echo $coupon->coupon_create_date;?></td>
		<td><?php echo $coupon->coupon_expire_date;?></td>
		<td><?php 
		if($coupon->coupon_status==1)
		{
			?>
		<a href="<?php echo base_url('dashboardProduct/deactivateCoupon/').$coupon->coupon_id;?>" class="badge badge-success" title="Inactive Now!">Inactive</a>
		
		<?php 
			
		}
		else
		{
		?>
		<a href="<?php echo base_url('dashboardProduct/activateCoupon/').$coupon->coupon_id;?>" class="badge badge-danger" title="Activate Now!">Inactive</a>
		<?php 
		};?>
			</td>
			
			<td> 
				
				
				 <a href="<?php echo base_url('admin/product/deleteCoupon/').$coupon->coupon_id;?>" onclick="return confirm('Are you sure to delete this coupon?')" class="btn btn-light"> <i class="mdi mdi-close text-danger"></i>Remove </a>
				
			</td>
      
      </tr>
  <?php 
}
else 
{
	echo"No Coupon created yet...";
}
  ?>
	  
	
	 
      
    </tbody>
  </table>
				   
				   
				   
                  </div>
				  
				  <br />
				  <br />
				  <br />
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        