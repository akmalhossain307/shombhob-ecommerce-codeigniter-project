		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Product</h4>
                  <div class="text-right"> 
				  
				   <a href="<?php echo base_url('admin/product/create')?>" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Add New</span></a>
				  </div>
				  
                  <div class="row">
                   
                  </div>
				  
				  <br />
				  <br />
				  <br />
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>SL No.</th>
                <th>Title</th>
                <th>Picture</th>
                <th>Price</th>
                <th>Status</th>
                <th>Action</th>
               
            </tr>
        </thead>
        <tbody>
		
		
		
		<?php 
						
						if($products)
						{
						foreach ($products as $product){
							
							//$this->load->model('Product_model');
									 $get_default_photo = $this->dashboardProduct_model->get_default_photo($product['product_id']);
									 $proImage = $get_default_photo['image_url'];
							
							?>
                          <tr>
                              
                              <td><?php echo$product['product_id'];?></td>
                              <td><?php echo$product['title'];?></td>
                              <td>
							 
							  <img src="<?php echo base_url().$proImage?>" alt="<?php echo$product['title'];?>" /></td>
							   <td><?php if($product['discountPrice'])
							   {
								   echo"<del style='color:red'>TK ".$product['price']."</del> TK ".$product['discountPrice'];
							   }
							   else 
							   {
								   echo"TK ".$product['price'];
							   };?></td>
							   
							   
							   <td>
							  <?php $status=$product['product_status'];
							  if($status==1){
							  ?>
							  <a href="<?php echo base_url('DashboardProduct/unpublishProduct/').$product['product_id'];?>" class="badge badge-success" title="Unpublish Now!">Published</a>
                                
							  <?php } 
							  else 
							  {?>
						  <a href="<?php echo base_url('DashboardProduct/publishProduct/').$product['product_id'];?>" class="badge badge-danger" title="Publish Now!">Unpublished</a>
							  <?php }?>
                              </td>
							   
							   
                              <td class="text-right">
                                
							
								<a href="<?php echo base_url('admin/product/edit/').$product['product_id'];?>" class="btn btn-light" >  <i class="mdi mdi-pencil text-primary"></i>Edit</a>&nbsp;&nbsp; 
								<a href="<?php echo base_url('admin/product/delete/').$product['product_id'];?>" onclick="return confirm('Are you sure to delete this product?')"  > <i class="mdi mdi-close text-danger"></i>Remove </a>
								
                              </td>
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No product found.";
						}
						  ?>
		
		
		
        </tbody>
        
    </table>
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        