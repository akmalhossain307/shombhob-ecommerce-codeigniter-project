		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			
			
			
			
			<div class="row"> 
				
				<div class="col-md-9">
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="fa fa-plus-square text-success"></i> Create New Coupon</strong>
					  </div>
					  <div class="card-body text-success">
					  
					  
					  <?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
					  
					  
					  
						<form action="<?php echo base_url('admin/product/saveCoupon');?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Title</strong></label>
							<input type="text" name="coupon_title"class="form-control" placeholder="title" required >
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Coupon Type</strong></label>
							<select class="form-control" name="coupon_type" id="exampleFormControlSelect2">
							  <option value="">Select One</option>
							  <option value="1">Bulk</option>
							  <option value="0">Individual</option>
							
							</select>
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Coupon Code</strong></label>
							<input type="text" name="coupon_code"class="form-control" placeholder="code" required >
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Coupon Discount Type</strong></label>
							<select class="form-control" name="coupon_discount_type" id="exampleFormControlSelect2">
							  <option value="">Select One</option>
							  <option value="1">Amount</option>
							  <option value="0">Percentage</option>
							
							</select>
						  </div>
						  
						  
						  

						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Discount Percentage</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">%</span>
                          </div>
                          <input type="text" name="coupon_discount_price"class="form-control" aria-label="Amount (to the nearest dollar)" placeholder="discount(%)" >
                          
                        </div>
						</div>
						
						<div class="form-group">
						<label for="exampleFormControlSelect2"><strong>Discount Amount</strong></label>
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">TK</span>
                          </div>
                          <input type="text" name="coupon_discount_amount"class="form-control" aria-label="Amount (to the nearest dollar)" placeholder=" Amount">
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
						</div>
						
						<div class="form-group">
							<label for="exampleFormControlInput1"><strong>Expire Date (yy-mm-dd)</strong></label>
							<input type="text" name="coupon_expire_date"class="form-control" placeholder="eg. 2019-12-04" required >
						 </div>
						
						
						<div class="form-group">
							<label for="exampleFormControlSelect1"><strong>Status</strong></label>
							<select class="form-control" name="coupon_status" required>
							  
							 <option value='1' selected >Published</option>
							 <option value='0'>Unpublished</option>
							</select>
						  </div>
						
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Save" />
					 
						<a href="<?php echo base_url('admin/product/couponList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        