		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					<div class="card">
					  <div class="card-header">
						<strong> <i class=" link-icon fa fa-eye"></i> View Product Details</strong>
					  </div>
					  <div class="card-body">
					  
						<table class="table table-bordered table-hover">
						  
						  
						  <tbody>
						  
						  <?php foreach($product as $pro){?>
							<tr>
							  <th colspan="2">Title</th>
							  <td colspan="4"><?php echo$pro->title;?></td>
							</tr>
							<tr>
							  <th colspan="2">Short Description</th>
							  <td colspan="4"><?php echo$pro->shortDescription;?></td>
							</tr>
							<tr>
							  <th colspan="2">Main category</th>
							  <td colspan="4"><?php echo$pro->mainCategory;?></td>
							</tr>
							<tr>
							  <th colspan="2">Sub category</th>
							  <td colspan="4"><?php echo$pro->subcategory;?></td>
							</tr>
							<tr>
							  <th colspan="2">Brand</th>
							  <td colspan="4"><?php echo$pro->brand;?></td>
							</tr>
							<tr>
							  <th colspan="2">Attribute</th>
							  <td colspan="4"><?php echo$pro->attribute;?></td>
							</tr>
							<tr>
							  <th colspan="2">Picture</th>
							  <td colspan="4"><?php $imgURL=$pro->productImage;?>
							  <img src="<?php echo base_url().$imgURL?>" alt="" width="100" height="80"/></td>
							</tr>
							<tr>
							  <th colspan="2">Price</th>
							  <td colspan="4"><?php echo$pro->price;?></td>
							</tr>
							<tr>
							  <th colspan="2">Discount Price</th>
							  <td colspan="4"><?php echo$pro->discountPrice;?></td>
							</tr>
							<tr>
							  <th colspan="2">Stock Qty</th>
							  <td colspan="4"><?php echo$pro->stockQty;?></td>
							</tr>
							<tr>
							  <th colspan="2">Min Order Qty</th>
							  <td colspan="4"><?php echo$pro->minOrderQty;?></td>
							</tr>
							<tr>
							  <th colspan="2">Measuring Type</th>
							  <td colspan="4"><?php echo$pro->measuringType;?></td>
							</tr>
							<tr>
							  <th colspan="2">Status</th>
							  <td colspan="4"><?php $status=$pro->status;
							  if($status==1){
							  ?>
                                <label class="badge badge-success">Published</label>
							  <?php } 
							  else 
							  {?>
						  <label class="badge badge-danger">Unpublished</label>
							  <?php }?></td>
							</tr>
							<tr>
							  <th colspan="2">Description</th>
							  <td colspan="4"><?php echo$pro->productDescription;?></td>
							</tr>
							<tr>
							  <th colspan="2">Additional Info</th>
							  <td colspan="4"><?php echo$pro->additionalInfo;?></td>
							</tr>
						  <?php } ?>
							
						  </tbody>
						</table>
						
					  </div>
					</div>
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						
						<a href="<?php echo base_url('admin/productList');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        