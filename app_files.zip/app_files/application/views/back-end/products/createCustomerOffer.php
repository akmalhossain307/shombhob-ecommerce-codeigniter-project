<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Summernote with Bootstrap 4</title>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
  </head>
  <body>
    
    
    <nav class="navbar navbar-expand-sm bg-light">
  <ul class="navbar-nav">
    <li class="nav-item">
        
        
         <h4 ><a style="color:magenta;"href="<?php echo base_url('dashboard')?>">Administrator Panel</a></h4>
     
    </li>
   
  </ul>
</nav>
<br>
    
    
    
    <div class="card">
        
          <div class="card-header">Send offer to Customer</div>
          <div class="card-body"> 
          
          <div class="row">
           <div class="col-md-2"></div>
        <div class="col-md-8">
          <form action="<?php echo base_url('admin/send-offer-to-customer');?>" method="POST">
              <div class="form-group">
                <label for="email"><strong>Offer Title</strong></label>
                <input type="text" name="offer_title"class="form-control" placeholder="Enter offer title" required>
              </div>
              
              
              
              <div class="form-group">
                <label for="pwd"><strong>Offer Body</strong></label>
                 
                 
                 <textarea id="summernote" class="form-control" name="offer_body" required></textarea>
                 
              </div>
             
              
              
              
              <button type="submit" class="btn btn-primary btn-sm">Send</button>  <button type="reset" class="btn btn-danger btn-sm">Reset</button>
            </form>
         </div>  
         
          <div class="col-md-2"></div>
          </div>
          
          </div>
          
          <!--
          <div class="card-footer">Footer</div>
          -->
</div>
    
    <script src="<?php echo base_url('assets/back-end/vendors/notifyjs/');?>notify.min.js"></script>
    <script>
      $('#summernote').summernote({
        placeholder: 'type offer text here...',
        tabsize: 2,
        height: 100
      });
    </script>
    
     <script type="text/javascript"> 
$.notify("<?php echo $this->session->flashdata('success'); ?>", "success");
$.notify("<?php echo $this->session->flashdata('error'); ?>", "error");

</script>
    
  </body>
</html>