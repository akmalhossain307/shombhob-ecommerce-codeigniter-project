		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
			
				<div class="col-md-9">
				
					<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
					<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class=" link-icon fa fa-pencil"></i> Update Slider</strong>
					  </div>
					  <div class="card-body text-success">
					  <?php foreach($slider as $s){?>
						<form action="<?php echo base_url('admin/slider/update/').$s->slider_id;?>" method="POST" enctype="multipart/form-data">
						  
						 <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Slider Title</strong></label>
							<input type="text" name="sliderTitle"class="form-control" placeholder="slider title" value="<?php echo$s->sliderTitle;?>" >
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Slider URL</strong></label>
							<input type="text" name="sliderURL"class="form-control" value="<?php echo$s->sliderURL;?>" >
						  </div>
						  
						<div class="form-group">
						  <div class="text-right"> 
						  <?php $imgURL=$s->sliderImage;?>
								<img id="img" src="<?php echo base_url().$imgURL;?>" alt="slider image" />
							</div>
							<label for="exampleFormControlSelect2"><strong>Slider Image</strong></label>
							<input type='file' name="sliderImage"class="form-control"onchange="readURL(this);" />
							
						  </div>
						  
						    <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Slider Status</strong></label>
							<select class="form-control" name="status" id="exampleFormControlSelect2">
							
							<?php $sts=$s->status;
							if($sts==1)
							{
								echo"<option value='1' selected >Published</option>";
								echo"<option value='0' >Unpublished</option>";
							}
							else 
							{
								echo"<option value='1' >Published</option>";
								echo"<option value='0' selected>Unpublished</option>";	
							}?>
							 
							</select>
						  </div>
						
					  </div>
					  <br />
					<br />
					<br />
					<br />
					<br />
					</div>
					
					
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center border-success">
				  <div class="card-header" style="background:#dfe8fb">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Update" />
					 
						<a href="<?php echo base_url('admin/manageSliders');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
					  <?php }?>
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        