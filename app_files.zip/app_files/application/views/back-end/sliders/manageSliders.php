		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-12">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
					<div class="card card-center border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class="link-icon mdi mdi-flag-outline"></i> Manage Sliders</strong>
					  </div>
							 <div class="text-left" style="margin-left:30px;margin-top:15px;margin-bottom:-15px"> 
							   <a href="<?php echo base_url('admin/slider/create')?>" class="btn btn-success btn-sm"><i class="link-icon fa fa-plus-square"></i>Add New</span></a>
							  </div>
					  
					  <div class="card-body">
					  
						<table class="table table-bordered table-hover">
						  
						  
						  <tbody>
						  
						  
							<tr>
							  <th>Sl No#</th>
							  <th colspan="2">Slider Image</th>
							  <th colspan="2">Slider Text</th>
							  <th>Status</th>
							  <th>Action</th>
							</tr>
							<?php if($sliders){
								$sl=0;
								foreach($sliders as $slider){
									$sl++;
									?>
							<tr>
							  <td><?php echo$sl;?></td>
							  <td colspan="2"><?php $imgURL=$slider->sliderImage;
							  ?> <img src="<?php echo base_url().$imgURL;?>" alt="banner image" id="sliderImage"/></td>
							  <td colspan="2"><?php echo$slider->sliderTitle;?></td>
							  <td><?php $sts=$slider->status;
							  if($sts==1)
							  {
								 echo"<label class='badge badge-success'>Published</label>" ;
							  }
							  else 
							  {
								  echo"<label class='badge badge-danger'>Unpublished</label>";
							  }?>
							  </td>
							  <td>
								<a href="<?php echo base_url('admin/slider/edit/').$slider->slider_id;?>" class="btn btn-light" >  <i class="mdi mdi-pencil text-primary"></i>Edit</a>&nbsp;&nbsp; 
								<a href="<?php echo base_url('admin/slider/delete/').$slider->slider_id;?>" onclick="return confirm('Are you sure to delete this Slider?')"> <i class="mdi mdi-close text-danger"></i> Remove </a>
							  
							  </td>
							</tr>
							<?php } 
							
							}
							else 
							{
								echo"No slider data found.";
							}?>
							
							
						  </tbody>
						</table>
						
					  </div>
					</div>
				
				</div>
				
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        