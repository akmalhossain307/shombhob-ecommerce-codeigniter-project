<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from www.urbanui.com/libertyui/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Oct 2019 07:34:33 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?php echo$title;?></title>
  
 
 
 <!--Style for datatable-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" />

 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" />
 
 

  
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/iconfonts/simple-line-icon/css/simple-line-icons.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/summernote/dist/summernote-bs4.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>vendors/iconfonts/font-awesome/css/font-awesome.min.css" />
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url('assets/back-end/')?>css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/back-end/')?>images/favicon.png" />
  
  <script src="https://code.jquery.com/jquery-3.2.0.min.js" integrity="sha256-JAW99MJVpJBGcbzEuXk4Az05s/XyDdBomFqNlM3ic+I=" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url('backend/js/jquery-3.2.0.min.js'); ?>"><\/script>')</script>



    
   
  
  <script type="text/javascript">
     var baseUrl = "<?php echo base_url(); ?>";
  </script>
  
  <style type="text/css"> 
  
  
  #prescriptionImg{
	  
	width: 300px;
    height: 150px;
	border-radius:0px;
  }

  #bannerImage{
	  
	width: 300px;
    height: 150px;
	border-radius:0px;
  }
  #sliderImage{
	  
	width: 250px;
    height: 150px;
	border-radius:0px;
  }
  
#subCategory li a{
margin-right:150px!important;
background:none;
}

#subCategory li a:hover{
color:red!important;

}
  
  </style>
  
  
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_horizontal-navbar.html -->
    <nav class="navbar horizontal-layout col-lg-12 col-12 p-0">
      <div class="container d-flex flex-row">
           <h4 ><a style="color:magenta;"href="<?php echo base_url('dashboard')?>">Administrator Panel</a></h4>
          
        <div class="text-right"> 
			 
		
		
		
		
		
		<ul class="navbar-nav navbar-nav-right mr-0">
		
		<li> </li>
           
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <img class="img-xs rounded-circle" src="<?php echo base_url('assets/back-end/')?>images/admin_user.jpg" alt="Profile image">
              </a>
			   <a href="#" class="btn btn-secondary"><i class="fa fa-database"></i> Backup Database</a><a href="<?php echo base_url();?>" class="btn btn-secondary" target="_blank"> <i class="fa fa-eye"></i> Visit Website</a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
               <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                <a href="<?php echo base_url('admin/user-list');?>"class="dropdown-item mt-2">
                  Manage Accounts
                </a>
                <?php }?>
                <a href="<?php echo base_url('admin/change-website-user-password');?>" class="dropdown-item">
                  Change Password
                </a>
                <a class="dropdown-item" href="<?php echo base_url('logout');?>">
                  Logout
                </a>
              </div>
            </li>
          </ul>
		
		
		
		
		
		
		
		
		
		</div>
       
      </div>
      <div class="nav-bottom">
        <div class="container">
          <ul class="nav page-navigation">
            <li class="nav-item">
              <a href="<?php echo base_url('dashboard')?>" class="nav-link"><i class="link-icon mdi mdi-apple-safari"></i><span class="menu-title">DASHBOARD</span></a>
            </li>
            <li class="nav-item mega-menu">
              <a href="#" class="nav-link"><i class=" link-icon icon-layers"></i><span class="menu-title">CATEGORY</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <div class="col-group-wrapper row">
                    
                     <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                  <div class="col-md-1"></div>
                  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE CATEGORY</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/category/add')?>">Add New category</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/categoryList')?>">Category List</a></li>
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE SUB-CATEGORY</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/subCategory/create')?>">Add New sub-category</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/subCategoryList')?>">Sub-Category List</a></li>
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE BRANDS</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/brandList')?>">Add New Brand</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/brandList')?>">Brand List</a></li>
                        </ul>
                    </div>
                  </div>
				   <div class="col-md-2"></div>
                 <?php }?>
                </div>
              </div>
            </li>
			
			<li class="nav-item mega-menu">
              <a href="#" class="nav-link"><i class=" link-icon icon-handbag"></i><span class="menu-title">PRODUCT</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <div class="col-group-wrapper row">
                  <div class="col-md-1"></div>
                  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE PRODUCTS</p>
                      </div>
                       <?php
                       	$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/create')?>">Add New Product</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/productList')?>">Product List</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/requestedProduct')?>">Requested Product</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/stockOutProduct')?>">Stock out Product</a></li>
                        </ul>
                        <?php }?>
                        
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE OFFERS</p>
                      </div>
                      
                        <ul class="submenu-item">
                 <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/createOffer')?>">Create New Offer</a></li>
						  
						  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/offerList')?>">Offer List</a></li>
						  
						  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product/couponList')?>">Coupon List</a></li>
						  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/send-offer')?>"> Send offer to customer</a></li>
						  <?php }?>
						  
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE ORDER</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/productOrders')?>">Order List</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/productwise-sales-report');?>">Product-wise Sale Report</a></li>
                          
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-2">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">OTHERS</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/prescription-list')?>">Prescription List</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/search-keyword-list')?>" target="_blank">Product Search Keywords</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product-view-list')?>" target="_blank">Product View List</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/product-restock-list')?>" target="_blank">Product Re-stock Request</a></li>
                        </ul>
                    </div>
                  </div>
				   
                 
                </div>
              </div>
            </li>

			<li class="nav-item mega-menu">
              <a href="#" class="nav-link"><i class=" link-icon icon-people"></i><span class="menu-title">PEOPLE</span><i class="menu-arrow"></i></a>
              <div class="submenu">
                <div class="col-group-wrapper row">
                  <div class="col-md-1"></div>
                  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE CUSTOMER</p>
                      </div>
                      
                        <ul class="submenu-item">
                          
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/customerList')?>">Customer List</a></li>
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/customerQueryList')?>">Customer Query List</a></li>
						
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                    <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE SUBSCRIBER</p>
                      </div>
                      
                        <ul class="submenu-item">
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/subscriberList')?>">Subscriber List</a></li>
                          
                        </ul>
                    </div>
                  </div>
				  <div class="col-group col-md-3">
                   <div class="row">
                      <div class="col-12">
                        <p class="category-heading">MANAGE WEBSITE USER</p>
                      </div>
                      
                        <ul class="submenu-item">
                             <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                            
                          <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/user-list');?>">Manage Site User</a></li>
						  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/create-new-user');?>">Create New User</a></li>
					<?php }?>
                        </ul>
                    </div>
                  </div>
				   <div class="col-md-2"></div>
                 
                </div>
              </div>
            </li> 
			
			<li class="nav-item">
              <a href="#" class="nav-link"><i class="link-icon mdi mdi-atom"></i><span class="menu-title">SETTINGS</span><i class="menu-arrow"></i></a>
               
			  <div class="submenu">
                <ul class="submenu-item">
                      <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/generalSettings')?>">General Settings</a></li>
				  
				  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/socialSettings')?>">Social settings</a></li>
              <?php }?>
                  
                </ul>
              </div>
            
            
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link"><i class="link-icon mdi mdi-flag-outline"></i><span class="menu-title">PAGES</span><i class="menu-arrow"></i></a>
              
			  <div class="submenu">
                <ul class="submenu-item">
                     <?php
				$role=$this->session->userdata('user_role');
				if($role=="admin"){?> 
                  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/managePages')?>">Manage Pages</a></li>
                  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/manageSliders')?>">Manage Sliders</a></li>
                  <li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/manageBanners')?>">Manage Banners</a></li>
                  <?php }?>
                </ul>
              </div>
			  
			  
            </li>
            </ul>
        </div>
      </div>
    </nav>