<!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
		
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © <?php echo date('Y');?> <a href="https://www.shombhob.com/" target="_blank">Shombhob.com Ltd</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Design and developed by- <strong style="color:magenta">Shombhob Team.</strong> <i class="mdi mdi-heart text-danger"></i></span>
          </div>
		  
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- plugins:js -->
  <script src="<?php echo base_url('assets/back-end/')?>vendors/js/vendor.bundle.base.js"></script>
  <script src="<?php echo base_url('assets/back-end/')?>vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  
  
  <!-- Plugin js for this page-->
   <script src="<?php echo base_url('assets/back-end/')?>vendors/tinymce/tinymce.min.js"></script>
  <script src="<?php echo base_url('assets/back-end/')?>vendors/tinymce/themes/modern/theme.js"></script>
  <script src="<?php echo base_url('assets/back-end/')?>vendors/summernote/dist/summernote-bs4.min.js"></script>
  <!-- End plugin js for this page-->
  
  
 
  
  
  <!--JS for datatable-->
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"> </script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"> </script>
  
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"> </script>
  
  <script type="text/javascript"> 
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  <!-- inject:js -->
  <script src="<?php echo base_url('assets/back-end/')?>js/template.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url('assets/back-end/')?>js/editorDemo.js"></script>
  <script src="<?php echo base_url('assets/back-end/')?>js/dashboard.js"></script>
  <script src="<?php echo base_url('assets/back-end/')?>js/data-table.js"></script>
 
  
  <script src="<?php echo base_url('assets/back-end/vendors/notifyjs/');?>notify.min.js"></script>
   <!-- End custom js for this page-->
   
  <script type="text/javascript"> 
$.notify("<?php echo $this->session->flashdata('success'); ?>", "success");
$.notify("<?php echo $this->session->flashdata('error'); ?>", "error");

</script>
  
  
  
  
  
  
   <script type='text/javascript'>
  $(document).ready(function(){
 
 function updateDelivery(val, order_val)
{
	//$('#couponLoder').show();
	$.ajax({
		type : "POST",
		url :"<?php base_url()?>dashboardOrder/updateDeliveryStatus",
		data : {status:val, order:order_val},
		dataType : "json",
		success : function (data) {
			if(data.status == "ok")
			{
				//$('#couponLoder').hide();
				window.location.reload();
				return false;
			}else
			{
				//have end check.
			}
			return false;
		}
	});
}
 
   
 });
 
 
 
 
 </script>
  
  
  
  
  
  
  
  
  
  
  
  
  <!--JS for image preview before upload-->
  <script type="text/javascript"> 
	  function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#img')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
  </script>
  
  <!--JS for dependent dropdown selection-->
  <script>

 $('#mainCategory').change(function(){
  var mainCategory = $('#mainCategory').val();
 
  //var mainCategory = $(this).val();
   //alert(mainCategory);
 
  if(mainCategory != '')
  {
   $.ajax({
    url:"<?php echo base_url(); ?>DashboardProduct/fetch_subCategory",
    method:"POST",
    data:{mainCategory:mainCategory},
    success:function(data)
    {
     $('#subCategory').html(data);
     //$('#city').html('<option value="">Select City</option>');
    }
   });
  }
  else
  {
   $('#subCategory').html(data);
   //$('#city').html('<option value="">Select City</option>');
  }
 });
 


$('[data-toggle="tooltip"]').tooltip();
   
</script>
  
</body>



</html>
