
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Product-wise sales report</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h3 style="text-decoration:underline">Product-Wise Sales Report</h3>
  
  	
  
            
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>SL No.</th>
        <th>Product Name</th>
        <th>Sold Qty</th>
      </tr>
    </thead>
    <tbody>
	
	<?php 
  	
		$this->load->model('dashboardOrder_model');	
		
		if($orders)
		{
		    $sl=1;
		foreach ($orders as $cu_order){
		    $order_id=$cu_order->order_id;
		    $order_details=$this->dashboardOrder_model->getOrderDetailsByOrderId($order_id);
		        foreach($order_details as $o_details)
		        {
		            
		             $product_id=$o_details->details_item_id;
		             $pro_details=$this->dashboardOrder_model->getProductDetailsByProductId($product_id);
		             foreach($pro_details as $p_details)
		            {
		                
		                
		?>
	      <tr>
        <td><?php echo$sl;?></td>
        <td> <?php echo$p_details->product_name;?></td>
       <td> <?php echo$o_details->sold_qty;?></td>
		
        
      </tr>
	  
	     
	  
	<?php 
		            }
		        }
		}
		}
	?>  
	     
	  
	 
	  
	        
	  
    </tbody>
  </table>
</div>

<script>

  window.print();

</script>
</body>
</html>