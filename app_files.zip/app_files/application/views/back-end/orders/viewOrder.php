		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
				
				
				<?php foreach($orderInfo as $order){
					$orderID=$order->order_id;
					//$customerID=$order->order_customerid;
					$cusAddressID=$order->order_addressid;
				
					$inv=$this->dashboardOrder_model->fetchInvoiceByOrderId($orderID);
					//$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($customerID);
					$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($cusAddressID);
					$orderDetails=$this->dashboardOrder_model->fetchOrderDetailsByOrderId($orderID);
					?>
				
					<div class="card">
					  <div class="card-header" style="background:#CD9BFF;color:white">
						<strong> <i class=" link-icon fa fa-eye"></i> Order Details</strong>
					  </div>
					  <div class="card-body ">
<div class="row"> 
<table class="table table-hover table-sm">
    <thead>
      <tr>
        <th>Invoice No</th>
        <th>Order No</th>
        <th>Order Date</th>
        <th>Delivery Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo$inv['invoice_number'];?></td>
        <td><?php echo$order->order_number;?></td>
        <td><?php echo$order->order_date;?></td>
        <td><?php echo$order->order_delivery_status;?></td>
       
      </tr>
      
    </tbody>
  </table>
			
					
</div>
		<br />				
		
			
			<div class="row"> 
					<div class="col-md-6"> 
						 <div class="card">
							<div class="card-header">
							<b>Delivery Information</b>
							</div>
							<div class="card-body">
							<b style="color:#8000FF">Customer Name:</b> <?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?> <?php } else { echo$cus['name'];}?> <br />
							<b style="color:#8000FF">Customer Address:</b> <?php echo$cus['address_address'];?> <br />
							<b style="color:#8000FF">Area:</b> <?php echo$cus['address_area'];?> <br />
							<b style="color:#8000FF">Phone No:</b> <?php echo$cus['address_phone'];?> <br />
							<b style="color:#8000FF"> Preferred Delivery Schedule:</b> <?php if($order->order_delivery_date!==null && $order->order_delivery_slot!==null){echo$order->order_delivery_date." ".$order->order_delivery_slot;}
							else 
								{
									echo"Delivery Schedule not specified.";
								};?> <br />
							
							</div>
							
						</div>
					</div>
					
	<div class="col-md-6"> 
		<div class="card">
			<div class="card-header">
			<b>Payment Information</b>
			</div>
			<div class="card-body">
				<b style="color:#8000FF">Payment Method:</b> <?php 
				$p_method=$order->order_payment_method;
				if($p_method=="COD")
				{
					echo"Cash On Delivery";
				}
				else if($p_method=="SSL")
				{
					echo"SSL Payment Method";
				}
				?> <br />
				<b style="color:#8000FF">Payment Amount:</b> <?php echo$order->order_total_amount;?> <br />
				<b style="color:#8000FF">Payment Status:</b> <?php echo$order->order_payment_status;?> <br />
				<b style="color:#8000FF">Delivery Cost:</b> TK <?php echo$order->order_delivery_cost;?> <br /><br /><br />
				
			
			
			</div>
			
		</div>
	</div>
			</div>	  
				
<br />		
<table class="table table-bordered">
    <thead>
      <tr style="background:#CD9BDB;color:white">
        <th>SL No.</th>
        <th>Image</th>
        <th>Item Name</th>
        <th>Qty</th>
        <th>Unit Price</th>
        <th>Sub Total</th>
      </tr>
    </thead>
    <tbody>
	<?php 
	$sl=0;
	foreach($orderDetails as $details){
		$itemID=$details->details_item_id;
		$sl++;
		
		$products=$this->dashboardOrder_model->fetchOrderedProductsById($itemID); 
		
		foreach($products as $product){
		
		 //$this->load->model('product_model');
		 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
		 $proImage = $get_default_photo['image_url'];
		
		
		
		?>
      <tr>
        <td><?php echo$sl;?></td>
        <td><a target="_blank"href="<?php echo base_url('productDetails/').$product->product_id;?>"><img src="<?php echo base_url().$proImage?>" alt="" width="80"height="70"/></a></td>
        <td><a target="_blank"href="<?php echo base_url('productDetails/').$product->product_id;?>"><?php echo$product->title;?></a></td>
        <td><?php echo$details->details_item_quantity;?></td>
        <td><?php echo$details->details_item_unitprice;?></td>
        <td><?php echo$details->details_item_subtotal;?></td>
        
      </tr> 
	  <?php 
		}
		}
	  ?>
	  
    </tbody>
  </table>		  
					  
					  
  
  </div>
</div>
				
				
				
				
				
				</div>
<div class="col-md-3">
				
	<div class="card card-center">
	  <div class="card-header" style="background:#CD9BFF;color:white">
		Order Summary
	  </div> <br/> 
	
				  
<table class="table table-hover table-sm">
    
    <tbody>
      <tr>
        <th>Items Total:</th>
		<td><?php echo$order->order_total_amount;?></td>
      </tr>
	  <?php $apply_coupon=$order->order_applied_coupon;
	  if($apply_coupon)
	  {
		  ?>
	<tr>
        <th>Applied Coupon:</th>
		<td><?php echo$order->order_applied_coupon;?></td>
    </tr>
	<tr>
        <th>Coupon Discount (TK):</th>
		<td><?php echo$order->order_coupon_discount;?></td>
    </tr>
		  <?php 
	  }
	  ?>
	  
	  <tr>
        <th>Delivery Cost:</th>
		<td><?php echo$order->order_delivery_cost;?></td>
      </tr>
	  
	  
	  <tr>
        <th>Grand Total:</th>
		 <td><?php echo$order->order_grand_total;?></td>
      </tr>
	 
      
    </tbody>
  </table>
				  
			<a target="_blank"href="<?php echo base_url('admin/orders/printInvoice/').$order->order_id;?>" class="btn btn-success btn-block">Print Invoice | Office Copy</a>			
				<br />
				
				<a target="_blank"href="<?php echo base_url('admin/orders/printCustomerInvoice/').$order->order_id;?>" class="btn btn-info btn-block">Print Invoice | Customer Copy</a>			
				<br />	
				
					
<div class="form-group">
  <b style="color:magenta">Update Delivery Status:</b>
  <select class="form-control"id="delivery_status">
    <option>Select Status</option>
    <option value="On Delivery">On Delivery</option>
    <option value="Delivered">Delivered</option>
    <option value="Cancelled">Cancelled</option>
    
  </select>
</div>

<div class="form-group">
  <b style="color:magenta">Update Payment Status:</b>
  <select class="form-control" id="payment_status">
  <option>Select Status</option>
    <option value="Unpaid">Unpaid</option>
    <option value="Processing">Processing</option>
    <option value="Paid">Paid</option>
  </select>
</div>
				
	
		<br />
		
		<a href="<?php echo base_url('admin/productOrders');?>" class="btn btn-danger ">Back To OrderList</a> <br />
		
	</div>
				
</div>



</div>
			
			
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
   <script>
$('#payment_status').on('change', function(){
	var urlmg = "<?php echo base_url('dashboardOrder/paymentstatus'); ?>";
	var payment_status = $(this).val();
	var order_id = "<?php echo$order->order_id; ?>";
	$.ajax({
		url:urlmg,
		type:"POST",
		data:{payment_status:payment_status,order_id:order_id},
		success:function(){
			location.reload();
		}
	});
	
});


$('#delivery_status').on('change', function(){
	var urlmg = "<?php echo base_url('dashboardOrder/deliverystatus'); ?>";
	var delivery_status = $(this).val();
	var order_id = "<?php echo$order->order_id; ?>";
	$.ajax({
		url:urlmg,
		type:"POST",
		data:{delivery_status:delivery_status,order_id:order_id},
		success:function(){
			location.reload();
		}
	});
	
});


</script>     
		
		
<?php 


}
?>	
		