<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Shombhob.com Order Invoice</title>
	
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <style> 
  .right_align{float:right;margin-top:-80px;}
  .right_align_footer{float:right;}
  .title{text-decoration: underline;}
  .signature{border-top:1px dotted black;}
  .copy_text{text-align:center;color:#ddd;font-size:20px;margin-bottom:20px;}
  </style>
	
</head>
<body>
    <?php 
    function numberTowords($num)
{

$ones = array(
0 =>"ZERO",
1 => "ONE",
2 => "TWO",
3 => "THREE",
4 => "FOUR",
5 => "FIVE",
6 => "SIX",
7 => "SEVEN",
8 => "EIGHT",
9 => "NINE",
10 => "TEN",
11 => "ELEVEN",
12 => "TWELVE",
13 => "THIRTEEN",
14 => "FOURTEEN",
15 => "FIFTEEN",
16 => "SIXTEEN",
17 => "SEVENTEEN",
18 => "EIGHTEEN",
19 => "NINETEEN",
"014" => "FOURTEEN"
);
$tens = array( 
0 => "ZERO",
1 => "TEN",
2 => "TWENTY",
3 => "THIRTY", 
4 => "FORTY", 
5 => "FIFTY", 
6 => "SIXTY", 
7 => "SEVENTY", 
8 => "EIGHTY", 
9 => "NINETY" 
); 
$hundreds = array( 
"HUNDRED", 
"THOUSAND", 
"MILLION", 
"BILLION", 
"TRILLION", 
"QUARDRILLION" 
); /*limit t quadrillion */
$num = number_format($num,2,".",","); 
$num_arr = explode(".",$num); 
$wholenum = $num_arr[0]; 
$decnum = $num_arr[1]; 
$whole_arr = array_reverse(explode(",",$wholenum)); 
krsort($whole_arr,1); 
$rettxt = ""; 
foreach($whole_arr as $key => $i){
	
while(substr($i,0,1)=="0")
		$i=substr($i,1,5);
if($i < 20){ 
/* echo "getting:".$i; */
$rettxt .= $ones[$i]; 
}elseif($i < 100){ 
if(substr($i,0,1)!="0")  $rettxt .= $tens[substr($i,0,1)]; 
if(substr($i,1,1)!="0") $rettxt .= " ".$ones[substr($i,1,1)]; 
}else{ 
if(substr($i,0,1)!="0") $rettxt .= $ones[substr($i,0,1)]." ".$hundreds[0]; 
if(substr($i,1,1)!="0")$rettxt .= " ".$tens[substr($i,1,1)]; 
if(substr($i,2,1)!="0")$rettxt .= " ".$ones[substr($i,2,1)]; 
} 
if($key > 0){ 
$rettxt .= " ".$hundreds[$key]." "; 
}
} 
if($decnum > 0){
$rettxt .= " and ";
if($decnum < 20){
$rettxt .= $ones[$decnum];
}elseif($decnum < 100){
$rettxt .= $tens[substr($decnum,0,1)];
$rettxt .= " ".$ones[substr($decnum,1,1)];
}
}
return $rettxt;
}
    
    ?>

<div class="container-fluid">
    <center><span class="copy_text">OFFICE COPY</span></center>
    <div class="row"> 
    	    <div class="left_align">
				<img src="<?php echo base_url('assets/front-end/images/logo/shombhob_logo.jpg')?>" width="150px" height="60px"alt="logo" />
		    </div>
		    <div class="right_align">
		
				 <br />Helpline: +8801755697233 <br />Email&nbsp;&nbsp;: info@shombhob.com
			</div>	
				
			
	
		
			<br/>	<br/>
    </div>

<?php 
date_default_timezone_set('Asia/Dhaka');
foreach($orderInfo as $order){
	$orderID=$order->order_id;
	//$customerID=$order->order_customerid;
	$cusAddressID=$order->order_addressid;
	$inv=$this->dashboardOrder_model->fetchInvoiceByOrderId($orderID);
	$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($cusAddressID);
	$orderDetails=$this->dashboardOrder_model->fetchOrderDetailsByOrderId($orderID);
	
	?>
	
		<div class="row"> 
		
		
		
		
			<b>Hello <?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?>! <?php } else { echo$cus['name'];}?>!</b>
			<span>Thank you for shopping with us. Please find your order summary below.</span> <br /> <span>As always, shombhob.com remains at your service. </span>
			<br /><br />
			<b>Shombhob.com</b> Team.
			
			
		</div>
		<div class="row"> 
		
		<div class="col-md-12"> <center><h3 class="title">Delivery Information</h3></center></div> <br />
		</div>
		
		<div class="row"> 
		<br />
			<table width="100%">
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Name:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?> <?php } else { echo$cus['name'];}?></td>
					
						<td align="right"><b>Invoice Number:</b></td>
				    	<td align="left">&nbsp;&nbsp;<?php echo$inv['invoice_number'];?> DK042101</td>
					
				
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Address:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_address'];?></td>
					<td align="right"><b>Order Date:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$order->order_date;?></td>
				
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Area:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_area'];?></td>
				
					<td align="right"><b>Order Number:</b></td>
					<td align="left">&nbsp;&nbsp;<?php echo$order->order_number;?></td>
					<td></td>
					<td></td>
					
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td align="right"><b>Phone No.:</b></td>
					
					<td align="left">&nbsp;&nbsp;<?php echo$cus['address_phone'];?></td>
				
					<td align="right"><b>Payment Method:</b></td>
					<td align="left">&nbsp;&nbsp;<?php 
				$p_method=$order->order_payment_method;
				if($p_method=="COD")
				{
					echo"Cash On Delivery";
				}
				else if($p_method=="SSL")
				{
					echo"SSL Payment Method";
				}
				?></td>
				
					<td></td>
					<td></td>
				</tr>
			
			</table>
		
		</div>
		
		<div class="row"> 
			
			<div class="col-md-12"> <center><h3 class="title">Order Details</h3></center></div> 
		</div>
		
		<div class="row"> 
		<br />
			<table class="table table-bordered table-hover" width="100%" border="1">
				<tr style="background:#EBCAFE">
					<td align="center"><b>SL No.</b></td>
					<td align="center"><b>Item</b></td>
					<td align="center"><b>Quantity</b></td>
					<td align="right"><b>Unit Price</b></td>
					<td align="right"><b>Total</b></td>
				</tr>
	<?php 
		$sl=0;
		foreach($orderDetails as $details){
		$itemID=$details->details_item_id;
		$sl++;
		
		$products=$this->dashboardOrder_model->fetchOrderedProductsById($itemID); 
		
		foreach($products as $product){
		
		 //$this->load->model('product_model');
		 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
		 $proImage = $get_default_photo['image_url'];
		
	?>
	
	 <tr>
		<td align="center"><?php echo$sl;?></td>
		<td align="left"><?php echo$product->title;?></td>
		<td align="center"><?php echo$details->details_item_quantity;?></td>
		<td align="right">Tk <?php echo$details->details_item_unitprice;?></td>
		<td align="right">Tk <?php echo$details->details_item_subtotal;?></td>
	</tr>
	  
	  <?php 
		}
		}
	  ?>
	
				<tr>
					<td align="right"colspan="4"><b>Sub Total</b>:</td>
					<td align="right">Tk <?php echo$order->order_total_amount;?> </td>
				</tr>
				<?php $apply_coupon=$order->order_applied_coupon;
				  if($apply_coupon)
				  {
					  ?>
				<tr>
					<td align="right"colspan="4"><b>Applied Coupon:</b></td>
					<td align="right"><?php echo$order->order_applied_coupon;?></td>
				</tr>
				<tr>
					<td align="right"colspan="4"><b>Coupon Discount (TK):</b></td>
					<td align="right"><?php echo$order->order_coupon_discount;?></td>
				</tr>
					  <?php 
				  }
				  ?>
				<tr>
					<td align="right"colspan="4"><b>Delivery Charge</b>:</td>
					<td align="right">Tk <?php echo$order->order_delivery_cost;?> </td>
				</tr>
				<tr>
					<td align="right"colspan="4"><b>Grand Total</b>:</td>
					<td align="right">Tk <?php echo$order->order_grand_total;?> </td>
					
				</tr>
				
			</table>
		<span><b>In Words:</b> <?php $grndTotal=$order->order_grand_total; echo numberTowords($grndTotal);?> ONLY.</span> 
		
		<br /><br />
		</div>
		
			<div class="row"> 
		
		    <br />
			<br />
			<br/>
					<span class="signature">Signature of the customer</span>
					
			<span class="right_align_footer">
			    <span class="signature">Signature of the Authority</span>
			     </span>
			
			<br />
			<br />
			<br />
			<hr/>
			<span>Powered By: Shombhob.com Ltd.</span>
			<span class="right_align_footer">Printed On: <?php echo date('l - d F, Y - g:h:i A');?></span>
			
		</div>
		
		<?php 
}
		?>

</div>



	
  <!-- JavaScript: placed at the end of the document so the pages load faster -->
  <!-- JQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script>
	window.print();
</script>
  
</body>
</html>