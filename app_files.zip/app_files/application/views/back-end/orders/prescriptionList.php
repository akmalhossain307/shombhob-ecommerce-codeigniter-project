		
	
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
					<?php 
				}
				
					elseif($this->session->flashdata('categoryExist')){ ?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('categoryExist'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					  
					  
					<?php } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Prescriptions</h4>
                 
				  
                  <div class="row">
				  
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                            
                              <th>SL No.</th>
                              <th>Name</th>
                              <th>Contact</th>
                              <th>Image</th>
							  <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
					
						if($prescriptions)
						{
							$sl=0;
						foreach ($prescriptions as $pres){
							$sl++;
						 
							if($pres->status==1)
							{
							?>
                          
							
							<tr>
                             <td><?php echo$sl;?></td>
                              <td><?php echo$pres->name;?></td>
                              <td><?php echo$pres->phone;?></td>
                              <td><a href="<?php echo base_url('dashboardOrder/viewPrescription/').$pres->prescription_id;?>"><img id="prescriptionImg"src="<?php echo base_url('').$pres->prescriptionImage;?>" alt=""/></a></td>
                             
                             
                              <td class="text-right">
                                <button class="btn btn-light">
                                <a href="<?php echo base_url('dashboardOrder/viewPrescription/').$pres->prescription_id;?>">  <i class="mdi mdi-eye text-primary"></i>View Details</a>
                                </button>
								
                              </td>
                          </tr>
							<?php 
						}
						else 
						{
							?>
							<tr style="background:#EBCAFE">
                             <td><?php echo$sl;?></td>
                              <td><?php echo$pres->name;?></td>
                              <td><?php echo$pres->phone;?></td>
                              <td><a href="<?php echo base_url('dashboardOrder/viewPrescription/').$pres->prescription_id;?>"><img id="prescriptionImg"src="<?php echo base_url('').$pres->prescriptionImage;?>" alt=""/></a></td>
                             
                             
                              <td class="text-right">
                                <button class="btn btn-light">
                                <a href="<?php echo base_url('dashboardOrder/viewPrescription/').$pres->prescription_id;?>">  <i class="mdi mdi-eye text-primary"></i>View Details</a>
                                </button>
								
                              </td>
                          </tr>
							
							<?php 
						}
						}
						
						}
						else 
						{
							echo"No prescription uploaded yet...";
						}
						  ?>
						  
                         
						 
						 
						 
						 
						 
						 
						 
						 
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        