		
	
	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
					<?php 
				}
				
					elseif($this->session->flashdata('categoryExist')){ ?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('categoryExist'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					  
					  
					<?php } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Manage Invoice</h4>
                 
				  
                  <div class="row">
				  
				  
				 
				  
				  
				  
				  
				  
				  
				  
                    <div class="col-12 table-responsive table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                            
                              <th>SL No.</th>
                              <th>Invoice No.</th>
                              <th>Invoice Date</th>
                 
                              <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
					
						if($invoices)
						{
							$sl=0;
						foreach ($invoices as $inv){
							$sl++;
						 
							
							?>
                          
							
							<tr>
                             <td><?php echo$sl;?></td>
                              <td><?php echo$inv->invoice_number;?></td>
                              <td><?php echo$inv->invoice_date;?></td>
                             
                             
                              <td class="text-right">
                                <button class="btn btn-light">
                                <a href="<?php echo base_url('admin/orders/viewOrder/').$inv->invoice_order_id;?>">  <i class="mdi mdi-eye text-primary"></i>View Details</a>
                                </button>
								
                              </td>
                          </tr>
							<?php 
						}
						
						}
						else 
						{
							echo"No Invoice generated yet...";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        