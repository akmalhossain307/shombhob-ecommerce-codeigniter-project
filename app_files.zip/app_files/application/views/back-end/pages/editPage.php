		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
			
			<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>
			
				
				<div class="col-md-9">
					<div class="card border-success">
					  <div class="card-header" style="background:#dfe8fb">
						<strong> <i class=" link-icon fa fa-pencil"></i> Update Page</strong>
					  </div>
					  <div class="card-body text-success">
					  <?php foreach($page as $p){?>
						<form action="<?php echo base_url('admin/page/update/').$p->page_id;;?>" method="POST" enctype="multipart/form-data">
						  <div class="form-group">
							<label for="exampleFormControlInput1"><strong>Page Title</strong></label>
							<input type="text" name="pageTitle"class="form-control" placeholder="page title" value="<?php echo$p->pageTitle;?>" required >
						  </div>
						  
						  <div class="form-group">
							<label for="exampleFormControlSelect2"><strong>Page Status</strong></label>
							<select class="form-control" name="status" id="exampleFormControlSelect2">
							
							<?php $sts=$p->status;
							if($sts==1)
							{
								echo"<option value='1' selected >Published</option>";
								echo"<option value='0' >Unpublished</option>";
							}
							else 
							{
								echo"<option value='1' >Published</option>";
								echo"<option value='0' selected>Unpublished</option>";	
							}?>
							 
							</select>
						  </div>
						  
						  
						<label for="exampleFormControlSelect2"><strong>Page Details</strong></label>
						
						<textarea name="pageContent" id="summernoteExample" cols="30" rows="10" required ><?php echo$p->pageContent;?></textarea>
						
					  </div>
					</div>
					  <?php }?>
				</div>
				<div class="col-md-3">
				
				<div class="card card-center border-success">
				  <div class="card-header" style="background:#dfe8fb">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Update" />
					 
						<a href="<?php echo base_url('admin/managePages');?>" class="btn btn-danger btn-sm">Back</a>
					</div>
					<br />
				</div>
				
					</form>
				
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        