<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yesbd.com || Marchant Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  
  <div class="row"> 
  <div class="col-md-12"> 
  
  <div class="card">
	  <div class="card-header">
	  
	  <h5> <i> <a href="<?php echo base_url('marchantDashboard');?>">Yesbd.com Marchant Panel</a></i></h5>
	  <div class="text-left">   
<br />	  


	  </div>
	  <div class="text-right" style="margin-top:-50px"> 
		<img src="https://yesbd.com/assets/back-end/images/admin_user.jpg" alt="img" width="40" height="30" /> <br />
		Welcome <b><?php echo $this->session->userdata('user');?></b>
		<a href="<?php echo base_url('marchantLogout');?>">Logout</a>
	
	  </div>
	  
	  </div>
<div class="card-body">






	

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
				
				<div class="text-right"> 
				 <a href="<?php echo base_url('marchantDashboard');?>" class="btn btn-danger btn-sm">Back</a> 
				 </div>
				
				
                 <h4 class="card-title"> <i class="icon-list"></i> Customer List</h4>
                 
                  <div class="row">
                    <div class="col-12 table table-hover">
                      <table id="order-listing" class="table">
                        <thead>
                          <tr class="bg-light" style="text-align:center;">
                              <th>SL No#</th>
                              <th>Name</th>
                              <th>Address</th>
                              <th>Phone No</th>
                              
                              <th>Area</th>
                          </tr>
                        </thead>
                        <tbody>
						
						<?php 
						$customers=$this->marchant_model->fetch_merchant_customer(); 
						$sl=0;
						if($customers)
						{
						foreach ($customers as $cus){
							$sl++;
							?>
                          <tr>
                              <td><?php echo$sl;?></td>
                              <td><?php echo$cus->name?></td>
                              <td><?php echo$cus->address_address?></td>
                              <td><?php echo$cus->address_phone?></td>
                              <td><?php echo$cus->address_area?></td>
							  
                          </tr>
						  <?php 
						}
						}
						else 
						{
							echo"No customer found.";
						}
						  ?>
						  
                         
						  
						  
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        











<div class="card-footer">
   
  <i>&copy; <?php echo date('Y');?> Yesbd.Com Ltd. All Right Reserved.</i>
  </div>



  </div>
  </div>
  
  
  
  
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>


<script type="text/javascript"> 

$(document).ready(function () {
  //Pagination full
  $('#paginationFull').DataTable({
    "pagingType": "full"
  });
  
  //Pagination full
  $('#paginationFull1').DataTable({
    "pagingType": "full"
  });
});
</script>

</body>
</html>