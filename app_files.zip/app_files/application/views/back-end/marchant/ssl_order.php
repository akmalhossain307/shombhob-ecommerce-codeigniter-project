<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yesbd.com || Marchant Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  
  <div class="row"> 
  <div class="col-md-12"> 
  
  <div class="card">
	  <div class="card-header">
	  
	  <h5> <i> <a href="<?php echo base_url('marchantDashboard');?>">Yesbd.com Marchant Panel</a></i></h5>
	  <div class="text-left">   
<br />	  

<h4>Sortlisted Products</h4>
	  </div>
	  <div class="text-right" style="margin-top:-50px"> 
		<img src="https://yesbd.com/assets/back-end/images/admin_user.jpg" alt="img" width="40" height="30" /> <br />
		Welcome <b><?php echo $this->session->userdata('user');?></b>
		<a href="<?php echo base_url('marchantLogout');?>">Logout</a>
	
	  </div>
	  
	  </div>
<div class="card-body">

<table id="paginationFull" class="table" width="100%">
  <thead>
    
	<tr class="bg-light" style="text-align:center;">
                            
	  <th>SL No.</th>
	  <th>Order No.</th>
	  <th>Payment Method</th>
	  <th>Payment Channel</th>
	  <th>Grand Total(TK)</th>
	  <th>Delivery Status</th>
	  <th>Order Date</th>

  </tr>
  </thead>
  <tbody>
		
		<?php 
		
		$sl=0;
		$this->load->model('marchant_model');
		$orders=$this->marchant_model->get_sold_by_ssl();
		if($orders){
			foreach ($orders as $order){
				$sl++;
			 
				
				
				?>
                          <tr style="background:#EBCAFE;text-align:center">
                             
                              <td><?php echo$sl;?></td>
                              <td><?php echo$order['order_number'];?></td>
                              <td><?php echo$order['order_payment_method'];?></td>
                              <td><?php echo$order['paymentChannel'];?></td>
                              <td><?php echo$order['order_grand_total'];?></td>
                           
                              <td><?php echo$order['order_delivery_status'];?></td>
                              <td><?php echo$order['order_date'];?></td>
                             
                          </tr>
						  
						<?php 
						
		}
		}
						else 
						{
							echo"No order placed yet...";
						}
						  ?>
			
			
			
			
			
			
			
    
  </tbody>
 
</table>
  
  </div>
  <div class="card-footer">
   
  <i>&copy; <?php echo date('Y');?> Yesbd.Com Ltd. All Right Reserved.</i>
  </div>
</div>
  
 
  </div>
  </div>
  
  
  
  
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>


<script type="text/javascript"> 

$(document).ready(function () {
  //Pagination full
  $('#paginationFull').DataTable({
    "pagingType": "full"
  });
  
  //Pagination full
  $('#paginationFull1').DataTable({
    "pagingType": "full"
  });
});
</script>

</body>
</html>