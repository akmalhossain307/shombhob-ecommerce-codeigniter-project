<?php 
$this->load->model('Dashboard_model');
$total_revenue = $this->Dashboard_model->total_revenue();
?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
		 
            <div class="col-12 grid-margin">
				 <h2 style="color:#4CCEAC;">WELCOME TO MARCHANT PANEL</h2>
			
              <div class="card card-statistics">
                <div class="row">
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row"> 
						
                          <i class="icon-basket text-primary mr-0 mr-sm-4 icon-lg text-warning"></i>
                          <div class="wrapper text-center text-sm-left">
						  <a href="<?php echo base_url('admin/productOrders');?>">
                            <p class="card-text mb-0">Total Sales</p>
                            <div class="fluid-container">
							
                              <h3 class="card-title mb-0">TK <?php echo number_format($total_revenue['revenue']); ?></h3>
							  
                            </div></a>
                          </div>
						  
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="icon-bag text-success mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
						  <a href="<?php echo base_url('admin/productOrders');?>">
                            <p class="card-text mb-0">Total Orders</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_orders(); ?></h3>
                            </div>
							</a>
                          </div> 
						  
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="icon-speedometer text-info mr-0 mr-sm-4 icon-lg"></i>
						 
                          <div class="wrapper text-center text-sm-left">
						  <a href="<?php echo base_url('admin/productList')?>">
                            <p class="card-text mb-0">Total Products in Stock</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_product_instock(); ?></h3>
                            </div>
							</a>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="icon-basket text-danger mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
                           <a href="<?php echo base_url('admin/product/stockOutProduct')?>"> <p class="card-text mb-0">Products Out Of Stock</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0" style="color:red"><?php echo $this->Dashboard_model->total_stockout_products(); ?></h3>
                            </div>
							</a>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
              
			  <div class="card card-statistics">
                <div class="row">
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          <i class="mdi mdi-account-multiple-outline text-primary mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
						  <a href="<?php echo base_url('admin/customerList')?>">
                            <p class="card-text mb-0">Total Customers</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_customers(); ?></h3>
							 
                            </div>
							</a>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                        
						  <i class="icon-feed text-info mr-0 mr-sm-4 icon-lg"></i>
						 <a href="<?php echo base_url('admin/subscriberList')?>">
                          <div class="wrapper text-center text-sm-left">
                            <p class="card-text mb-0">Total Subscribers</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_subscribers(); ?></h3>
                            </div>
                          </div>
						  </a>
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          
						  <i class="icon-list text-success mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
                            <a href="<?php echo base_url('admin/product/requestedProduct');?>"><p class="card-text mb-0">Requested Products</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_requested_products(); ?></h3>
                            </div></a>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div class="card-col col-xl-3 col-lg-3 col-md-3 col-6">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center flex-column flex-sm-row">
                          
						  <i class="icon-cloud-upload text-success mr-0 mr-sm-4 icon-lg"></i>
                          <div class="wrapper text-center text-sm-left">
                            <a href="<?php echo base_url('admin/prescriptionList');?>"><p class="card-text mb-0">Uploaded Prescriptions</p>
                            <div class="fluid-container">
                              <h3 class="card-title mb-0"><?php echo $this->Dashboard_model->total_uploaded_prescriptions(); ?></h3>
                            </div>
							</a>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 col-sm-12 grid-margin stretch-card">
							<div class="card">
								<div class="card-body">
									<h3 style="color:#juyhsu;text-decoration:underline">QUICK LINKS</h3> <br />
									<a href="<?php echo base_url('admin/category/add')?>"><i class="fa fa-plus-square text-success"></i> Add Category</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/subCategory/create')?>"><i class="fa fa-plus-square text-success"></i> Add Sub-Category</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/brandList')?>"><i class="fa fa-plus-square text-danger"></i> Add Brand</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/product/create')?>"><i class="fa fa-plus-square text-warning"></i> Add Product</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/product/createOffer')?>"><i class="fa fa-plus-square text-warning"></i> Create Offer</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/productOrders')?>"><i class="icon-list text-success"></i> Order List</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/invoiceList')?>"><i class="icon-list text-info"></i> Invoice List</a>
									
									<br />
									<br />
									
									<a href="<?php echo base_url('admin/categoryList')?>"><i class="icon-list text-warning"></i> Category List</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/subCategoryList')?>"><i class="icon-list text-warning"></i> Sub-Category List</a>
									
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/brandList')?>"><i class="icon-list text-warning"></i> Brand List</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/productList')?>"><i class="icon-list text-success"></i> Product List</a>
									&nbsp;&nbsp;&nbsp;
									<a href="<?php echo base_url('admin/product/offerList')?>"><i class="icon-list text-success"></i> Offer List</a>
									<br /><br />
									
									
									
									
									
								</div>
							</div>
						</div>
            </div>
          
		  
		  <!--
		  
		  <div class="row">
            <div class="col-md-4 col-sm-6 grid-margin stretch-card">
							<div class="card text-center">
								<div class="card-body">
									<img src="<?php echo base_url('assets/back-end/')?>images/faces/face5.jpg" class="img-lg rounded-circle mb-2" alt="profile image"/>
									<h4>Maria Johnson</h4>
									<p class="text-muted">Developer</p>
									<p class="mt-4 card-text">
											Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
											Aenean commodo ligula eget dolor. Lorem
									</p>
									<button class="btn btn-primary btn-sm mt-3 mb-4">Follow</button>
									<div class="border-top pt-3">
										<div class="row">
											<div class="col-4">
												<h6>5896</h6>
												<p>Post</p>
											</div>
											<div class="col-4">
												<h6>1596</h6>
												<p>Followers</p>
											</div>
											<div class="col-4">
												<h6>7896</h6>
												<p>Likes</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
            <div class="col-md-4 col-sm-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body pb-0">
                  <div class="wrapper border-bottom">
                    <h5 class="mb-0 text-gray">Top Products</h5>
                    <h1 class="mb-0">598,486</h1>
                    <p class="mb-4">6.5% change from today</p>
                  </div>
                  <div class="pt-4 wrapper">
                    <h5 class="mb-0 text-gray">Support Cases</h5>
                    <h1 class="mb-0">323,360</h1>
                    <p>2.5% change from yesterday</p>
                  </div>
                </div>
                <canvas id="product-area-chart" height="200"></canvas>
              </div>
            </div>
            <div class="col-md-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="w-75 mx-auto">
                    <div class="d-flex justify-content-between text-center mb-2">
                      <div class="wrapper">
                        <h4>6,256</h4>
                        <small class="text-muted">Total sales</small>
                      </div>
                      <div class="wrapper">
                        <h4>8569</h4>
                        <small class="text-muted">Open Campaign</small>
                      </div>
                    </div>
                  </div>
                  <div id="morris-line-example" style="height:250px;"></div>
                  <div class="w-75 mx-auto">
                    <div class="d-flex justify-content-between text-center mt-5">
                      <div class="wrapper">
                        <h4>5136</h4>
                        <small class="text-muted">Online Sales</small>
                      </div>
                      <div class="wrapper">
                        <h4>4596</h4>
                        <small class="text-muted">Store Sales</small>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          -->
          
          
          
         </div>
        