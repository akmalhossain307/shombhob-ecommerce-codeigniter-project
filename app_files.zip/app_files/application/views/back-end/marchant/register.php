
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <title>Yesbd.com Marchant Login</title>
    
    
    <style> 
    
    .card {
  box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
}
    </style>
    
  </head>
  <body style="background:#EBCAFE">
   <div class="container">  
   <br/><br/><br/>
   
   <?php if($this->session->flashdata('regSuccess')){ ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<strong><?php echo $this->session->flashdata('regSuccess'); ?> <a href="<?php echo base_url('marchant')?>"> Click here to Login</a> </strong>
	</div>
	<?php }
	else if($this->session->flashdata('regError')){ ?>
	
	<div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<strong><?php echo $this->session->flashdata('regError'); ?></strong>
	</div>

	<?php 
	}
	else if($this->session->flashdata('userExist')){ ?>
	
	<div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<strong><?php echo $this->session->flashdata('userExist'); ?></strong>
	</div>
	
	<?php };?>


<div class="container pt-3">
  <div class="row justify-content-sm-center">
    <div class="col-sm-10 col-md-6">
      <div class="card border-info">
        <div class="card-header">Marchant Register</div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-4 text-center">
              <img src="https://yesbd.com/assets/front-end/images/logo/Yesbd_Logo_with_Tag_line.png" width="125px" > <br/><br/>
              <italic> Online Pharmacy & Healthcare Shop <italic>
            </div>
            <div class="col-md-8">
                
            <form action="<?php echo base_url('registerMarchant');?>" method="post">
                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-address-card"></i></span>
                    </div>
                    <input type="text" name="name" class="form-control" placeholder="Name" required>
                </div> 
				<div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                    </div>
                    <input type="text" name="username" class="form-control" placeholder="Username" required>
                </div>

                <div class="input-group form-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <input type="submit" name="register" value="Register" class="btn btn-success float-left login_btn">
                    &nbsp;&nbsp;&nbsp;<input type="reset" value="Reset" class="btn btn-danger float-right">
                </div>
				
            </form>
			
			<div class="form-group">
                  Already registered? <a href="<?php echo base_url('marchant')?>"> Click here to Login</a>
                </div>

            </div>
			 
			
			
          </div>
        </div>
      </div>
   
    </div>
  </div>
</div>
   
  
   
   
   </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>





