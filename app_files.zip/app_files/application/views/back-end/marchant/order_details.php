<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yesbd.com || Marchant Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  
  <div class="row"> 
  <div class="col-md-12"> 
  
  <div class="card">
	  <div class="card-header">
	  
	  <h5> <i> <a href="<?php echo base_url('marchantDashboard');?>">Yesbd.com Marchant Panel</a></i></h5>
	  <div class="text-left">   
<br />	  


	  </div>
	  <div class="text-right" style="margin-top:-50px"> 
		<img src="https://yesbd.com/assets/back-end/images/admin_user.jpg" alt="img" width="40" height="30" /> <br />
		Welcome <b><?php echo $this->session->userdata('user');?></b>
		<a href="<?php echo base_url('marchantLogout');?>">Logout</a>
	
	  </div>
	  
	  </div>
<div class="card-body">










		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
				
				
				<?php foreach($orderinfo as $order){
					$orderID=$order->order_id;
					//$customerID=$order->order_customerid;
					$cusAddressID=$order->order_addressid;
				
					$inv=$this->dashboardOrder_model->fetchInvoiceByOrderId($orderID);
					//$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($customerID);
					$cus=$this->dashboardOrder_model->fetchCusInfoByOrderId($cusAddressID);
					$orderDetails=$this->dashboardOrder_model->fetchOrderDetailsByOrderId($orderID);
					?>
				
					<div class="card">
					  <div class="card-header" style="background:#CD9BFF;color:white">
						<strong> <i class=" link-icon fa fa-eye"></i> Order Details</strong>
					  </div>
					  <div class="card-body ">
<div class="row"> 
<table class="table table-hover table-sm">
    <thead>
      <tr>
        <th>Invoice No</th>
        <th>Order No</th>
        <th>Order Date</th>
        <th>Delivery Status</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo$inv['invoice_number'];?></td>
        <td><?php echo$order->order_number;?></td>
        <td><?php echo$order->order_date;?></td>
        <td><?php echo$order->order_delivery_status;?></td>
       
      </tr>
      
    </tbody>
  </table>
			
					
</div>
		<br />				
		
			
			<div class="row"> 
					<div class="col-md-6"> 
						 <div class="card">
							<div class="card-header">
							<b>Delivery Information</b>
							</div>
							<div class="card-body">
							<b style="color:#8000FF">Customer Name:</b> <?php if($cus['name']==false){?> <?php echo$cus['address_first_name'];?> <?php echo$cus['address_last_name'];?> <?php } else { echo$cus['name'];}?> <br />
							<b style="color:#8000FF">Customer Address:</b> <?php echo$cus['address_address'];?> <br />
							<b style="color:#8000FF">Area:</b> <?php echo$cus['address_area'];?> <br />
							<b style="color:#8000FF">Phone No:</b> <?php echo$cus['address_phone'];?> <br />
							<b style="color:#8000FF"> Preferred Delivery Schedule:</b> <?php if($order->order_delivery_date!==null && $order->order_delivery_slot!==null){echo$order->order_delivery_date." ".$order->order_delivery_slot;}
							else 
								{
									echo"Delivery Schedule not specified.";
								};?> <br />
							
							</div>
							
						</div>
					</div>
					
	<div class="col-md-6"> 
		<div class="card">
			<div class="card-header">
			<b>Payment Information</b>
			</div>
			<div class="card-body">
				<b style="color:#8000FF">Payment Method:</b> <?php 
				$p_method=$order->order_payment_method;
				if($p_method=="COD")
				{
					echo"Cash On Delivery";
				}
				else if($p_method=="SSL")
				{
					echo"SSL Payment Method";
				}
				?> <br />
				<b style="color:#8000FF">Payment Amount:</b> <?php echo$order->order_total_amount;?> <br />
				<b style="color:#8000FF">Payment Status:</b> <?php echo$order->order_payment_status;?> <br />
				<b style="color:#8000FF">Delivery Cost:</b> TK <?php echo$order->order_delivery_cost;?> <br /><br /><br />
				
			
			
			</div>
			
		</div>
	</div>
			</div>	  
				
<br />		
<table class="table table-bordered">
    <thead>
      <tr style="background:#CD9BDB;color:white">
        <th>SL No.</th>
        <th>Image</th>
        <th>Item Name</th>
        <th>Qty</th>
        <th>Unit Price</th>
        <th>Sub Total</th>
      </tr>
    </thead>
    <tbody>
	<?php 
	$sl=0;
	foreach($orderDetails as $details){
		$itemID=$details->details_item_id;
		$sl++;
		
		$products=$this->dashboardOrder_model->fetchOrderedProductsById($itemID); 
		
		foreach($products as $product){
		
		 //$this->load->model('product_model');
		 $get_default_photo = $this->product_model->get_default_photo($product->product_id);
		 $proImage = $get_default_photo['image_url'];
		
		
		
		?>
      <tr>
        <td><?php echo$sl;?></td>
        <td><a target="_blank"href="<?php echo base_url('productDetails/').$product->product_id;?>"><img src="<?php echo base_url().$proImage?>" alt="" width="80"height="70"/></a></td>
        <td><a target="_blank"href="<?php echo base_url('productDetails/').$product->product_id;?>"><?php echo$product->title;?></a></td>
        <td><?php echo$details->details_item_quantity;?></td>
        <td><?php echo$details->details_item_unitprice;?></td>
        <td><?php echo$details->details_item_subtotal;?></td>
        
      </tr> 
	  <?php 
		}
		}
	  ?>
	  
    </tbody>
  </table>		  
					  
					  
  
  </div>
</div>
				
				
				
				
				
				</div>
<div class="col-md-3">
				
	<div class="card card-center">
	  <div class="card-header" style="background:#CD9BFF;color:white">
		Order Summary
	  </div> <br/> 
	
				  
<table class="table table-hover table-sm">
    
    <tbody>
      <tr>
        <th>Items Total:</th>
		<td><?php echo$order->order_total_amount;?></td>
      </tr>
	  <?php $apply_coupon=$order->order_applied_coupon;
	  if($apply_coupon)
	  {
		  ?>
	<tr>
        <th>Applied Coupon:</th>
		<td><?php echo$order->order_applied_coupon;?></td>
    </tr>
	<tr>
        <th>Coupon Discount (TK):</th>
		<td><?php echo$order->order_coupon_discount;?></td>
    </tr>
		  <?php 
	  }
	  ?>
	  
	  <tr>
        <th>Delivery Cost:</th>
		<td><?php echo$order->order_delivery_cost;?></td>
      </tr>
	  
	  
	  <tr>
        <th>Grand Total:</th>
		 <td><?php echo$order->order_grand_total;?></td>
      </tr>
	 
      
    </tbody>
  </table>
				  
					
	
				
	
		<br />
		
		<a href="<?php echo base_url('marchant/orderList');?>" class="btn btn-danger ">Back To OrderList</a> <br />
		
	</div>
				
</div>



</div>
			
			
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
   <script>
$('#payment_status').on('change', function(){
	var urlmg = "<?php echo base_url('dashboardOrder/paymentstatus'); ?>";
	var payment_status = $(this).val();
	var order_id = "<?php echo$order->order_id; ?>";
	$.ajax({
		url:urlmg,
		type:"POST",
		data:{payment_status:payment_status,order_id:order_id},
		success:function(){
			location.reload();
		}
	});
	
});


$('#delivery_status').on('change', function(){
	var urlmg = "<?php echo base_url('dashboardOrder/deliverystatus'); ?>";
	var delivery_status = $(this).val();
	var order_id = "<?php echo$order->order_id; ?>";
	$.ajax({
		url:urlmg,
		type:"POST",
		data:{delivery_status:delivery_status,order_id:order_id},
		success:function(){
			location.reload();
		}
	});
	
});


</script>     
		
		
<?php 


}
?>	
		



































  </div>
  <div class="card-footer">
   
  <i>&copy; <?php echo date('Y');?> Yesbd.Com Ltd. All Right Reserved.</i>
  </div>
</div>
  
 
  </div>
  </div>
  
  
  
  
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>


<script type="text/javascript"> 

$(document).ready(function () {
  //Pagination full
  $('#paginationFull').DataTable({
    "pagingType": "full"
  });
  
  //Pagination full
  $('#paginationFull1').DataTable({
    "pagingType": "full"
  });
});
</script>

</body>
</html>