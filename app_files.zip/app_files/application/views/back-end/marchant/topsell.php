<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yesbd.com || Marchant Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  
  <div class="row"> 
  <div class="col-md-12"> 
  
  <div class="card">
	  <div class="card-header">
	  
	  <h5> <i> <a href="<?php echo base_url('marchantDashboard');?>">Yesbd.com Marchant Panel</a></i></h5>
	  <div class="text-left">   
<br />	  

<h4>Top 20 Selling Products</h4>


	  </div>
	  
	  
	  <div class="text-right" style="margin-top:-50px"> 
		<img src="https://yesbd.com/assets/back-end/images/admin_user.jpg" alt="img" width="40" height="30" /> <br />
		Welcome <b><?php echo $this->session->userdata('user');?></b>
		<a href="<?php echo base_url('marchantLogout');?>">Logout</a>
	
	  </div>
	  
	  </div>
<div class="card-body">

<table id="paginationFull" class="table" width="100%">
  <thead>
    <tr>
      <th class="th-sm">SL No
      </th>
      <th class="th-sm">Title
      </th>
      <th class="th-sm">Picture
      </th>
      <th class="th-sm">Price
      </th>
      <th class="th-sm">Stock
      </th>
      <th class="th-sm">Status
      </th>
	  <th class="th-sm">Action
      </th>
    </tr>
  </thead>
  <tbody>
		
		<?php 
		
		$counter=0;
		$Products=$this->marchant_model->filterByProductByTopSeller();
			foreach($products as $product)
			{
				
				$counter++;
				
				$get_default_photo = $this->dashboardProduct_model->get_default_photo($product['product_id']);
				$proImage = $get_default_photo['image_url'];
				
				
				
				 //$this->load->model('Product_model');
				 //$get_default_photo = $this->product_model->get_default_photo($product['product_id']);
				 //$proImage = $get_default_photo['image_url'];
			
			
			?>
  
  
   <tr>
      <td><?php echo$counter;?></td>
      <td><?php echo$product['title'];?></td>
	  <td>
	 
	  <img src="<?php echo base_url().$proImage?>" alt="<?php echo$product['title'];?>" width="50" height="30"/></td>
	   <td><?php if($product['discountPrice'])
	   {
		   echo"<del style='color:red'>TK ".$product['price']."</del> TK ".$product['discountPrice'];
	   }
	   else 
	   {
		   echo"TK ".$product['price'];
	   };?></td>
	   
	   <td><?php echo$product['product_quantity'];?></td>
	   <td>
	  <?php $status=$product['product_status'];
	  if($status==1){
	  ?>
	  <a href="#" class="badge badge-success">Published</a>
		
	  <?php } 
	  else 
	  {?>
  <a href="#" class="badge badge-danger">Unpublished</a>
	  <?php }?>
	  </td>
	  <td> <a href="#" class="btn btn-info btn-sm"> SortList This Product</a></td>
    </tr>
    <?php 
		}
	
	?>
    
  </tbody>
 
</table>
  
  </div>
  <div class="card-footer">
   
  <i>&copy; <?php echo date('Y');?> Yesbd.Com Ltd. All Right Reserved.</i>
  </div>
</div>
  
 
  </div>
  </div>
  
  
  
  
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>


<script type="text/javascript"> 

$(document).ready(function () {
  //Pagination full
  $('#paginationFull').DataTable({
    "pagingType": "full"
  });
  
  //Pagination full
  $('#paginationFull1').DataTable({
    "pagingType": "full"
  });
});
</script>

</body>
</html>