<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo$title;?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h3 style="text-decoration:underline">Search Keyword List</h3>
            
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>SL No.</th>
        <th>Searck Key</th>
        <th>Search Date</th>
      </tr>
    </thead>
    <tbody>
	
	
	<?php 
	date_default_timezone_set("Asia/Dhaka");
	$sl=0;
	foreach($searchInfo as $src)
	{
		$sl++;
	?>
      <tr>
        <td><?php if($sl<10){echo"0".$sl;}else{echo$sl;}?></td>
        <td><?php echo$src['keywords'];?></td>
        <td><?php echo$src['search_date'];?></td>
		
        
      </tr>
	  
	  <?php 
	}
	  ?>
      
	  
    </tbody>
  </table>
</div>

<script>

  window.print();

</script>
</body>
</html>