<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo$title;?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h3 style="text-decoration:underline">Customer List</h3>
            
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>SL No.</th>
        <th>Name</th>
        <th>Email</th>
        
        <th>Address</th>
		<th>Mobile No.</th>
      </tr>
    </thead>
    <tbody>
	<?php 
	$sl=0;
	foreach($customerInfo as $cus)
	{
		$sl++;
	?>
      <tr>
        <td><?php if($sl<10){echo"0".$sl;}else{echo$sl;}?></td>
        <td><?php echo$cus['name'];?></td>
        <td><?php echo$cus['email'];?></td>
		<td><?php echo$cus['address_address'];?></td>
        <td><?php echo$cus['mobile'];?></td>
        
      </tr>
	  
	  <?php 
	}
	  ?>
      
	  
    </tbody>
  </table>
</div>

<script>

  window.print();

</script>
</body>
</html>