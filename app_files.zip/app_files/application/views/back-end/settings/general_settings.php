		

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-12">
			
			<div class="row"> 
				
				<div class="col-md-9">
					
					
				<?php if($this->session->flashdata('success')){ ?>
					  <div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<?php echo $this->session->flashdata('success'); ?>
					  </div>
				
					  
					  
				<?php  } elseif($this->session->flashdata('error')){ ?>
					  <div class="alert alert-warning alert-dismissible fade show" role="alert">
					<?php echo $this->session->flashdata('error'); ?>
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					  </button>
					</div>
					<?php } ?>	
					
					
					
					  
				<form action="<?php echo base_url('admin/updateGeneralSettings');?>" method="POST" enctype="multipart/form-data">
					
				<?php foreach($settings as $setting){?>
					
				  <div class="form-group">
					
					<div class="card border-success">
						  <div class="card-header" style="background:#dfe8fb"><b>Header Settings</b></div>
						  <div class="card-body text-success">
							<div class="text-right">
							<?php $imgURL=$setting->logoImage;?>
								<img id="img" src="<?php echo base_url().$imgURL;?>" alt="Logo image" />
							</div>
							<label for="exampleFormControlSelect2"><strong>Change Logo</strong></label>
							<input type='file' name="logoImage"class="form-control"onchange="readURL(this);" />
							
						  </div>
					
					</div>
				  </div>
				  
				  <div class="form-group">
					
					<div class="card border-success">
						  <div class="card-header" style="background:#dfe8fb"><b>SEO Settings</b></div>
						  <div class="card-body text-success">
							<label for="exampleFormControlInput1"><strong>SEO Titile</strong></label>
							<input type="text" name="seoTitle"class="form-control" value="<?php echo$setting->seoTitle;?>"placeholder="SEO Title" >
							<br /> 
							
							<label for="exampleFormControlInput1"><strong>Meta Keywords</strong></label>
							<textarea name="seoMetaKeyword" id="" class="form-control" cols="30" rows="10"><?php echo$setting->seoMetaKeyword;?></textarea>
							<br /> 
							
							<label for="exampleFormControlInput1"><strong>Meta Description</strong></label>
							<textarea name="seoMetaDescription" id="" class="form-control" cols="30" rows="10"><?php echo$setting->seoMetaDescription;?></textarea>
							
						  </div>
					
					</div>
				  </div>
				  
				  
				  <div class="form-group">
					
					<div class="card border-success">
						  <div class="card-header" style="background:#dfe8fb"><b>Company Settings</b></div>
						  <div class="card-body text-success">
							<label for="exampleFormControlInput1"><strong>Company Address</strong></label>
							<input type="text" name="companyAddress"class="form-control" value="<?php echo$setting->companyAddress;?>"placeholder="Company Address" >
							<br /> 
							
							<label for="exampleFormControlInput1"><strong>Company Email</strong></label>
							<input type="email" name="companyEmail"class="form-control" value="<?php echo$setting->companyEmail;?>"placeholder="Company Email" >
							<br />
							
							<label for="exampleFormControlInput1"><strong>Opening & Closing Time</strong></label>
							<input type="text" name="companyOpeningClosing"class="form-control" value="<?php echo$setting->companyOpeningClosing;?>" placeholder="Company opening & closing" >
							<br />
							
							<label for="exampleFormControlInput1"><strong>Phone Number</strong></label>
							<input type="text" name="companyPhone"class="form-control" placeholder="Company Phone number" value="<?php echo$setting->companyPhone;?>" >
							<br /> 
							
							<label for="exampleFormControlInput1"><strong>Deliver Time (Inside Dhaka)</strong></label>
							<input type="text" name="deliveryInsideDhaka"class="form-control" value="<?php echo$setting->deliveryInsideDhaka;?>" placeholder="Delivery inside Dhaka" >
							<br /> 
							
							<label for="exampleFormControlInput1"><strong>Deliver Time (Outside Dhaka)</strong></label>
							<input type="text" name="deliveryOutsideDhaka"class="form-control" value="<?php echo$setting->deliveryOutsideDhaka;?>"placeholder="Delivery outside Dhaka" >
							<br /> 
							
							
						  </div>
					
					</div>
				  </div>
				  
				  
				  <div class="form-group">
					
					<div class="card border-success">
						  <div class="card-header" style="background:#dfe8fb"><b>Footer Settings</b></div>
						  <div class="card-body text-success">
							<label for="exampleFormControlInput1"><strong>Copyright Text</strong></label>
							<input type="text" name="copyrightText"class="form-control" placeholder="Copyright Text" value="<?php echo$setting->copyrightText;?>">
							<br /> 
							
							
						  </div>
					
					</div>
				  </div>
						  
					
				
				</div>
				<div class="col-md-3">
				
				<div class="card card-center">
				  <div class="card-header">
					Action
				  </div> <br/> 
				  <div class="text-center"> 
						<input type="submit" class="btn btn-success btn-sm" value="Update Settings" />
					 
					</div>
					<br />
				</div>
				
					</form>
				<?php } ?>
				
				</div>
				</div>
			
			
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
       
        