<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model {
    function __construct() {
        $this->tableName = 'tbl_customer';
        $this->primaryKey = 'customer_id';
    }
    
    
    public function saveWebsiteUser($data)
			{
				$insert = $this->db->insert('tbl_website_user',$data);
				return ($insert == true) ? true : false;
			}
    
    public function fetchWebsiteUser()
		{
			$result=$this->db->select('*')
						->from('tbl_website_user')
						->get()
						->result();
					return $result;	
				
		}
		
		
		 public function checkWebsiteUser($user,$pass)
			{
				$result=$this->db->query("SELECT * FROM tbl_website_user WHERE user_name='$user' AND password='$pass'");
				//$result=$this->db->query("SELECT * FROM tbl_website_user WHERE user_name='akmalhossain307@gmail.com' AND password='e3afed0047b08059d0fada10f400c1e5'");
				return $result->row_array();
				
				
			}
			
			 public function changeWebsiteUserPassword($user_name,$password)
			{
				$u=$this->db->query("UPDATE tbl_website_user SET password='$password',cpassword='$password' WHERE user_name='$user_name'");
				//$result=$this->db->query("SELECT * FROM tbl_website_user WHERE user_name='akmalhossain307@gmail.com' AND password='e3afed0047b08059d0fada10f400c1e5'");
				if($u)
				{
				    return true;
				}
				else 
				{
				    return false;
				}
				
				
			}
			
			
			// Activate single category by id
			public function deactivateUserById($data,$id)
			{
			   $this->db->where("id", $id);  
			   $update=$this->db->update("tbl_website_user", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
		
		// Activate user by id
			public function activateUserById($data,$id)
			{
			   $this->db->where("id", $id);  
			   $update=$this->db->update("tbl_website_user", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			public function deleteUserById($id)
			{
				   $this->db->where("id", $id);  
				   $delete=$this->db->delete("tbl_website_user");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
    
    
    /*
     * Insert / Update facebook profile data into the database
     * @param array the data for inserting into the table
     */
    public function checkUser($userData = array()){
        if(!empty($userData)){
            //check whether user data already exists in database with same oauth info
            $this->db->select($this->primaryKey);
            $this->db->from($this->tableName);
            $this->db->where(array('oauth_provider'=>$userData['oauth_provider'], 'oauth_uid'=>$userData['oauth_uid']));
            $prevQuery = $this->db->get();
            $prevCheck = $prevQuery->num_rows();
            
            if($prevCheck > 0){
                $prevResult = $prevQuery->row_array();
                
                //update user data
                $userData['modified'] = date("Y-m-d H:i:s");
                $update = $this->db->update($this->tableName, $userData, array('customer_id' => $prevResult['customer_id']));
                
                //get user ID
                $userID = $prevResult['customer_id'];
            }else{
                //insert user data
                $userData['created']  = date("Y-m-d H:i:s");
                $userData['modified'] = date("Y-m-d H:i:s");
                $insert = $this->db->insert($this->tableName, $userData);
                
                //get user ID
                $userID = $this->db->insert_id();
            }
        }
        
        //return user ID
        return $userID?$userID:FALSE;
    }
}