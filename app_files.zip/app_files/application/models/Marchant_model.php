<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marchant_model extends CI_Model{
	
	 public function register_marchant($data)
			 {
				 	$insert = $this->db->insert('tbl_marchant',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 public function saveShortListedProduct($data)
			 {
				 	$insert = $this->db->insert('tbl_marchant_sortlisted',$data);
					return ($insert == true) ? true : false;
			 }
			 
		 // function for checking user already exist or not
		 public function checkMarchantUser($user)
			{
				$result=$this->db->select('*')
					->from('tbl_marchant')
					->where("username",$user)
					->get()
					->result();
				return $result;
			}
			
			
		 // function for marchant login
			public function checkMarchant($user,$pass)
			{
				$query = $this->db->query("SELECT * FROM tbl_marchant WHERE username='$user' AND password='$pass'");
				return $query->row_array();	
			}
	
	public function total_product_instock()
	{
		$query = $this->db->query("SELECT product_id FROM starter_shop_products WHERE starter_shop_products.product_quantity<>'0'");
		return $query->num_rows();
	}
	
	public function total_stockout_products()
	{
		$query = $this->db->query("SELECT product_id FROM starter_shop_products WHERE starter_shop_products.product_quantity='0'");
		return $query->num_rows();
	}
	
	// Filter products by- new product  
	public function filterByProductByNew()
	{
		$query = $this->db->query("SELECT * FROM starter_shop_products ORDER BY product_id DESC LIMIT 100");
		return $query->result_array();
	}
	
	// Filter products by- sortlisted by marchant  
	public function get_filtered_products()
	{
		$query = $this->db->query("SELECT starter_shop_products.product_id,title,price,discountPrice,product_quantity,product_status FROM starter_shop_products INNER JOIN tbl_marchant_sortlisted ON tbl_marchant_sortlisted.product_id=starter_shop_products.product_id ORDER BY entry_date DESC;");
		return $query->result_array();
	}
	
	// Remove item from sortlisted product  
	
	 public function deleteShortListedProduct($proId)
			{
				   $this->db->where("product_id",$proId);  
				   $delete=$this->db->delete("tbl_marchant_sortlisted");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
	
	// Filter products by- top seller product  
	public function filterByProductByTopSeller()
	{
	$query = $this->db->query("SELECT details_item_id, product_id, title,price,discountPrice,product_quantity,product_status ,SUM(details_item_quantity) AS TotalQuantity FROM tbl_order_details INNER JOIN starter_shop_products WHERE tbl_order_details.details_item_id=starter_shop_products.product_id GROUP BY details_item_id ORDER BY SUM(details_item_quantity) DESC LIMIT 50;");
	return $query->result_array();
	}
	
	// Filter products by- get_sold_by_ssl 
	public function get_sold_by_ssl()
	{
	$query = $this->db->query("SELECT * FROM tbl_customer_orders where order_payment_method='SSL' order by order_id DESC");
	return $query->result_array();
	}
	
	
	// fetch customer orders by merchant 
	public function get_customer_order_by_merchant()
	{
	$query = $this->db->query("SELECT * FROM tbl_customer_orders where order_customerid='1' order by order_id DESC");
	return $query->result_array();
	}
	
	// fetch order details by order id..
	public function get_order_details_by_order_id($order_id)
	{
	$result=$this->db->select('*')
					->from('tbl_customer_orders')
					->where("order_id",$order_id)
					->get()
					->result();
				return $result;
	
	}
	
	// fetch order details by order id..
	public function fetch_merchant_customer()
	{
	$result=$this->db->select('*')
					->from('tbl_customeraddress')
					->where("address_customerId",1)
					->get()
					->result();
				return $result;
	
	}
	
}
