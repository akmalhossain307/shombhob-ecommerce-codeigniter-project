<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class DashboardOrder_model extends CI_Model
	{
			// insert new product into db 
			public function insertNewProduct($data)
			{
				$insert = $this->db->insert('tbl_product',$data);
				return ($insert == true) ? true : false;
			}
			
			
			// function for fetching all product orders
			 public function get_all_orders()
			{
				$query = $this->db->query("SELECT * FROM tbl_customer_orders order by order_id DESC");
				return $query->result();
		
			}
			
			// function for fetching all product orders which are delivered
			 public function get_all_delivered_orders()
			{
				$query = $this->db->query("SELECT * FROM tbl_customer_orders WHERE order_delivery_status='Delivered' order by order_id ASC");
				return $query->result();
		
			}
			
			 public function getOrderDetailsByOrderId($order_id)
			{
				$query = $this->db->query("SELECT SUM(details_item_quantity) as sold_qty , details_item_id FROM tbl_order_details WHERE details_orderid='$order_id' GROUP BY details_item_quantity");
				return $query->result();
		
			}
			
			public function getProductDetailsByProductId($product_id)
			{
				$query = $this->db->query("SELECT title as product_name FROM starter_shop_products WHERE product_id='$product_id' GROUP BY title");
				return $query->result();
		
			}
			
			// function for fetching all product order invoices
			 public function get_all_invoices()
			{
				$query = $this->db->query("SELECT * FROM tbl_order_invoices order by invoice_id DESC");
				return $query->result();
		
			}
			
			// function for fetching all uploaded prescriptions
			 public function get_all_prescriptions()
			{
				$query = $this->db->query("SELECT * FROM tbl_prescriptions order by prescription_id DESC");
				return $query->result();
		
			}
			
			// function for fetching single product order
			 public function getSingleOrderById($orderID)
			{
				$result=$this->db->select('*')
					->from('tbl_customer_orders')
					->where("order_id",$orderID)
					->get()
					->result();
				return $result;
			}
			
			// function for fetching single prescription by id
			 public function getSinglePrescriptionById($presID)
			{
				$result=$this->db->select('*')
					->from('tbl_prescriptions')
					->where("prescription_id",$presID)
					->get()
					->result();
				return $result;
			}
			
			// function for fetching single product order
			 public function fetchInvoiceByOrderId($orderID)
			{
				$query = $this->db->query("SELECT invoice_number FROM tbl_order_invoices WHERE invoice_order_id='$orderID'");
				return $query->row_array();
			}
			
			// function for fetching single customer info by order customer id
			 public function fetchCusInfoByOrderId($cusAddressID)
			{
				$query = $this->db->query("SELECT * FROM tbl_customeraddress WHERE address_id='$cusAddressID'");
				return $query->row_array();
			}
			
			// function for fetching product order products
			 public function fetchOrderedProductsById($itemID)
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where("product_id",$itemID)
					->get()
					->result();
				return $result;
			}
			
			// function for fetching single product order
			 public function fetchOrderDetailsByOrderId($orderID)
			{
				$result=$this->db->select('*')
					->from('tbl_order_details')
					->where("details_orderid",$orderID)
					->get()
					->result();
				return $result;
			}
			
			
			//function for getting product by product id 
			public function getProductById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_product')
					->where("product_id",$id)
					->get()
					->result();
				return $result;
			}
			
			//function for getting stock out product 
			public function getStockOutProduct()
			{
				$result=$this->db->select('*')
					->from('tbl_product')
					->where("stockQty",0)
					->get()
					->result();
				return $result;
			}
			
			// update single product by id
			public function updateProductById($data,$id)
			{
			   $this->db->where("product_id", $id);  
			   $update=$this->db->update("tbl_product", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// update single product by id
			public function changeViewStatus($data,$orderID)
			{
			   $this->db->where("order_id", $orderID);  
			   $update=$this->db->update("tbl_customer_orders", $data);  
			  
			}
			
			// update single prescription by id
			public function changePrescriptionViewStatus($data,$presID)
			{
			   $this->db->where("prescription_id", $presID);  
			   $update=$this->db->update("tbl_prescriptions", $data);  
			  
			}
			
			
			public function update_delivery($order_id, $data)
			{
				$this->db->where('order_id', $order_id);
				$this->db->update('tbl_customer_orders', $data);
			}
			
			
			
			// function for deleting specific product order by product id
			 public function deleteProductOrderById($order_id)
			{
				   $this->db->where("order_id", $order_id);  
				   $delete=$this->db->delete("tbl_customer_orders");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			
			
			
			
			// function for fetching all requested products
			 public function getRequestedProduct()
			{
				$result=$this->db->select('*')
					->from('tbl_requestedProduct')
					->get()
					->result();
				return $result;
			}
			
			// function for deleting specific requested product by id
			 public function deleteRequestedProductById($id)
			{
				   $this->db->where("id", $id);  
				   $delete=$this->db->delete("tbl_requestedProduct");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			// Insert new product offer
			public function insertNewProductOffer($data)
			{
				$insert = $this->db->insert('tbl_productoffer',$data);
				return ($insert == true) ? true : false;
			}
			
			// function for fetching all product offers
			 public function getOfferProduct()
			{
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->get()
					->result();
				return $result;
			}
			
			
			//function for getting product by product id 
			public function getProductOfferById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where("offer_id",$id)
					->get()
					->result();
				return $result;
			}
			
			// update single product offer by id
			public function updateProductOfferById($data,$id)
			{
			   $this->db->where("offer_id", $id);  
			   $update=$this->db->update("tbl_productoffer", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for deleting specific product offer by id
			 public function deleteProductOfferById($id)
			{
				   $this->db->where("offer_id", $id);  
				   $delete=$this->db->delete("tbl_productoffer");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			 
			
	}
?>