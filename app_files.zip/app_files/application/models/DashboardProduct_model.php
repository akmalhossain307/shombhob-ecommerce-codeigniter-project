<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class DashboardProduct_model extends CI_Model
	{
			// insert new product into db 
			public function insertNewProduct($data)
			{
				$insert = $this->db->insert('starter_shop_products',$data);
				return ($insert == true) ? true : false;
			}
			public function save_images($data)
			{
				$this->db->insert('starter_products_images', $data);
			}
			
			
			
			// update single product image by image productid
			public function update_product_image($photo,$image_productid)
			{
			   $this->db->where("image_productid", $image_productid);  
			   $update=$this->db->update("starter_products_images", $photo);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for fetching all products
			 public function get_all_products()
			{
				/*
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->get()
					->result();
				return $result;
				*/
				
				$query = $this->db->query("SELECT * FROM starter_shop_products ORDER BY starter_shop_products.product_create_date DESC");
				return $query->result_array();
				
				
			}
			
			
			// function for fetching all products viewed by website visitors
			 public function fetchviewedProducts()
			{
				/*
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->get()
					->result();
				return $result;
				*/
				
				$query = $this->db->query("SELECT * FROM tbl_view_list
LEFT JOIN starter_shop_products ON tbl_view_list.product_id = starter_shop_products.product_id
ORDER BY tbl_view_list.view_date DESC");
				return $query->result_array();
				
				
			}
			
			
			
			
			
			public function get_default_photo($product_id)
			{
				$query = $this->db->query("SELECT image_url FROM starter_products_images 
										   WHERE starter_products_images.image_productid='$product_id'
										   ORDER BY starter_products_images.image_id ASC
										   ");
				return $query->row_array();
			}
			
			
			//function for getting product by product id 
			public function getProductById($id)
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where("product_id",$id)
					->get()
					->result();
				return $result;
			}
			
			//function for getting stock out product 
			public function getStockOutProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where("product_quantity",0)
					->get()
					->result();
				return $result;
			}
			
			//function for getting list of restock requested products
			public function fetchRestockRequestedProducts()
			{
			/*
				$result=$this->db->select('*')
					->from('tbl_product_restock_request')
					->get()
					->result();
				return $result;
				
				*/
				
				$query = $this->db->query("SELECT * FROM tbl_product_restock_request
LEFT JOIN starter_shop_products ON tbl_product_restock_request.product_id = starter_shop_products.product_id
ORDER BY tbl_product_restock_request.request_date DESC");
				return $query->result_array();
				
				
				
			}
			
			
			// update single product by id
			public function updateProductById($data,$id)
			{
			   $this->db->where("product_id", $id);  
			   $update=$this->db->update("starter_shop_products", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			// Deactivate single product by id
			public function unpublishProductById($data,$id)
			{
			   $this->db->where("product_id", $id);  
			   $update=$this->db->update("starter_shop_products", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// Activate single product by id
			public function publishProductById($data,$id)
			{
			   $this->db->where("product_id", $id);  
			   $update=$this->db->update("starter_shop_products", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			
			
			// function for deleting specific product by product id
			 public function deleteProductById($id)
			{
				   $this->db->where("product_id", $id);  
				   $delete=$this->db->delete("starter_shop_products");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			
			
			
			
			// function for fetching all requested products
			 public function getRequestedProduct()
			{
				$result=$this->db->select('*')
					->from('tbl_requestedproduct')
					->get()
					->result();
				return $result;
			}
			
			// function for deleting specific requested product by id
			 public function deleteRequestedProductById($id)
			{
				   $this->db->where("id", $id);  
				   $delete=$this->db->delete("tbl_requestedProduct");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			// Insert new product offer
			public function insertNewProductOffer($data)
			{
				$insert = $this->db->insert('tbl_productoffer',$data);
				return ($insert == true) ? true : false;
			}
			
			// Insert new coupon 
			public function insertNewCoupon($data)
			{
				$insert = $this->db->insert('starter_coupons',$data);
				return ($insert == true) ? true : false;
			}
			
			// function for fetching all product offers
			 public function getOfferProduct()
			{
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->get()
					->result();
				return $result;
			}
			
			
			
			
			//function for getting product by product id 
			public function getProductOfferById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where("offer_id",$id)
					->get()
					->result();
				return $result;
			}
			
			// update single product offer by id
			public function updateProductOfferById($data,$id)
			{
			   $this->db->where("offer_id", $id);  
			   $update=$this->db->update("tbl_productoffer", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for deleting specific product offer by id
			 public function deleteProductOfferById($id)
			{
				   $this->db->where("offer_id", $id);  
				   $delete=$this->db->delete("tbl_productoffer");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			
			
			// function for fetching all product coupon offers
			 public function getCouponOffers()
			{
				$result=$this->db->select('*')
					->from('starter_coupons')
					->get()
					->result();
				return $result;
			}
			
			// Deactivate single coupon by id
			public function deactivateCouponById($data,$id)
			{
			   $this->db->where("coupon_id", $id);  
			   $update=$this->db->update("starter_coupons", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// Activate single coupon by id
			public function activateCouponById($data,$id)
			{
			   $this->db->where("coupon_id", $id);  
			   $update=$this->db->update("starter_coupons", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for deleting specific coupon by id
			public function deleteCouponById($coupon_id)
			{
				   $this->db->where("coupon_id", $coupon_id);  
				   $delete=$this->db->delete("starter_coupons");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			 
			
	}
?>