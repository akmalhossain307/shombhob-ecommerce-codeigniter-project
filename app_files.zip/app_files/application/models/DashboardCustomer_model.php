<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class DashboardCustomer_model extends CI_Model
	{
		
			 // function for fetching all customer
			 public function get_all_customer()
			{
				$result=$this->db->select('*')
					->from('tbl_customer')
					->get()
					->result();
				return $result;
			}
			
			// function for fetching specific category by category id
			 public function getCustomerById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_customer')
					->where("customer_id",$id)
					->get()
					->result();
				return $result;
			}
			

			// function for deleting specific customer by customer id
			 public function deleteCustomerById($id)
			{
				   $this->db->where("customer_id", $id);  
				   $delete=$this->db->delete("tbl_customer");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			
			 
			// function for fetching all subscribers
			public function get_all_subscriber()
			{
				$result=$this->db->select('*')
					->from('tbl_subscribers')
					->get()
					->result();
				return $result;
			}
			
			// function for deleting specific subscriber by customer id
			 public function deleteSubscriberById($id)
			{
				   $this->db->where("subscriber_id", $id);  
				   $delete=$this->db->delete("tbl_subscribers");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			 
			 
			
	}
?>