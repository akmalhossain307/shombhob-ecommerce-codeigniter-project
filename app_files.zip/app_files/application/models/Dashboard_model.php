<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model{
	
	public function total_revenue()
	{
		$query = $this->db->query("SELECT SUM(order_grand_total) AS revenue FROM tbl_customer_orders WHERE tbl_customer_orders.order_payment_status='Paid' AND tbl_customer_orders.order_delivery_status='Delivered'");
		return $query->row_array();
	}
	
	public function total_displayed_products()
	{
		$query = $this->db->query("SELECT product_id FROM starter_shop_products WHERE starter_shop_products.product_status=1");
		return $query->num_rows();
	}
	
	public function total_requested_products()
	{
		$query = $this->db->query("SELECT id FROM tbl_requestedproduct");
		return $query->num_rows();
	}
	
	public function total_uploaded_prescriptions()
	{
		$query = $this->db->query("SELECT prescription_id FROM tbl_prescriptions");
		return $query->num_rows();
	}
	
	public function total_customers()
	{
		$query = $this->db->query("SELECT customer_id FROM tbl_customer");
		return $query->num_rows();
	}
	
	public function total_subscribers()
	{
		$query = $this->db->query("SELECT subscriber_id FROM tbl_subscribers");
		return $query->num_rows();
	}
	
	public function total_orders()
	{
		$query = $this->db->query("SELECT order_id FROM tbl_customer_orders");
		return $query->num_rows();
	}
	
	public function get_active_admin()
	{
		$admin_id = $this->session->userdata('active_user');
		$query = $this->db->query("SELECT starter_owner.*, 
								   starter_admin_role.role_title
								   FROM starter_owner
								   LEFT JOIN starter_admin_role ON
								   starter_admin_role.role_id=starter_owner.owner_role_id
								   WHERE starter_owner.owner_id='$admin_id'
								   ");
		return $query->row_array();
	}
	
	public function get_orders_weekly($day)
	{
		$query = $this->db->query("SELECT 
								   order_id 
								   FROM starter_users_orders 
								   LEFT JOIN starter_report_mapping ON
								   starter_report_mapping.mapping_orderid=starter_users_orders.order_id
								   WHERE order_date > DATE_SUB(NOW(), INTERVAL 1 WEEK)
								   AND mapping_day='$day'
								   ");
		return $query->num_rows();
	}
	
	public function get_revenue_weekly($day)
	{
		$query = $this->db->query("SELECT 
								   SUM(order_grand_total) AS revenue 
								   FROM starter_users_orders 
								   LEFT JOIN starter_report_mapping ON
								   starter_report_mapping.mapping_orderid=starter_users_orders.order_id
								   WHERE order_date > DATE_SUB(NOW(), INTERVAL 1 WEEK)
								   AND starter_users_orders.order_payment_status='Paid'
								   AND starter_users_orders.order_delivery_status='completed'
								   AND mapping_day='$day'
								   ");
		return $query->row_array();
	}
	
	public function get_sale_monthly($month)
	{
		$query = $this->db->query("SELECT 
								   order_id 
								   FROM starter_users_orders 
								   LEFT JOIN starter_report_mapping ON
								   starter_report_mapping.mapping_orderid=starter_users_orders.order_id
								   WHERE order_date > DATE_SUB(NOW(), INTERVAL 1 MONTH)
								   AND starter_users_orders.order_payment_status='Paid'
								   AND starter_users_orders.order_delivery_status='completed'
								   AND mapping_month='$month'
								   ");
		return $query->num_rows();
	}
	
	public function get_revenue_monthly($month)
	{
		$query = $this->db->query("SELECT 
								   SUM(order_grand_total) AS revenue 
								   FROM starter_users_orders 
								   LEFT JOIN starter_report_mapping ON
								   starter_report_mapping.mapping_orderid=starter_users_orders.order_id
								   WHERE order_date > DATE_SUB(NOW(), INTERVAL 1 MONTH)
								   AND starter_users_orders.order_payment_status='Paid'
								   AND starter_users_orders.order_delivery_status='completed'
								   AND mapping_month='$month'
								   ");
		return $query->row_array();
	}
	
	public function total_product_instock()
	{
		$query = $this->db->query("SELECT product_id FROM starter_shop_products WHERE starter_shop_products.product_quantity<>'0'");
		return $query->num_rows();
	}
	
	public function total_stockout_products()
	{
		$query = $this->db->query("SELECT * FROM starter_shop_products WHERE starter_shop_products.product_quantity=0");
		return $query->num_rows();
	}
	
}
