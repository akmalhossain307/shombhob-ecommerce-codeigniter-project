<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class DashboardSettings_model extends CI_Model
	{
			
			
			//function for getting social profile links 
			public function fetchSocialLinks()
			{
				$result=$this->db->select('*')
					->from('tbl_social_settings')
					->where("social_id",1)
					->get()
					->result();
				return $result;
			}
			
			
			
			// update social profile link
			public function modifySocialSettings($data)
			{
			   $this->db->where("social_id",1);  
			   $update=$this->db->update("tbl_social_settings", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// update general settings data 
			public function modifyGeneralSettings($data)
			{
			   $this->db->where("setting_id",1);  
			   $update=$this->db->update("tbl_general_settings", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			
			//function for getting general settings data 
			public function fetchGeneralSettings()
			{
				$result=$this->db->select('*')
					->from('tbl_general_settings')
					->where("setting_id",1)
					->get()
					->result();
				return $result;
			}
			
			
			
			
			// insert new page data into db 
			public function saveNewPageData($data)
			{
				$insert = $this->db->insert('tbl_pages',$data);
				return ($insert == true) ? true : false;
			}
			
			// function for fetching all pages
			 public function fetchPages()
			{
				$result=$this->db->select('*')
					->from('tbl_pages')
					->get()
					->result();
				return $result;
			}
			
			//function for getting page data by id 
			public function fetchPageById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_pages')
					->where("page_id",$id)
					->get()
					->result();
				return $result;
			}
			
			
			
			// update page data by id 
			public function saveUpdatePageData($data,$id)
			{
			   $this->db->where("page_id",$id);  
			   $update=$this->db->update("tbl_pages", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for deleting specific page by id
			 public function deletePageById($id)
			{
				   $this->db->where("page_id", $id);  
				   $delete=$this->db->delete("tbl_pages");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			// function for fetching all banners
			 public function fetchBanners()
			{
				$result=$this->db->select('*')
					->from('tbl_banners')
					->get()
					->result();
				return $result;
			}
			
			//function for getting banner data by id 
			public function fetchBannerById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_banners')
					->where("banner_id",$id)
					->get()
					->result();
				return $result;
			}
			
			
			//function for getting banner data by specific id 
			public function fetchBannerByIdAndStatus()
			{
				$result=$this->db->select('*')
					->from('tbl_banners')
					->where("banner_id",6)
					->where("status",1)
					->get()
					->result();
				return $result;
			}
			
			
			
			// insert new banner data into db 
			public function saveNewBanner($data)
			{
				$insert = $this->db->insert('tbl_banners',$data);
				return ($insert == true) ? true : false;
			}
			
			// update banner data by id 
			public function updateBannerById($data,$id)
			{
			   $this->db->where("banner_id",$id);  
			   $update=$this->db->update("tbl_banners", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			
			// function for deleting specific banner by id
			 public function deleteBannerById($id)
			{
				   $this->db->where("banner_id", $id);  
				   $delete=$this->db->delete("tbl_banners");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			
			
			// insert new slider data into db 
			public function saveNewSlider($data)
			{
				$insert = $this->db->insert('tbl_sliders',$data);
				return ($insert == true) ? true : false;
			}
			
			// function for fetching all sliders
			 public function fetchSliders()
			{
				$result=$this->db->select('*')
					->from('tbl_sliders')
					->get()
					->result();
				return $result;
			}
			
		
			// function for fetching all active sliders
			 public function fetchActiveSliders()
			{
				$result=$this->db->select('*')
					->from('tbl_sliders')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			//function for getting slider data by id 
			public function fetchSliderById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_sliders')
					->where("slider_id",$id)
					->get()
					->result();
				return $result;
			}
			
			// update slider data by id 
			public function updateSliderById($data,$id)
			{
			   $this->db->where("slider_id",$id);  
			   $update=$this->db->update("tbl_sliders", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for deleting specific slider by id
			 public function deleteSliderById($id)
			{
				   $this->db->where("slider_id", $id);  
				   $delete=$this->db->delete("tbl_sliders");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			 
			
	}
?>