<?php 
class Pages_model extends CI_Model{

			
	
			// function for fetching all pages
			public function get_all_pages()
			{
				$result=$this->db->select('*')
					->from('tbl_pages')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			
	
}

?>