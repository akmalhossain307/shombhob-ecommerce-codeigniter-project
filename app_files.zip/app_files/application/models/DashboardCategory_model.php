<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class DashboardCategory_model extends CI_Model
	{
			// function for checking existing category
			public function checkCategory($category)
			{
				$result=$this->db->select('*')
					->from('starter_goods_parentcats')
					->where("category_name",$category)
					->get()
					->result();
				return $result;
				
			}
			 
			 // Create new category	
			 public function createCategory($data)
			 {
				 	$insert = $this->db->insert('starter_goods_parentcats',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 // function for fetching all categories
			 public function get_all_category()
			{
				$result=$this->db->select('*')
					->from('starter_goods_parentcats')
					->get()
					->result();
				return $result;
			}
			
			// function for fetching all active categories
			 public function get_all_active_category()
			{
				$result=$this->db->select('*')
					->from('starter_goods_parentcats')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			
			
			// function for fetching all active sub-categories
			 public function get_all_active_subcategory()
			{
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			// Deactivate single category by id
			public function deactivateCategoryById($data,$id)
			{
			   $this->db->where("category_id", $id);  
			   $update=$this->db->update("starter_goods_parentcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// Activate single category by id
			public function activateCategoryById($data,$id)
			{
			   $this->db->where("category_id", $id);  
			   $update=$this->db->update("starter_goods_parentcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// function for fetching specific subCategory by category
			 public function fetch_subCategory($mainCategory)
			{
				
			  $this->db->where('category_id', $mainCategory);
			  $query = $this->db->get('starter_goods_subcats');
			  //$output = '<option value="">Select State</option>';
			  $output = '';
			  foreach($query->result() as $row)
			  {
			   $output .= '<option value="'.$row->subcat_id.'">'.$row->subCategoryName.'</option>';
			  }
			  return $output;
				
			}
			
			// function for fetching specific category by category id
			 public function getCategoryById($id)
			{
				$result=$this->db->select('*')
					->from('starter_goods_parentcats')
					->where("category_id",$id)
					->get()
					->result();
				return $result;
			}
			// update single category by id
			public function updateCategoryById($data,$id)
			{
			   $this->db->where("category_id", $id);  
			   $update=$this->db->update("starter_goods_parentcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}

			// function for deleting specific category by category id
			 public function deleteCategoryById($id)
			{
				   $this->db->where("category_id", $id);  
				   $delete=$this->db->delete("starter_goods_parentcats");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			 // Create new sub-category	
			 public function createSubCategory($data)
			 {
				 	$insert = $this->db->insert('starter_goods_subcats',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 // function for fetching all sub-categories
			 public function get_all_subCategory()
			 {
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->get()
					->result();
				return $result;
			 }
			 
			 
			
			 public function fetchMainCatBySubCat($id)
			{
				
				$query = $this->db->query("SELECT category_name FROM starter_goods_parentcats WHERE category_id='$id'");
				return $query->row_array();
			}
			
			// function for fetching specific sub-category by id
			 public function getSubCategoryById($id)
			{
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->where("subcat_id",$id)
					->get()
					->result();
				return $result;
			}
			// update single sub-category by id
			public function updateSubCategoryById($data,$id)
			{
			   $this->db->where("subcat_id", $id);  
			   $update=$this->db->update("starter_goods_subcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// Deactivate single sub-category by id
			public function deactivateSubCategoryById($data,$id)
			{
			   $this->db->where("subcat_id", $id);  
			   $update=$this->db->update("starter_goods_subcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			// Activate single sub-category by id
			public function activateSubCategoryById($data,$id)
			{
			   $this->db->where("subcat_id", $id);  
			   $update=$this->db->update("starter_goods_subcats", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			
			// function for deleting specific sub-category by id
			 public function deleteSubCategoryById($id)
			 {
				   $this->db->where("subcat_id", $id);  
				   $delete=$this->db->delete("starter_goods_subcats");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			 }
			 
			 
			 
			 
			 // function for checking existing brand
			public function checkBrand($brand)
			{
				$result=$this->db->select('*')
					->from('tbl_productbrand')
					->where("brand_name",$brand)
					->get()
					->result();
				return $result;
				
			}
			 
			 // Create new brand	
			 public function createBrand($data)
			 {
				 	$insert = $this->db->insert('tbl_productbrand',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 // function for fetching all brands
			 public function get_all_brand()
			{
				$result=$this->db->select('*')
					->from('tbl_productbrand')
					->get()
					->result();
				return $result;
			}
			
			// function for fetching all active brands
			 public function get_all_active_brand()
			{
				$result=$this->db->select('*')
					->from('tbl_productbrand')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			// function for fetching specific brand by brand id
			 public function getBrandById($id)
			{
				$result=$this->db->select('*')
					->from('tbl_productbrand')
					->where("brand_id",$id)
					->get()
					->result();
				return $result;
			}
			// update single brand by id
			public function updateBrandById($data,$id)
			{
			   $this->db->where("brand_id", $id);  
			   $update=$this->db->update("tbl_productbrand", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}

			// function for deleting specific brand by brand id
			 public function deleteBrandById($id)
			{
				   $this->db->where("brand_id", $id);  
				   $delete=$this->db->delete("tbl_productbrand");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			 
			 
			
	}
?>