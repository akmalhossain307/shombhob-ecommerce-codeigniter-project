<?php
	class Search_model extends CI_Model
	{
		
			 function fetch_search_data($query)
			 {
			  
			  if($query != '')
			  {
				$this->db->select("*");
				$this->db->from("tbl_product");
				$this->db->like('title',$query);
				//$this->db->or_like('product_price', $query);
			   return $this->db->get();
			  }
			  //$this->db->order_by('CustomerID', 'DESC');
			  
			 }
			
			/*
			function fetch_search_data($query)
			 {
			  
			  if($query != '')
			  {
				  $query=$this->db->query("SELECT * FROM tbl_product WHERE title LIKE '%$query%' ORDER BY product_id ASC LIMIT 20");
				  return $query->result_array();
				
			  }
			  //$this->db->order_by('CustomerID', 'DESC');
			  
			 }
*/


// 
			public function searchByKeyword($keyword)
			{
				/*
				$result=$this->db->select('*')
					->from('tbl_product')
					->where("title",$keyword)
					->where("slug",$keyword)
					->get()
					->result();
				return $result;
				*/
				
				/* Original copy
				$query = $this->db->query("SELECT * FROM starter_shop_products 
								   WHERE title LIKE '%$keyword%' OR shortDescription LIKE '%$keyword%' ORDER BY title ASC LIMIT 50");
		return $query->result();
				
			*/
			    
			    
			    $this->db->select('title,product_id,slug,measuringType,discountPrice,price,product_need_prescription,product_quantity,type,attribute,product_status');
				$this->db->where('product_status',1);
				$this->db->group_by("title");
				$this->db->like('title', $keyword);
				$this->db->or_like('shortDescription', $keyword);
				

				return $this->db->get('starter_shop_products', 100)->result();
			    
			    
			    
			    
			}
			
			
			 // Insert product search keys data	
			 public function saveSearchKeyword($data)
			 {
				 	$insert = $this->db->insert('tbl_productsearchkey',$data);
					return ($insert == true) ? true : false;
			 } 
			


			 
			 function fetch_filter_data($cat)
			 {
			  
			  if($cat != '')
			  {
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where("mainCategory",$cat)
					->get()
					->result();
				return $result;
			  }
			  //$this->db->order_by('CustomerID', 'DESC');
			  
			 }
			 
			 // Insert product request data	
			 public function saveProductRequestData($data)
			 {
				 	$insert = $this->db->insert('tbl_requestedproduct',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 // Insert product request data	
			 public function saveSubscriberData($data)
			 {
				 	$insert = $this->db->insert('tbl_subscribers',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 /*
			 function fetch_data($query)
			 {
			  $this->db->like('title', $query);
			  $query = $this->db->get('tbl_product');
			  if($query->num_rows() > 0)
			  {
			   foreach($query->result_array() as $row)
			   {
				$output[] = array(
				 'name'  => $row["title"],
				 'image'  => $row["productImage"]
				);
			   }
			   echo json_encode($output);
			  }
			 }
			 */
			 
			 
		function fetch_data($query)
		 {
		  
		$query=$this->db->query("SELECT * FROM tbl_product WHERE title LIKE '%$query%'");
		  //$query = $this->db->get('starter_shop_products');
		  if($query->num_rows() > 0)
		  {
		   foreach($query->result_array() as $row)
		   {
			$output[] = array(
			 'product_id'  => $row["product_id"],
			 'product_title'  => $row["title"],
			 'product_slug'  => $row["slug"],
			 'product_metering_type'  => $row["measuringType"],
			 'product_price'  => $row["price"],
			 'image_url'  => $row["productImage"]
			);
		   }
		   echo json_encode($output);
		  }
		 }
		 
		 
		 
		 public function get_autocomplete($search_data)
			{
			    
			    
			    
			    
			/*    
			  
		$this->db->select('title,product_id,slug,measuringType,discountPrice,price,product_need_prescription,product_quantity');
				$this->db->where('product_status',1);
				$this->db->like('title', $search_data);
				$this->db->or_like('shortDescription', $search_data);
				

				return $this->db->get('starter_shop_products', 20)->result();
			    
			
		*/	
			
$this->db->select('title,product_id,slug,measuringType,discountPrice,price,product_need_prescription,product_quantity');
				$this->db->where('product_status',1);
				$this->db->group_by("title");
				$this->db->like('title', $search_data);
				$this->db->or_like('shortDescription', $search_data);
				

				return $this->db->get('starter_shop_products', 100)->result();
			 
		
	
	
		
		/*
			$query = $this->db->query("SELECT * FROM starter_shop_products ORDER BY price ASC LIMIT 300");
				return $query->result_array();
			*/
			
				
			}
			
			public function get_autocomplete1($search_data)
			{
				$this->db->select('title, product_id,slug,measuringType,discountPrice,price,product_need_prescription,product_quantity');
				$this->db->group_by("title");
				$this->db->where('product_status',1);
				$this->db->like('title', $search_data);
				$this->db->or_like('shortDescription', $search_data);
				//$this->db->where('status',"1");

				return $this->db->get('starter_shop_products', 20)->result();
			}
		 
		 
		 
	}
?>