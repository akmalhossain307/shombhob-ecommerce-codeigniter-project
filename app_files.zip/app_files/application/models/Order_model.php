<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends CI_Model{
	
	public function save_order($data)
	{
		$this->db->insert('tbl_customer_orders', $data);
	}
	
	public function insert_mapping($data)
	{
		$this->db->insert('tbl_report_mapping', $data);
	}
	
	public function save_order_details($data)
	{
		$this->db->insert('tbl_order_details', $data);
	}
	
	
	public function update_ordernumber($order_id, $ordernumber)
	{
		$this->db->query("UPDATE tbl_customer_orders SET tbl_customer_orders.order_number='$ordernumber' WHERE tbl_customer_orders.order_id='$order_id'");
	}
	
	public function save_invoice($data)
	{
		$this->db->insert('tbl_order_invoices', $data);
	}
	
	public function save_details_varietions($data)
	{
		$this->db->insert('starter_details_varietions', $data);
	}
	
	public function get_details_vernts($details_id)
	{
		$query = $this->db->query("SELECT
								   starter_details_varietions.details_v_varients,
								   starter_details_varietions.details_v_option
			                       FROM starter_details_varietions 
								   WHERE starter_details_varietions.details_vdetails_id='$details_id'
								 ");
		return $query->result_array();
	}
	
	
	public function get_verient_options_title($verient_id, $option_id, $item_id)
	{
		$query = $this->db->query("SELECT 
								   starter_product_varients.varient_title, 
								   starter_varient_options.option_name, 
								   starter_varient_options.option_price
								   FROM starter_product_varients
								   LEFT JOIN starter_varient_options ON
								   starter_varient_options.option_varientid=starter_product_varients.varient_id
								   WHERE starter_product_varients.varient_id='$verient_id'
								   AND starter_product_varients.varient_product_id='$item_id'
								   AND starter_varient_options.option_id='$option_id'
								 ");
		return $query->row_array();
	}
	
	public function get_single_order($order_number)
	{
		$user_id = $this->session->userdata('active_customer');
		$query = $this->db->query("SELECT starter_users_orders.*,
								   starter_user_addresses.*,
								   starter_order_invoices.invoice_number,
								   starter_shop_users.user_full_name,
								   starter_cities.city_name
								   FROM starter_users_orders
								   LEFT JOIN starter_order_invoices ON
								   starter_order_invoices.invoice_order_id=starter_users_orders.order_id
								   LEFT JOIN starter_shop_users ON
								   starter_shop_users.user_id=starter_users_orders.order_userid
								   LEFT JOIN starter_user_addresses ON
								   starter_user_addresses.address_id=starter_users_orders.order_addressid
								   LEFT JOIN starter_cities ON
								   starter_cities.city_id=starter_user_addresses.address_city
								   WHERE starter_users_orders.order_number='$order_number'
								   AND starter_users_orders.order_userid='$user_id'
								 ");
		return $query->row_array();
	}
	
	public function get_order_items($order_id)
	{
		$query = $this->db->query("SELECT
								   starter_orders_details.*,
								   starter_shop_products.product_title,
								   starter_shop_products.product_slug,
								   starter_shop_products.product_price,
								   starter_shop_products.product_discount_price
								   FROM starter_orders_details
								   LEFT JOIN starter_shop_products ON
								   starter_shop_products.product_id=starter_orders_details.details_item_id
								   WHERE starter_orders_details.details_orderid='$order_id' 
								   ORDER BY starter_orders_details.details_id ASC
								 ");
		return $query->result_array();
	}
	
	public function get_default_photo($product_id)
	{
		$query = $this->db->query("SELECT image_url FROM starter_products_images 
							       WHERE starter_products_images.image_productid='$product_id'
								   ORDER BY starter_products_images.image_id ASC
								   ");
		return $query->row_array();
	}
	
	public function get_customer_email($cus_id)
	{
		$query = $this->db->query("SELECT email FROM tbl_customer WHERE tbl_customer.customer_id='$cus_id'");
		return $query->row_array();
	}
	
	public function get_customer_phone($address_id)
	{
		$query = $this->db->query("SELECT address_phone FROM tbl_customeraddress WHERE tbl_customeraddress.address_id='$address_id'");
		return $query->row_array();
	}
	
	public function check_coupon($coupon_code)
	{
		$query = $this->db->query("SELECT coupon_id FROM starter_coupons WHERE starter_coupons.coupon_code='$coupon_code'");
		return $query->row_array();
	}
	
	public function delete_customer_coupon($coupon_id, $customer_id)
	{
		$this->db->query("DELETE FROM starter_customer_gifts WHERE starter_customer_gifts.gift_coupon_id='$coupon_id' AND starter_customer_gifts.gift_customer_id='$customer_id'");
	}
	
	public function total_count()
	{
		$query = $this->db->query("SELECT order_id FROM tbl_customer_orders");
		return $query->num_rows();
	}
	
}
