<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class Customer_model extends CI_Model
	{
			 public function register_customer($data)
			 {
				 	$insert = $this->db->insert('tbl_customer',$data);
					return ($insert == true) ? true : false;
			 }
			 
			 // function for checking customer mobile already exist or not
			 public function checkCustomerMobile($mobile)
				{
					$result=$this->db->select('*')
						->from('tbl_customer')
						->where("mobile",$mobile)
						->get()
						->result();
					return $result;
				}
				
				// function for checking customer email already exist or not
			 public function checkCustomerEmail($email)
				{
					$result=$this->db->select('*')
						->from('tbl_customer')
						->where("email",$email)
						->get()
						->result();
					return $result;
				}
				
				// function for customer login by customer phone no
				public function customerLoginByPhone($phone,$password)
				{
					$result=$this->db->query("SELECT * FROM tbl_customer WHERE mobile='$phone' AND password='$password'");
					return $result->row_array();
					
				}
				// function for customer login
				public function customerLoginByEmail($email,$password)
				{
					$result=$this->db->query("SELECT * FROM tbl_customer WHERE email='$email' AND password='$password'");
					return $result->row_array();
					
				}
				
				// function for customer login
				public function checkCustomerLogin($username,$password)
				{
					$query = $this->db->query("SELECT * FROM tbl_customer WHERE email='$username' AND password='$password'");
					return $query->row_array();	
				}
				
				// function for checking customer old password...
				public function checkExistPassword($cus_id,$password)
				{
					$query = $this->db->query("SELECT * FROM tbl_customer WHERE customer_id='$cus_id' AND password='$password'");
					return $query->row_array();	
				}
				
				// function for updating customer password
				public function changeOldPassByNewPass($cus_id,$newPassword)
				{
					$query = $this->db->query("UPDATE tbl_customer SET password='$newPassword' WHERE customer_id=$cus_id");
					//return $query->row_array();
					if($query)	
					{
						return true;
					}
					else 
					{
						return false;
					}
				}
				
				// Save prescription data 
				 public function savePrescriptionData($data)
				 {
						$insert = $this->db->insert('tbl_prescriptions',$data);
						return ($insert == true) ? true : false;
				 }
				 
				 // Save prescription data 
				 public function saveCustomerAddressData($deliveryAddressData)
				 {
						$insert = $this->db->insert('tbl_customeraddress',$deliveryAddressData);
						return ($insert == true) ? true : false;
				 }
				 
				 // Fetch customer address by customer id 
				 public function fetchCustomerAddressById($cust_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customeraddress')
						->where("address_customerId",$cust_id)
						->get()
						->result();
					return $result;
				 }

				 // Fetch customer address by customer id 
				 public function fetchCustomerWishListByCusId($cust_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_wishlist')
						->where("customer_id",$cust_id)
						->get()
						->result();
					return $result;
				 } 
				 
				 // Fetch customer order data by customer id 
				 public function fetchCustomerOrderDataById($cus_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customer_orders')
						->where("order_customerid",$cus_id)
						->get()
						->result();
					return $result;
				 }
				 
				 
				 //Fetch customer order details by order id 
				 public function fetchCustomerOrderDetailsById($orderID)
				 {
					 $result=$this->db->select('*')
						->from('tbl_order_details')
						->where("details_orderid",$orderID)
						->get()
						->result();
					return $result;
				 }  
				 
				 //Fetch customer order details by order id 
				 public function fetchCustomerOrderSummaryById($orderID)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customer_orders')
						->where("order_id",$orderID)
						->get()
						->result();
					return $result;
				 } 
				 
				 
				 // Update order payment status data by order id 
				 public function updatePaymentStatusData($order_id,$data)
				 {
					  $this->db->where("order_id", $order_id);  
					   $update=$this->db->update("tbl_customer_orders", $data);  
					   if($update)
					   {
						   return true;
					   }
					   else {
						   return false;
						}
				
				 }
				 
				 
				 
				 
				 //Fetch customer order details by order id 
				 public function orderProductDetailsById($proID)
				 {
					  $result=$this->db->select('*')
						->from('starter_shop_products')
						->where("product_id",$proID)
						->get()
						->result();
					return $result;
					
				 } 
				 
				 
				 
				 
				 // Update customer address data  
				 public function updateCustomerAddressData($cus_id,$deliveryAddressData)
				 {
					  $this->db->where("address_customerId", $cus_id);  
					   $update=$this->db->update("tbl_customeraddress", $deliveryAddressData);  
					   if($update)
					   {
						   return true;
					   }
					   else {
						   return false;
						}
				
				 }
				 
				 // Update customer account pass by phone no   
				 public function changePasswordWithPhone($str,$pass)
				 {
					 
					 $query = $this->db->query(" UPDATE tbl_customer SET password='$pass' WHERE mobile='$str'");
					  
					   if($query)
					   {
						   return true;
					   }
					   else {
						   return false;
						}
				
				 }
				 
				 // Update customer account pass by email   
				 public function changePasswordWithEmail($str,$pass)
				 {
					 
					 $query = $this->db->query(" UPDATE tbl_customer SET password='$pass' WHERE email='$str'");
					  
					   if($query)
					   {
						   return true;
					   }
					   else {
						   return false;
						}
				
				 }
				 
				 // Fetch customer data by customer id 
				 public function fetchCustomerById($cus_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customer')
						->where("customer_id",$cus_id)
						->get()
						->result();
					return $result;
				 } 
				 
				 // Fetch customer address data by customer id 
				 public function fetchCustomerAddressByCusId($cus_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customeraddress')
						->where("address_customerId",$cus_id)
						->get()
						->result();
					return $result;
				 } 
				 
				 // Fetch customer address data by customer id 
				 public function fetchCustomerAddressByAddressId($address_id)
				 {
					 $result=$this->db->select('*')
						->from('tbl_customeraddress')
						->where("address_id",$address_id)
						->get()
						->result();
					return $result;
				 }
	}
?>