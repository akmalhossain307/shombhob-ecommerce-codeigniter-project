<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Coupon_model extends CI_Model{
	
	public function check_coupon_code($coupon_code)
	{
		$query = $this->db->query("SELECT coupon_id, coupon_type, coupon_code, coupon_discount_type, coupon_discount_price, coupon_discount_amount, coupon_expire_date  FROM starter_coupons WHERE starter_coupons.coupon_code='$coupon_code'");
		return $query->row_array();
	}
	
	public function check_coupon_owner($coupon_id, $customer_id)
	{
		$query = $this->db->query("SELECT gift_id FROM starter_customer_gifts WHERE starter_customer_gifts.gift_coupon_id='$coupon_id' AND starter_customer_gifts.gift_customer_id='$customer_id'");
		return $query->row_array();
	}
	
	public function check_coupon_hasused($coupon_code, $customer_id)
	{
		$query = $this->db->query("SELECT cpnused_coupon_code FROM starter_coupon_used WHERE starter_coupon_used.cpnused_coupon_code='$coupon_code' AND starter_coupon_used.cpnused_customer_id='$customer_id'");
		return $query->row_array();
	}
	
	public function save_used($data)
	{
		$this->db->insert('starter_coupon_used', $data);
	}
	
	
	public function customer_has_applied_coupon($coupon_code)
	{
		$query = $this->db->query("SELECT * FROM starter_coupons WHERE starter_coupons.coupon_code='$coupon_code'");
		return $query->row_array();
	}
	
	
}
