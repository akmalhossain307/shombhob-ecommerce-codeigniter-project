<?php 
class Product_model extends CI_Model{
    
    
    
            // insert product to view product list 
			public function saveProductToViewList($proData)
			{
				$insert = $this->db->insert('tbl_view_list',$proData);
				return ($insert == true) ? true : false;
			}

			public function get_all_product($id = ''){
				$this->db->select('*');
				$this->db->from('product');
				//$this->db->where('status', '1');
				if($id){
					$this->db->where('product_id', $id);
					$query = $this->db->get();
					$result = $query->row_array();
				}else{
					//$this->db->order_by('proname', 'asc');
					$query = $this->db->get();
					$result = $query->result_array();
				}
				
				// Return fetched data
				return !empty($result)?$result:false;
			}
			
			
			
			public function get_default_photo($product_id)
			{
				$query = $this->db->query("SELECT image_url FROM starter_products_images 
										   WHERE starter_products_images.image_productid='$product_id'
										   ORDER BY starter_products_images.image_id ASC
										   ");
				return $query->row_array();
			}
			
			
			// insert product to wishlist 
			public function saveProductWishList($data)
			{
				$insert = $this->db->insert('tbl_wishlist',$data);
				return ($insert == true) ? true : false;
			}
			
			
			
			
			// function for deleting specific product by product id
			 public function deleteProductFromWishList($proId)
			{
				   $this->db->where("product_id", $proId);  
				   $delete=$this->db->delete("tbl_wishlist");
				   if($delete)
				   {
					   return true;
				   }
				   else 
				   {
					   return false;
				   }
			}
			
			// Fetch popular product 
			public function fetchPopularProduct1()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('product_status',1)
					->order_by('product_id','DESC')
					//->limit(50,8)
					->limit(12)
					->get()
					->result();
				return $result;
			}
			
			// Fetch popular product 
			public function fetchPopularProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('product_status',1)
					->order_by('product_id','ASC')
					//->limit(20,8)
					->limit(12)
					->get()
					->result();
				return $result;
			}
			
			// Fetch similar product 
			public function fetchSimilarProduct($productSubCatId)
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('subcat_id',$productSubCatId)
					->where('product_status',1)
					->order_by('product_id','ASC')
					->limit(12)
					->get()
					->result();
				return $result;
			}
			public function fetchSimilarProduct1($productSubCatId)
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('subcat_id',$productSubCatId)
					->where('product_status',1)
					->order_by('product_id','ASC')
					->limit(12,12)
					->get()
					->result();
				return $result;
			}
			
			// Fetch OTC product 
			public function fetchOTCProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('type','otc')
					->where('product_status',1)
					->limit(6)
					->get()
					->result();
				return $result;
			}
			
			// Fetch prescribed product 
			public function fetchPrescribedProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('type','prescribed')
					->where('product_status',1)
					->limit(6)
					->get()
					->result();
				return $result;
			}
			
			// Fetch Essential product 
			public function fetchEssentialProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('type','essential')
					->where('product_status',1)
					->limit(6)
					->get()
					->result();
				return $result;
			}
			
			// Fetch Essential product 
			public function fetchFeaturedProduct()
			{
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where('type','featured')
					->where('product_status',1)
					->limit(6)
					->get()
					->result();
				return $result;
			}
			
			
			// Filter products by price- low to high  
			public function filterByProductPriceLowToHigh()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY price ASC LIMIT 5000");
				return $query->result_array();
			}
			
			// Filter products by price- high to low  
			public function filterByProductPriceHighToLow()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY price DESC LIMIT 5000");
				return $query->result_array();
			}
			
			// Filter products by newest  
			public function filterByProductNewest()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY product_id DESC LIMIT 5000");
				return $query->result_array();
			}
			
			// Filter products by newest  
			public function filterByProductOldest()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY product_id ASC LIMIT 5000");
				return $query->result_array();
			}
			
			// Filter products by A-Z  
			public function filterByProductAtoZ()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY title ASC LIMIT 5000");
				return $query->result_array();
			}
			
			// Filter products by Z-A  
			public function filterByProductZtoA()
			{
				$query = $this->db->query("SELECT * FROM starter_shop_products WHERE product_status=1 ORDER BY title DESC LIMIT 5000");
				return $query->result_array();
			}
	
			
			
			// function for fetching all offers
			public function get_offer_categories()
			{
				/*
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->get()
					->result();
				return $result;
				*/
				
				$query=$this->db->query("SELECT DISTINCT(mainCategory) FROM tbl_productoffer");
				$result=$query->result_array();
				return $result;
				
			}
			
			// Function for fetching productCategories...
			public function productMainCategory()
			{
				$result=$this->db->select('*')
					->from('starter_goods_parentcats')
					->where("status",1)
					->get()
					->result();
				return $result;
				
			}
			
			// Function for fetching product sub-Categories by Healthcare category
			public function productHealthcareSubCategories()
			{
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->where("category_id",66)
					->where("status",1)
					->get()
					->result();
				return $result;
				
			}
			
			// Function for fetching productSubCategories by category_id...
			public function productSubCategory($category_id)
			{
				
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->where("category_id",$category_id)
					->where("status",1)
					->get()
					->result();
				return $result;
				
			}
			
			
			function fetch_filter_data($cat)
			 {
			  
			  if($cat != '')
			  {
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where("mainCategory",$cat)
					->get()
					->result();
				return $result;
			  }
			  //$this->db->order_by('CustomerID', 'DESC');
			  
			 }
			 
			 
			 // Fetch product sub-category by category_id
			 function getProductSubCategoryByCategory($cat_id)
			 {
			  
			  if($cat_id != '')
			  {
				$result=$this->db->select('*')
					->from('starter_goods_subcats')
					->where("category_id",$cat_id)
					->where("status",1)
					->get()
					->result();
				return $result;
			  }
			 }
			 
			 public function countProductsBySubCategory($subCategory)
			 {
				 $query = $this->db->query("SELECT * FROM starter_shop_products WHERE subcat_id='$subCategory'");
				 return $query->num_rows();
				 
			 }
			 
			 
			 
			 // function for fetching all active offers
			public function get_all_offers()
			{
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where('status',1)
					->get()
					->result();
				return $result;
			}
			
			
			 public function countTotalOffers()
			 {
				 $query = $this->db->query("SELECT * FROM tbl_productoffer WHERE status=1");
				 return $query->num_rows();
				 
			 } 
			 
			 public function countOfferByCategory($Category)
			 {
				 $query = $this->db->query("SELECT * FROM tbl_productoffer WHERE mainCategory='$Category' AND status=1");
				 return $query->num_rows();
				 
			 }
			 
			 // Fetch offers by category
			 function getOffersByCategory($cat)
			 {
			  
			  if($cat!= '')
			  {
				$result=$this->db->select('*')
					->from('tbl_productoffer')
					->where("mainCategory",$cat)
					->where("status",1)
					->get()
					->result();
				return $result;
			  }
			 }
			 
			 
			 // Fetch product by sub-category
			 function getProductBySubCategory($slug)
			 {
			  
			  if($slug != '')
			  {
			      /*
				$result=$this->db->select('*')
					->from('starter_shop_products')
					->where("subcat_id",$slug)
					->where("product_status",1)
					->limit(99)
					->get()
					->result();
				return $result;
				*/
				
				$this->db->select ( '*' ); 
                $this->db->from ( 'starter_shop_products' );
                $this->db->join ( 'starter_goods_subcats', 'starter_goods_subcats.subcat_id = starter_shop_products.subcat_id' , 'left' );
                $this->db->where ( 'starter_goods_subcats.subCategorySlug', $slug);
                $this->db->where ( 'product_status', 1);
                $this->db->limit(99);
                $query = $this->db->get ();
                return $query->result ();
				
			  }
			  
			   
			  
			  
			  
			  
			 }
			 
			 
			public function getSingleProductDetailsById($proId)
			{
				$result=$this->db->select('*')
								->from('starter_shop_products')
								->where('product_id',$proId)
								->get()
								->result();
				return $result;
			}
			
			public function getSingleProductDetailsBySlug($pro_slug)
			{
				$result=$this->db->select('*')
								->from('starter_shop_products')
								->where('slug',$pro_slug)
								->limit(1)
								->get()
								->result();
				return $result;
			}
			
			//for customer activity log
			public function getSingleProductDetailsBySlug1($pro_slug)
			{
				$result=$this->db->select('*')
								->from('starter_shop_products')
								->where('slug',$pro_slug)
								->limit(1)
								->get()
								->result();
				return $result;
			}
			
			
			public function getSingleProductInfo($productId)
			{
				$result=$this->db->select('*')
								->from('starter_shop_products')
								->where('product_id',$productId)
								->get()
								->result();
				return $result;
			}
			
			public function updateSingleProductQtyById($data,$pID)
			{
			   $this->db->where("product_id", $pID);  
			   $update=$this->db->update("starter_shop_products", $data);  
			   if($update)
			   {
				   return true;
			   }
			   else {
				   return false;
				}
			}
			
			
			public function getSingleOfferProductDetailsById($offerId)
			{
				$result=$this->db->select('*')
								->from('tbl_productoffer')
								->where('offer_id',$offerId)
								->get()
								->result();
				return $result;
			}
			
			
			public function fetchSearchKeywordList()
			 {
				 $query = $this->db->query("SELECT * FROM tbl_productsearchkey ORDER BY search_date DESC");
				return $query->result_array();
			 }
	
	// function for inserting product re-stock request
		public function saveproductRestockRequest($data)
    			{
    				$insert = $this->db->insert('tbl_product_restock_request',$data);
    				return ($insert == true) ? true : false;
    			}
	
	
}

?>