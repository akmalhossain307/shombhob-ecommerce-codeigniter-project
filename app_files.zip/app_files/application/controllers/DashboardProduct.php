<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardProduct extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboardProduct_model');
		$this->load->model('dashboardCategory_model');
		$this->load->model('product_model');
		//$this->load->library('product_model');
		//$this->load->library('cart');
		
		$login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('yesAdmin'));
		}
		//$this->output->cache(720);
	}
	

	public function index()
	{
		
		$data=array();
		//$data['categories']=$this->dashboardCategory_model->get_all_category();
		$data['products']=$this->dashboardProduct_model->get_all_products();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/productList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	public function keywordList()
	{
		
		$data=array();
		$data['searchInfo']=$this->product_model->fetchSearchKeywordList();
		$data['title']="Product || Keyword List";
		$this->load->view('back-end/reports/keywordList',$data);
		
	}
	
	public function productViewList()
	{
		
		$data=array();
		$data['viewedProductsInfo']=$this->dashboardProduct_model->fetchviewedProducts();
		$data['title']="Product || Customer viewed List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/viewedProductList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	public function sendOfferTemplate()
	{
		
		$data=array();
		$data['title']="Product || Send Offer to Customer";
	
		$this->load->view('back-end/products/createCustomerOffer',$data);
		
	}
	
	public function sendOfferToCustomer()
	{
	    $title=$this->input->post('offer_title');
	    $body=$this->input->post('offer_body');
	    
	    
	    
	    
			$config = Array(
				'protocol' => 'smtp',
				'smtp_host' => 'ssl://smtp.googlemail.com',
				'smtp_port' => 465,
				'smtp_user' => 'info@yesbd.com',
				'smtp_pass' => '123#123#',
				'mailtype'  => 'html', 
				'charset'   => 'iso-8859-1',
				'wordwrap' => TRUE
			);

			
			$this->email->set_mailtype("html");
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->from('info@yesbd.com', 'Yesbd.com');
			$this->email->to(array('akmal@yesbd.com','shuchi@yesbd.com')); 
			
			//$this->email->bcc(array('akmal110130@gmail.com','akmal@yesbd.com','shuchi@yesbd.com','akmalhossain307@gmail.com'));
			
			//$this->email->bcc(array('azra.salim@jaysonbd.com','anistarafder@jaysonbd.com'));
			//$this->email->bcc(array('order@yesbd.com'));
			
			$this->email->bcc('akmalhossain307@gmail.com');
			
			//$this->email->cc('saikatzamanit@gmail.com');
			$this->email->subject($title);
			//$this->email->set_header('MIME-Version', '1.0; charset=utf-8');
			//$this->email->set_header('Content-type', 'text/html');
			$this->email->message($body); 
			$sent=$this->email->send();
		
	
			if($sent)
			{
			
			$this->session->set_flashdata('success','Offer sent successfully!');
			redirect(base_url('admin/send-offer'));
		}
		else {
		
			$this->session->set_flashdata('error','Offer not sent. Something went wrong!');
			redirect(base_url('admin/send-offer'));
		}
				
			
		}
	
	
	
	
	
	
	
	
		public function productRestockRequstList()
	{
		
		$data=array();
		$data['restockRequestedProductInfo']=$this->dashboardProduct_model->fetchRestockRequestedProducts();
		$data['title']="Product || Product re-stock Request List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/restockRequestList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	
	//view product by id
	public function viewProduct($id)
	{
		$data['product']=$this->dashboardProduct_model->getProductById($id);
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/viewProduct',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	public function editProduct($id)
	{
		$data['product']=$this->dashboardProduct_model->getProductById($id);
		$data['categories']=$this->dashboardCategory_model->get_all_active_category();
		$data['subCategories']=$this->dashboardCategory_model->get_all_active_subcategory();
		$data['brands']=$this->dashboardCategory_model->get_all_brand();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/editProduct',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//function for fetching sub-category
	
	public function fetch_subCategory()
	{
		if($this->input->post('mainCategory'))
		  {
		   echo $this->dashboardCategory_model->fetch_subCategory($this->input->post('mainCategory'));
		  }
	}
	
	// Create new product
	public function createProduct()
	{
		$data=array();
		$data['categories']=$this->dashboardCategory_model->get_all_active_category();
		$data['brands']=$this->dashboardCategory_model->get_all_active_brand();
		$data['title']="Yesbd.com Ltd. || Create Product";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/createProduct',$data);
		$this->load->view('back-end/templates/footer');
		
	}
	
	// function for inserting new product to db 
	public function saveProduct()
	{
		//$slug 			= url_title($this->input->post('category_name'), 'dash', true);
		$slug 					= url_title($this->input->post('title'), 'dash', true);
		//$productImage 		= $this->uploadProductImage();
		$data=array(
		'title'					=>$this->input->post('title'),
		'slug'					=>$slug,
		'shortDescription'		=>$this->input->post('shortDescription'),
		'product_parentcat_id' 	=>$this->input->post('mainCategory'),
		'subcat_id'				=>$this->input->post('subCategory'),
		'product_brand_id'		=>$this->input->post('brand'),
		'attribute'				=>$this->input->post('attribute'),
		'type'					=>$this->input->post('type'),
		'price'					=>$this->input->post('price'),
		'discountPrice'			=>$this->input->post('discountPrice'),
		'product_quantity'		=>$this->input->post('stockQty'),
		'product_minorder_qty'	=>$this->input->post('minOrderQty'),
		'measuringType'			=>$this->input->post('measuringType'),
		'product_status'		=>$this->input->post('status'),
		'productDescription'	=>$this->input->post('productDescription'),
		'additionalInfo'		=>$this->input->post('additionalInfo'),
		'product_meta_keywords'	=>$this->input->post('metaKeywords'),
		'product_meta_descriptions'	=>$this->input->post('metaDescription'),
		);
		$ins_id=$this->dashboardProduct_model->insertNewProduct($data);
		$product_id = $this->db->insert_id($ins_id);
		$photo['image_url']=$this->uploadProductImage();
		$photo['image_productid'] = $product_id;
			if(!empty($photo['image_url']))
			{
				$this->dashboardProduct_model->save_images($photo);
			}
		
		if($ins_id == true) {
			
			$this->session->set_flashdata('success','Product created successfully!');
			redirect(base_url('admin/product/create'));
		}
		else {
		
			$this->session->set_flashdata('error','Product not Added!');
			redirect(base_url('admin/product/create'));
		}
		
	}
	
	// function for productImage upload
	public function uploadProductImage()
    {
		
        $config['upload_path'] = 'uploads/products/';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('productImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['productImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	// function for saving update product 
	public function updateProduct($id)
	{
		if(!empty($_FILES['productImage']['name'])){
		$slug 					= url_title($this->input->post('title'), 'dash', true);
		//$productImage 		= $this->uploadProductImage();
		$data=array(
		'title'					=>$this->input->post('title'),
		'slug'					=>$slug,
		'shortDescription'		=>$this->input->post('shortDescription'),
		'product_parentcat_id' 	=>$this->input->post('mainCategory'),
		'subcat_id'				=>$this->input->post('subCategory'),
		'product_brand_id'		=>$this->input->post('brand'),
		'attribute'				=>$this->input->post('attribute'),
		'type'					=>$this->input->post('type'),
		'price'					=>$this->input->post('price'),
		'discountPrice'			=>$this->input->post('discountPrice'),
		'product_quantity'		=>$this->input->post('stockQty'),
		'product_minorder_qty'	=>$this->input->post('minOrderQty'),
		'measuringType'			=>$this->input->post('measuringType'),
		'product_status'		=>$this->input->post('status'),
		'productDescription'	=>$this->input->post('productDescription'),
		'additionalInfo'		=>$this->input->post('additionalInfo'),
		'product_meta_keywords'	=>$this->input->post('metaKeywords'),
		'product_meta_descriptions'	=>$this->input->post('metaDescription'),
		);
		
		$product_id = $id;
		$photo['image_url']=$this->uploadProductImage();
		//$photo['image_productid'] = $product_id;
		$image_productid = $product_id;
		if(!empty($photo['image_url']))
		{
			$this->dashboardProduct_model->update_product_image($photo,$image_productid);
		}
		
		
			$update=$this->dashboardProduct_model->updateProductById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Product updated successfully!');
				redirect(base_url('admin/productList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Product not updated!');
				redirect(base_url('admin/productList'));
        	}
		}
		else
		{
			//for empty image...
			$slug 					= url_title($this->input->post('title'), 'dash', true);
	
			$data=array(
			'title'					=>$this->input->post('title'),
			'slug'					=>$slug,
			'shortDescription'		=>$this->input->post('shortDescription'),
			'product_parentcat_id' 	=>$this->input->post('mainCategory'),
			'subcat_id'				=>$this->input->post('subCategory'),
			'product_brand_id'		=>$this->input->post('brand'),
			'attribute'				=>$this->input->post('attribute'),
			'type'					=>$this->input->post('type'),
			'price'					=>$this->input->post('price'),
			'discountPrice'			=>$this->input->post('discountPrice'),
			'product_quantity'		=>$this->input->post('stockQty'),
			'product_minorder_qty'	=>$this->input->post('minOrderQty'),
			'measuringType'			=>$this->input->post('measuringType'),
			'product_status'		=>$this->input->post('status'),
			'productDescription'	=>$this->input->post('productDescription'),
			'additionalInfo'		=>$this->input->post('additionalInfo'),
			'product_meta_keywords'	=>$this->input->post('metaKeywords'),
			'product_meta_descriptions'	=>$this->input->post('metaDescription'),
			);
			$update=$this->dashboardProduct_model->updateProductById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Product updated successfully!');
				redirect(base_url('admin/productList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Product not updated!');
				redirect(base_url('admin/productList'));
        	}
			
		  
		}
	}
	
	
	
	public function unpublishProduct($id)
	{
		$data = array(
			'product_status' => 0,
			);
		$changed=$this->dashboardProduct_model->unpublishProductById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/productList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/productList'));
        	}
	}
	
	public function publishProduct($id)
	{
		$data = array(
			'product_status' => 1,
			);
		$changed=$this->dashboardProduct_model->publishProductById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/productList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/productList'));
        	}
	}
	
	
	//Function for deleting product by id
	public function deleteProduct($id)
	{
		$delete=$this->dashboardProduct_model->deleteProductById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Product Succesfully deleted!');
					redirect(base_url('admin/productList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Product not deleted');
					redirect(base_url('admin/productList'));
				}
		
	}
	
	// Display requested product list 
	public function requestedProduct()
	{
		$data=array();
		$data['requestedProducts']=$this->dashboardProduct_model->getRequestedProduct();
		$data['title']="Yesbd.com Ltd. || Requested Product List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/requestedProductList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//Function for deleting requested product by id
	public function deleteRequestedProduct($id)
	{
		$delete=$this->dashboardProduct_model->deleteRequestedProductById($id);
		if($delete)
		{
			$this->session->set_flashdata('success','Requested product Succesfully deleted!');
			redirect(base_url('admin/product/requestedProduct'));
		}
		else 
		{	
			$this->session->set_flashdata('error','Requested product not deleted');
			redirect(base_url('admin/product/requestedProduct'));
		}	
	}
	
	// Display stock out product list 
	public function stockOutProduct()
	{
		$data=array();
		$data['stockOutProducts']=$this->dashboardProduct_model->getStockOutProduct();
		$data['title']="Yesbd.com Ltd. || Stock out Product List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/stockOutProductList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	
	// function for listing product offers
	public function offerList()
	{
		$data=array();
		$data['productOffer']=$this->dashboardProduct_model->getOfferProduct();
		$data['title']="Yesbd.com Ltd. || Product offer List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/offerList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	
	
	
	
	// Create new product
	public function createProductOffer()
	{
		$data=array();
		$data['categories']	=$this->dashboardCategory_model->get_all_category();
		$data['brands']		=$this->dashboardCategory_model->get_all_brand();
		$data['title']		="Yesbd.com Ltd. || Create Product Offer";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/createProductOffer',$data);
		$this->load->view('back-end/templates/footer');
		
	}
	
	
	
	
	
	
	// function for inserting new product offer to db 
	public function saveProductOffer()
	{
		$productImage 		= $this->uploadOfferProductImage();
		$data=array(
		'title'				=>$this->input->post('title'),
		'shortDescription'	=>$this->input->post('shortDescription'),
		'mainCategory'		=>$this->input->post('mainCategory'),
		'subCategory'		=>$this->input->post('subCategory'),
		'brand'				=>$this->input->post('brand'),
		'attribute'			=>$this->input->post('attribute'),
		'productImage'		=>$productImage,
		'price'				=>$this->input->post('price'),
		'discountPrice'		=>$this->input->post('discountPrice'),
		'stockQty'			=>$this->input->post('stockQty'),
		'minOrderQty'		=>$this->input->post('minOrderQty'),
		'measuringType'		=>$this->input->post('measuringType'),
		'status'			=>$this->input->post('status'),
		'productDescription'=>$this->input->post('productDescription'),
		'additionalInfo'	=>$this->input->post('additionalInfo'),
		'metaKeywords'		=>$this->input->post('metaKeywords'),
		'metaDescription'	=>$this->input->post('metaDescription'),
		);
		$ins=$this->dashboardProduct_model->insertNewProductOffer($data);
		
		if($ins == true) {
			
			$this->session->set_flashdata('success','Product offer created successfully!');
			redirect(base_url('admin/product/offerList'));
		}
		else {
		
			$this->session->set_flashdata('error','Product offer not Created!');
			redirect(base_url('admin/product/offerList'));
		}
		
	}
	
	
	
	
	// function for offer's product image upload
	public function uploadOfferProductImage()
    {
		
        $config['upload_path'] = 'assets/uploads/productOffers';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('productImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['productImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	//view product offer by id
	public function viewProductOffer($id)
	{
		$data['productOffer']=$this->dashboardProduct_model->getProductOfferById($id);
		$data['title']="Admin || View single Offer";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/viewProductOffer',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	public function editProductOffer($id)
	{
		
		$data['product']=$this->dashboardProduct_model->getProductOfferById($id);
		$data['categories']=$this->dashboardCategory_model->get_all_category();
		$data['brands']=$this->dashboardCategory_model->get_all_brand();
		$data['title']="Yesbd.com Ltd. Admin panel || Update product offer";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/editProductOffer',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	// function for saving update product 
	public function updateProductOffer($id)
	{
		if(!empty($_FILES['productImage']['name'])){
	
		$productImage 		= $this->uploadOfferProductImage();
			$data=array(
				'title'				=>$this->input->post('title'),
				'shortDescription'	=>$this->input->post('shortDescription'),
				'mainCategory'		=>$this->input->post('mainCategory'),
				'subCategory'		=>$this->input->post('subCategory'),
				'brand'				=>$this->input->post('brand'),
				'attribute'			=>$this->input->post('attribute'),
				'productImage'		=>$productImage,
				'price'				=>$this->input->post('price'),
				'discountPrice'		=>$this->input->post('discountPrice'),
				'stockQty'			=>$this->input->post('stockQty'),
				'minOrderQty'		=>$this->input->post('minOrderQty'),
				'measuringType'		=>$this->input->post('measuringType'),
				'status'			=>$this->input->post('status'),
				'productDescription'=>$this->input->post('productDescription'),
				'additionalInfo'	=>$this->input->post('additionalInfo'),
				'metaKeywords'		=>$this->input->post('metaKeywords'),
				'metaDescription'	=>$this->input->post('metaDescription'),
				);
			$update=$this->dashboardProduct_model->updateProductOfferById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Product offer updated successfully!');
				redirect(base_url('admin/product/offerList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Product offer not updated!');
				redirect(base_url('admin/product/offerList'));
        	}
		}
		else
		{
			// for empty img
			$data=array(
				'title'				=>$this->input->post('title'),
				'shortDescription'	=>$this->input->post('shortDescription'),
				'mainCategory'		=>$this->input->post('mainCategory'),
				'subCategory'		=>$this->input->post('subCategory'),
				'brand'				=>$this->input->post('brand'),
				'attribute'			=>$this->input->post('attribute'),
				'price'				=>$this->input->post('price'),
				'discountPrice'		=>$this->input->post('discountPrice'),
				'stockQty'			=>$this->input->post('stockQty'),
				'minOrderQty'		=>$this->input->post('minOrderQty'),
				'measuringType'		=>$this->input->post('measuringType'),
				'status'			=>$this->input->post('status'),
				'productDescription'=>$this->input->post('productDescription'),
				'additionalInfo'	=>$this->input->post('additionalInfo'),
				'metaKeywords'		=>$this->input->post('metaKeywords'),
				'metaDescription'	=>$this->input->post('metaDescription'),
				);
			$update=$this->dashboardProduct_model->updateProductOfferById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Product offer updated successfully!');
				redirect(base_url('admin/product/offerList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Product offer not updated!');
				redirect(base_url('admin/product/offerList'));
        	}
			
		  
		}
	}
	
	//Function for deleting product by id
	public function deleteProductOffer($id)
	{
			$delete=$this->dashboardProduct_model->deleteProductOfferById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Product offer Succesfully deleted!');
					redirect(base_url('admin/product/offerList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Product offer not deleted');
					redirect(base_url('admin/product/offerList'));
				}
		
	}
	
	
	// function for listing coupon offers
	public function couponList()
	{
		$data=array();
		$data['coupons']=$this->dashboardProduct_model->getCouponOffers();
		$data['title']="Yesbd.com Ltd. || Product offer List";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/couponList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Create new coupon 
	public function createCouponOffer()
	{
		$data=array();
		//$data['categories']	=$this->dashboardCategory_model->get_all_category();
		//$data['brands']		=$this->dashboardCategory_model->get_all_brand();
		$data['title']		="Yesbd.com Ltd. || Create Product Offer";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/products/createCoupon',$data);
		$this->load->view('back-end/templates/footer');
		
	}
	
	// function for inserting new product offer to db 
	public function saveCoupon()
	{
		
		$data=array(
		'coupon_title'=>$this->input->post('coupon_title'),
		'coupon_type'=>$this->input->post('coupon_type'),
		'coupon_code'=>$this->input->post('coupon_code'),
		'coupon_discount_type'=>$this->input->post('coupon_discount_type'),
		'coupon_discount_price'=>$this->input->post('coupon_discount_price'),
		'coupon_discount_amount'=>$this->input->post('coupon_discount_amount'),
		'coupon_expire_date'=>$this->input->post('coupon_expire_date'),
		'coupon_status'=>$this->input->post('coupon_status'),
		);
		$ins_coupon=$this->dashboardProduct_model->insertNewCoupon($data);
		
		if($ins_coupon == true) {
			
			$this->session->set_flashdata('success','Coupon created successfully!');
			redirect(base_url('admin/product/couponList'));
		}
		else {
		
			$this->session->set_flashdata('error','Coupon not Created!');
			redirect(base_url('admin/product/couponList'));
		}
		
	}
	
	
	public function deactivateCoupon($id)
	{
	
		
		$data = array(
			'coupon_status' => 0,
			);
		$changed=$this->dashboardProduct_model->deactivateCouponById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/product/couponList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/product/couponList'));
        	}
	}
	
	public function activateCoupon($id)
	{
		$data = array(
			'coupon_status' => 1,
			);
		$changed=$this->dashboardProduct_model->activateCouponById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/product/couponList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/product/couponList'));
        	}
	}
	
	
	
	
	
	//Function for deleting coupon by coupon id
	public function deleteCoupon($coupon_id)
	{
		
		$delete=$this->dashboardProduct_model->deleteCouponById($coupon_id);
				if($delete)
				{
					$this->session->set_flashdata('success','Coupon Succesfully deleted!');
					redirect(base_url('admin/product/couponList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Coupon not deleted');
					redirect(base_url('admin/product/couponList'));
				}
		
	}
	
	
	
}
