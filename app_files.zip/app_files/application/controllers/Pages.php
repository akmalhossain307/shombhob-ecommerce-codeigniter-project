<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('DashboardSettings_model');
		$this->load->library('cart');
		// Load facebook oauth library 
        $this->load->library('facebook'); 
        
         //$this->output->cache(720);
         
        // Load user model 
        $this->load->model('user'); 
		
	}
	

	public function index()
	{
	   
	    //$this->output->cache(720);
		$data=array();
		$data['cartItems'] = $this->cart->contents();
		$data['products']=$this->product_model->get_all_product();
		//$data['website_info']=$this->DashboardSettings_model->fetchGeneralSettings();
		$data['slider_info']=$this->DashboardSettings_model->fetchActiveSliders();
		$data['slider_info']=$this->DashboardSettings_model->fetchActiveSliders();
		$data['title']="Yesbd.com Ltd";
		
		
		
		
		$userData = array(); 
         
        // Authenticate user with facebook 
        if($this->facebook->is_authenticated()){ 
            // Get user info from facebook 
            $fbUser = $this->facebook->request('get', '/me?fields=id,first_name,last_name,email,link,gender,picture'); 
 
            // Preparing data for database insertion 
            $userData['oauth_provider'] = 'facebook'; 
            $userData['oauth_uid']    = !empty($fbUser['id'])?$fbUser['id']:'';; 
            $userData['first_name']    = !empty($fbUser['first_name'])?$fbUser['first_name']:''; 
            $userData['last_name']    = !empty($fbUser['last_name'])?$fbUser['last_name']:''; 
			$userData['name']		  =$userData['first_name']." ".$userData['last_name'];
            $userData['email']        = !empty($fbUser['email'])?$fbUser['email']:''; 
            $userData['gender']        = !empty($fbUser['gender'])?$fbUser['gender']:''; 
            $userData['picture']    = !empty($fbUser['picture']['data']['url'])?$fbUser['picture']['data']['url']:''; 
            $userData['link']        = !empty($fbUser['link'])?$fbUser['link']:'https://www.facebook.com/'; 
			
			
             
            // Insert or update user data to the database 
            $userID = $this->user->checkUser($userData); 
             
            // Check user data insert or update status 
            if(!empty($userID)){ 
			
                //$userData['custmrLogin'] = true; 
                //$userData['active_customer']=$userID;
                $data['userData'] = $userData; 
                 
                // Store the user profile info into session 
                $this->session->set_userdata('custmrLogin', true); 
				$this->session->set_userdata('active_customer', $userID); 
                $this->session->set_userdata('userData', $userData); 
            }
			else{ 
               $data['userData'] = array(); 
            } 
             
            // Facebook logout URL 
            $data['logoutURL'] = $this->facebook->logout_url(); 
        }else{ 
            // Facebook authentication url 
            $data['authURL'] =  $this->facebook->login_url(); 
        } 
         
        // Load login/profile view 
        //$this->load->view('user_authentication/index',$data);
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');		
		
		
		
	//	redirect(base_url());
	}
	
	public function search()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
public function notFound()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/notFound',$data);
		$this->load->view('front-end/templates/footer',$data);
	}
	
	public function sitemap()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/sitemap',$data);
		$this->load->view('front-end/templates/footer',$data);
	}
	
	public function test()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com | test page";
		$data['pageTitle']="Test";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/test');
		$this->load->view('front-end/templates/footer');
	}
	
	public function faq()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="FAQs";
		$data['pageTitle']="FAQs";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/faq');
		$this->load->view('front-end/templates/footer');
	}
	
	public function about()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="About us";
		$data['pageTitle']="About Us";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/about');
		$this->load->view('front-end/templates/footer');
	}
	
	public function privacy()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Privacy and confidentiality";
		$data['pageTitle']="Privacy and confidentiality";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/privacy');
		$this->load->view('front-end/templates/footer');
	}
	
	public function terms_conditions()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Terms and conditions";
		$data['pageTitle']="Terms and conditions";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/terms');
		$this->load->view('front-end/templates/footer');
	}
	
	public function return_refund_policy()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Return and refund policy";
		$data['pageTitle']="Return and refund policy";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/return_refund');
		$this->load->view('front-end/templates/footer');
	}
	
	public function how_to_order()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="How to order";
		$data['pageTitle']="How to order";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/how_to_order');
		$this->load->view('front-end/templates/footer');
	}
	
	public function contact()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Contact";
		$data['pageTitle']="Contact";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/pages/contact');
		$this->load->view('front-end/templates/footer');
	}
	
	
	// Offer page
	public function offerPage()
	{
		if(isset($_POST['category']))
		{
			$cat=$this->input->post('category');
			$data=array();
			//$data['cartItems'] = $this->cart->contents();
			$data['offerProducts']=$this->product_model->get_all_offers();
			$data['offerCategories']=$this->product_model->get_offer_categories();
			$data['offersByCategory']=$this->product_model->getOffersByCategory($cat);
			$data['title']="Yesbd.com Ltd || Offers";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/offers',$data);
			$this->load->view('front-end/templates/footer');
		}
		else 
		{
		
			$data=array();
			//$data['cartItems'] = $this->cart->contents();
			$data['offerProducts']=$this->product_model->get_all_offers();
			$data['offerCategories']=$this->product_model->get_offer_categories();
			$data['title']="Yesbd.com Ltd || Offers";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/offers',$data);
			$this->load->view('front-end/templates/footer');
		}
		
	}
	
	
	
	// Offer page
	public function category()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['offerProducts']=$this->product_model->get_all_offers();
		//$data['offerCategories']=$this->product_model->get_offer_categories();
		$data['title']="Yesbd.com Ltd || Offers";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/category',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
/* Function for pages like-about us, how to order, contact us, privacy policy etc...*/
	public function displayPage()
	{
		$data=array();
		$this->load->model('pages_model');
		$data['pageInfo']=$this->pages_model->get_all_pages();
		$data['title']="Yesbd.com Ltd || Pages";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/page',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
  public function logout() { 
        // Remove local Facebook session 
        $this->facebook->destroy_session(); 
        // Remove user data from session 
        $this->session->unset_userdata('userData'); 
         
		
		
		
		$this->session->unset_userdata("custmrLogin");
		$this->session->unset_userdata("active_customer");
		$this->session->unset_userdata("customr_mobile");
		$this->session->unset_userdata("customr_email");
		$this->session->unset_userdata("merchantActive");
		$this->session->unset_userdata('paymentMethod');
			$this->session->unset_userdata('address_id');
		$this->session->unset_userdata('delivery_address');
		// Redirect to login page 
        redirect(base_url());
		
		
    } 
	
	
}
