<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->library('cart');
		$this->load->library('session');
		$this->load->model('customer_model');
		$this->load->model('Coupon_model');
	}
	
	public function index()
	{
		// Redirect if the cart is empty
        if($this->cart->total_items() <= 0){
			
			
			$data=array();
			$data['title']="Yesbd.com Ltd || Empty Cart";
			
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/emptyCart',$data);
			$this->load->view('front-end/templates/footer');
			
			//redirect(base_url());
        }
else 
{
		$cust_id=$this->session->userdata("active_customer");
		
		$data=array();
		//$this->load->model('product_model');
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$data['customer_address']=$this->customer_model->fetchCustomerAddressById($cust_id);
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/checkout',$data);
		$this->load->view('front-end/templates/footer');
		
	}
	}
	
	//
	public function setDeliveryAddress()
	{
		$deliveryTo=$this->input->post('deliveryAddress');
		$sess['delivery_address']=$deliveryTo;
		$this->session->set_userdata($sess);
		redirect(base_url('checkout'));
	}
	
	//
	public function setPaymentMethod()
	{
		$paymentMethod=$this->input->post('paymentType');
		$sess['paymentMethod']=$paymentMethod;
		$this->session->set_userdata($sess);
		
		redirect(base_url('checkout'));
	}
	
	
	// function for adding customer's new address
	public function saveCustomerAddress()
	{
		$CurrentURL=$this->input->post('currentURL');
		$cus_id=$this->input->post('address_customerId');
		$cus_firstName=$this->input->post('address_first_name');
		$cus_lastName=$this->input->post('address_last_name');
		$cus_phone=$this->input->post('address_phone');
		$cus_address=$this->input->post('address_address');
		$cus_area=$this->input->post('address_area');
		
		$deliveryAddressData=array(
		'address_customerId'=>$cus_id,
		'address_first_name'=>$cus_firstName,
		'address_last_name'=>$cus_lastName,
		'address_phone'=>$cus_phone,
		'address_address'=>$cus_address,
		'address_area'=>$cus_area,
		);
		
		$insertData=$this->customer_model->saveCustomerAddressData($deliveryAddressData);
		if($insertData == true) {
			
			//$this->session->set_flashdata('success','Prescription uploaded successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('error','Address save fail!. Please try again.');
			redirect($CurrentURL);
		}
		
	}
	
	
	// function for adding customer's new address
	public function updateDeliveryAddress($cus_id)
	{
		$CurrentURL=$this->input->post('currentURL');
		$cus_firstName=$this->input->post('address_first_name');
		$cus_lastName=$this->input->post('address_last_name');
		$cus_phone=$this->input->post('address_phone');
		$cus_address=$this->input->post('address_address');
		$cus_area=$this->input->post('address_area');
		
		$deliveryAddressData=array(
		'address_first_name'=>$cus_firstName,
		'address_last_name'=>$cus_lastName,
		'address_phone'=>$cus_phone,
		'address_address'=>$cus_address,
		'address_area'=>$cus_area,
		);
		
		$updateData=$this->customer_model->updateCustomerAddressData($cus_id,$deliveryAddressData);
		if($updateData == true) {
			
			//$this->session->set_flashdata('success','Prescription uploaded successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('error','Address update fail!. Please try again.');
			redirect($CurrentURL);
		}
		
	}
	
	
	// Save customer delivery schedule
	public function saveDeliverySchedule()
	{
	    //$CurrentURL=$this->input->post('currentURL');
        $delivery_date=$this->input->post('deliveryDate');
        $delivery_slot=$this->input->post('delivery_slot');
        $cus_id=$this->input->post('customerId');
        	$data = array(
        	    'order_customerId'=>$cus_id,
        		'delivery_date' => $delivery_date,
        		'delivery_slot' => $delivery_slot,	
        	);
        	
        	print_r($data);
        	exit();

            //$this->load->model('Checkout_model');

        	$save = $this->Checkout_model->saveDeliverySchedule($data);
        	if($save == true) {
				
			//	$this->session->set_flashdata('success','Vendor Succesfully created');
				redirect(base_url('checkout'));
        	}
        	else {
        	
				//$this->session->set_flashdata('error','Vendor not created');
				redirect(base_url('checkout'));
        	}
        

	}
	
	

	
	// function for appliying coupon discount
	public function applyCoupon()
	{
		$CurrentURL=$this->input->post('currentURL');
		$CouponCode=$this->input->post('coupon_code');
		$customer_id=$this->session->userdata("active_customer");
		
		$couponData=array(
		'coupon_code'=>$CouponCode,
		'coupon_customer_id'=>$customer_id,
		'address_first_name'=>$cus_firstName,
		'address_last_name'=>$cus_lastName,
		'address_phone'=>$cus_phone,
		'address_address'=>$cus_address,
		'address_area'=>$cus_area,
		);
		
		$insertData=$this->customer_model->saveCustomerAddressData($deliveryAddressData);
		if($insertData == true) {
			
			//$this->session->set_flashdata('success','Prescription uploaded successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('error','Address save fail!. Please try again.');
			redirect($CurrentURL);
		}
		
	}
	
	

		 
}

?>