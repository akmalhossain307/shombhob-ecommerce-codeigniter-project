<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class Users extends CI_Controller { 
    function __construct() { 
        parent::__construct(); 
         
        // Load facebook oauth library 
        $this->load->library('facebook'); 
         
        // Load user model 
        $this->load->model('user'); 
    } 
     
    public function createNewUser(){ 
		$data=array();
		$data['title']="User || Create new Role";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/users/createNewUser',$data);
		$this->load->view('back-end/templates/footer');
    }
	
	public function userList(){ 
		$data=array();
		$data['title']="User || User List";
		$data['userInfo']=$this->user->fetchWebsiteUser();
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/users/user-list',$data);
		$this->load->view('back-end/templates/footer');
    }
    
    public function changeWebsiteUserPassword(){ 
		$data=array();
		$data['title']="User || Change password";
		//$data['userInfo']=$this->user->fetchWebsiteUser();
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/users/changePassword',$data);
		$this->load->view('back-end/templates/footer');
    }


public function changeUserPassword(){ 
	
				$this->load->helper(array('form', 'url'));

                $this->load->library('form_validation');

                
                $this->form_validation->set_rules('user_name', 'Username', 'trim|required|valid_email');
                $this->form_validation->set_rules('old_password', 'Old Password', 'trim|required|min_length[3]');
                $this->form_validation->set_rules('new_password', 'New Password', 'trim|required|min_length[3]');
				
				$this->form_validation->set_error_delimiters('<div style="background:#ddd;color:coral">', '</div>');
				
				
                if ($this->form_validation->run() == FALSE)
                {
                        $data=array();
                		$data['title']="User || Change password";
                		//$data['userInfo']=$this->user->fetchWebsiteUser();
                		$this->load->view('back-end/templates/header',$data);
                		$this->load->view('back-end/users/changePassword',$data);
                		$this->load->view('back-end/templates/footer');
                }
                else
                {
                    $user_name=$this->input->post("user_name");
                    $password=md5($this->input->post("new_password"));
                        
						$update=$this->user->changeWebsiteUserPassword($user_name,$password);
						if($update)
						{
							$this->session->set_flashdata('success','Password changed successfully!');
							redirect(base_url('admin/change-website-user-password'));
						}
						else 
						{
							$this->session->set_flashdata('error','Something went wrong!');
							redirect(base_url('admin/change-website-user-password'));
						}
						//print_r($data);
                }
		
    } 



	public function saveUser(){ 
	
				$this->load->helper(array('form', 'url'));

                $this->load->library('form_validation');

                $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[3]|max_length[80]');
                $this->form_validation->set_rules('user_name', 'Username', 'trim|required|valid_email|is_unique[tbl_website_user.user_name]');
                $this->form_validation->set_rules('user_role', 'User Role', 'trim|required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]');
                $this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|matches[password]');
				
				$this->form_validation->set_error_delimiters('<div style="background:#ddd;color:coral">', '</div>');
				
				
                if ($this->form_validation->run() == FALSE)
                {
                        $data=array();
						$data['title']="User || Create new Role";
						$this->load->view('back-end/templates/header',$data);
						$this->load->view('back-end/users/createNewUser',$data);
						$this->load->view('back-end/templates/footer');
                }
                else
                {
                        $data=array(
						"name"=>$this->input->post("name"),
						"user_name"=>$this->input->post("user_name"),
						"user_role"=>$this->input->post("user_role"),
						"password"=>md5($this->input->post("password")),
						"cpassword"=>md5($this->input->post("cpassword")),
						);
						$insert=$this->user->saveWebsiteUser($data);
						if($insert)
						{
							$this->session->set_flashdata('success','New website user created successfully!');
							redirect(base_url('admin/create-new-user'));
						}
						else 
						{
							$this->session->set_flashdata('error','Something went wrong!');
							redirect(base_url('admin/create-new-user'));
						}
						//print_r($data);
                }
		
    } 
    
    
    
    public function deactivateUser($id)
	{
	    
		$data = array(
			'status' => 0,
			);
		$changed=$this->user->deactivateUserById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/user-list'));
        	}
        	else {
        	
				
				redirect(base_url('admin/user-list'));
        	}
	}
	
	public function activateUser($id)
	{
		$data = array(
			'status' => 1,
			);
		$changed=$this->user->activateUserById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/user-list'));
        	}
        	else {
        	
				
				redirect(base_url('admin/user-list'));
        	}
	}
    
    
    public function deleteWebsiteUser($id)
	{
	  
		$delete=$this->user->deleteUserById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Website user succesfully deleted!');
					redirect(base_url('admin/user-list'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','User not deleted');
					redirect(base_url('admin/user-list'));
				}
		
	}
    
 
    public function logout() { 
        // Remove local Facebook session 
        $this->facebook->destroy_session(); 
        // Remove user data from session 
        $this->session->unset_userdata('userData'); 
        // Redirect to login page 
        redirect('user_authentication'); 
    } 
}