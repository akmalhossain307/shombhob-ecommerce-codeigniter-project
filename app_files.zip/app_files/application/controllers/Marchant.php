<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Marchant extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('marchant_model');
		$this->load->model('dashboardProduct_model');
		$this->load->model('dashboardOrder_model');
		$this->load->model('product_model');
		//$this->load->library('cart');
		
	}
	

	public function marchantDashboard()
	{
	    $login = $this->session->userdata('isMarchantLoggedIn');
		if($login==false)
		{
		    redirect(base_url('marchant'));
		}
		else 
		{
    		
    		$this->load->view('back-end/marchant/dashboard');
    		
		}
		
	}
	
	public function register()
	{
		$data=array();
		$data['title']="Yesbd.com Marchant Panel";
		//$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/marchant/register',$data);
		//$this->load->view('back-end/templates/footer');
	}
	
	public function topsell()
	{
		
		$this->load->view('back-end/marchant/topsell');
		
	}
	
	public function shortListProducts()
	{
		
		$this->load->view('back-end/marchant/sorted');
		
	}
	
	public function SoldBySSL()
	{
		
		$this->load->view('back-end/marchant/ssl_order');
		
	}
	
	public function orderList()
	{
		
		$this->load->view('back-end/marchant/orders');
		
	}
	
	public function customerList()
	{
		
		$this->load->view('back-end/marchant/customer_list');
		
	}
	
	public function order_details($order_id)
	{
		
		$data['orderinfo'] = $this->marchant_model->get_order_details_by_order_id($order_id);
		$this->load->view('back-end/marchant/order_details',$data);
		
	}
	
	public function shortList()
	{
		
		$pro_id=$this->input->post('product_id');
		$currentURL=$this->input->post('currentURL');
		$data = array(
				'product_id' =>$pro_id
				);
		$save = $this->marchant_model->saveShortListedProduct($data);
			if($save==true)
			{
				$this->session->set_flashdata('sortSuccess','Product sortListed successfully!');
				redirect($currentURL); 
			}
			else
			{
				$this->session->set_flashdata('sortError','Failed to sortlist this product! Something went wrong..');
				redirect($currentURL);
			}
		
	}
	
	
	public function removeShortList($id)
	{
		
		$pro_id=$id;
		$delete = $this->marchant_model->deleteShortListedProduct($pro_id);
			if($delete==true)
			{
				//$this->session->set_flashdata('sortSuccess','Product sortListed successfully!');
				redirect(base_url('marchant/shortListProducts')); 
			}
			else
			{
				redirect(base_url('marchant/shortListProducts'));
			}
		
	}
	
	public function login()
	{
		$data=array();
		$data['title']="Yesbd.com Marchant Panel";
		//$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/marchant/login',$data);
		//$this->load->view('back-end/templates/footer');
	}
	
	public function logout(){ 
        $this->session->unset_userdata('isMarchantLoggedIn'); 
        $this->session->sess_destroy(); 
        redirect(base_url('marchant')); 
    } 
	
	
	public function registerMarchant(){ 
      
      if($_POST['register'])
      {
       //$currentURL= $this->input->post('currentURL');
	   
       $name= $this->input->post('name');
       $user= $this->input->post('username');
       $pass= md5($this->input->post('password'));
	   
	  // echo" ".$name." ".$user." ".$pass;
	   //exit;
       $data = array(
					'name' =>$name,
					'username' =>$user,
					'password' =>$pass	
					);
			
		$userExist=$this->marchant_model->checkMarchantUser($user);
		if($userExist==true)
		{
			$this->session->set_flashdata('userExist','This user already registered! Please try with different one.');
			
			$data=array();
			$data['title']="Yesbd.com Marchant Panel";
			$this->load->view('back-end/marchant/register',$data);
		}
		else 
		{			
			$save = $this->marchant_model->register_marchant($data);
			if($save==true)
			{
				$this->session->set_flashdata('regSuccess','Registration is successful!');
			
				$data=array();
				$data['title']="Yesbd.com Marchant Panel";
				$this->load->view('back-end/marchant/register',$data);
			}
			else
			{
				$this->session->set_flashdata('regError','Registration is fail! Something went wrong..');
			
				$data=array();
				$data['title']="Yesbd.com Marchant Panel";
				$this->load->view('back-end/marchant/register',$data);
			}
		
		}		
       
      }
         
      } 
	  
	  
	  public function checkLogin(){ 
      
      if(@$_POST['login'])
      {
      
       $user= $this->input->post('username');
       $pass= md5($this->input->post('password'));
	   $checkData=$this->marchant_model->checkMarchant($user,$pass);
       
       if($checkData==true)
       {
           //$this->session->set_userdata('isUserLoggedIn', TRUE);
           $this->session->set_userdata('isMarchantLoggedIn',true);
           $this->session->set_userdata('user',$user);
           redirect(base_url('marchantDashboard'));
       }
       else 
       {
           $this->session->set_flashdata('MarchantError','Username or Password is incorrect!');
			
		    redirect(base_url('marchant')); 
       }
      }
         
      } 
	
	
	
	public function category()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
  
	
	
}
