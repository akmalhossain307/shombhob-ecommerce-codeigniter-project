<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardOrder extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboardOrder_model');
		$this->load->model('product_model');
		//$this->load->model('dashboardCategory_model');
		//$this->load->library('cart');
		
		$login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('yesAdmin'));
		}
	//	$this->output->cache(720);
	}
	

	public function index()
	{
		$data=array();
		$data['orders']=$this->dashboardOrder_model->get_all_orders();
		//$data['products']=$this->dashboardProduct_model->get_all_products();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/orderList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	public function productwiseReport()
	{
		$data=array();
	    $data['orders']=$this->dashboardOrder_model->get_all_delivered_orders();
		//$data['products']=$this->dashboardProduct_model->get_all_products();
		//$data['title']="Yesbd.com Ltd. Admin panel";
	//	$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/productwisesalereport',$data);
	//	$this->load->view('back-end/templates/footer');
	}
	
	public function invoiceList()
	{
		$data=array();
		$data['invoices']=$this->dashboardOrder_model->get_all_invoices();
		//$data['products']=$this->dashboardProduct_model->get_all_products();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/invoiceList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	public function prescriptionList()
	{
		$data=array();
		$data['prescriptions']=$this->dashboardOrder_model->get_all_prescriptions();
		//$data['products']=$this->dashboardProduct_model->get_all_products();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/prescriptionList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	
	//view single prescription by id
	public function viewPrescription($presID)
	{
		
		$data=array();
		$data=array('status'=>1);
		$this->dashboardOrder_model->changePrescriptionViewStatus($data,$presID);
		$data['prescriptionInfo']=$this->dashboardOrder_model->getSinglePrescriptionById($presID);
		
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/viewPrescription',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	//view product order by id
	public function viewOrder($orderID)
	{
		$data=array('viewStatus'=>1);
		$this->dashboardOrder_model->changeViewStatus($data,$orderID);
		$data['orderInfo']=$this->dashboardOrder_model->getSingleOrderById($orderID);
		
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/orders/viewOrder',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//view product invoice by product id
	public function viewInvoice($orderID)
	{
		//$data=array('viewStatus'=>1);
		//$this->dashboardOrder_model->changeViewStatus($data,$orderID);
		
		$data['orderInfo']=$this->dashboardOrder_model->getSingleOrderById($orderID);
		
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/orders/viewInvoice',$data);
	
	}
	
	//print product invoice by product id
	public function printInvoice($orderID)
	{
		//$data=array('viewStatus'=>1);
		//$this->dashboardOrder_model->changeViewStatus($data,$orderID);
		
		$data['orderInfo']=$this->dashboardOrder_model->getSingleOrderById($orderID);
		
		$data['title']="Print Invoice | Office Copy";
		$this->load->view('back-end/orders/printInvoice',$data);
	
	}
	
	//print customer invoice by product id
	public function printCustomerInvoice($orderID)
	{
		//$data=array('viewStatus'=>1);
		//$this->dashboardOrder_model->changeViewStatus($data,$orderID);
		
		$data['orderInfo']=$this->dashboardOrder_model->getSingleOrderById($orderID);
		
		$data['title']="Print Invoice | Customer Copy";
		$this->load->view('back-end/orders/printCustomerInvoice',$data);
	
	}
	
	
	
	public function deliverystatus()
	{
		
		$delivery_status = $this->input->post('delivery_status');
		$order_id		= $this->input->post('order_id');
		$data['order_delivery_status'] = $delivery_status;
		$this->db->update('tbl_customer_orders', $data, array('order_id' => $order_id));
		
	}
	
	
	public function paymentstatus()
	{
		$payment_status = $this->input->post('payment_status');
		$order_id		= $this->input->post('order_id');
		$data['order_payment_status'] = $payment_status;
		$this->db->update('tbl_customer_orders', $data, array('order_id' => $order_id));
		
	}
	
	
	//Function for deleting product order by order id
	public function deleteOrder($order_id)
	{
		$delete=$this->dashboardOrder_model->deleteProductOrderById($order_id);
				if($delete)
				{
					//$this->session->set_flashdata('success','Product Succesfully deleted!');
					redirect(base_url('admin/productOrders'));
				}
				else 
				{
					
					//$this->session->set_flashdata('error','Product not deleted');
					redirect(base_url('admin/productOrders'));
				}
		
	}
	
	
	
	
	
	
}
