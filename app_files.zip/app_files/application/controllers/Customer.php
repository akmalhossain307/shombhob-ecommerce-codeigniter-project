<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('customer_model');
		$this->load->model('product_model');
		$this->load->helper('url');
		//$this->load->library('cart');
		//$this->output->cache(720);
	}
	
	public function registration()
	{
		
				$CurrentURL=$this->input->post('currentURL');
				
				$mobile=$this->input->post('mobile');
				$email=$this->input->post('email');
				
				$emailExist=$this->customer_model->checkCustomerEmail($email);
				$mobileNumberExist=$this->customer_model->checkCustomerMobile($mobile);
				if($emailExist==true && $mobileNumberExist==true)
				{
					$this->session->set_flashdata('emailExist','Dear customer,  this email already registered! Please try different one.');
					
					$this->session->set_flashdata('mobileNumberExist','Dear customer,  this mobile number already registered! Please try different one.');
					redirect($CurrentURL);
				}
				else if($emailExist==true)
				{
					$this->session->set_flashdata('emailExist','Dear customer,  this email already registered! Please try different one.');
					redirect($CurrentURL);
				}
				else if($mobileNumberExist==true)
				{
					$this->session->set_flashdata('mobileNumberExist','Dear customer,  this mobile number already registered! Please try different one.');
					redirect($CurrentURL);
				}
			
				$data = array(
						'name' => $this->input->post('name'),
						'mobile' => $this->input->post('mobile'),
						'email' => $this->input->post('email'),
						'password' => md5($this->input->post('password'))	
					);

				$create = $this->customer_model->register_customer($data);
				if($create == true) {
					
					
						//$cus_phone =$this->input->post('mobile');
						$cus_phone =$this->input->post('mobile');
					
						$message_body="Dear customer, You have successfully completed your registration at shombhob.com( a pioneer online pharmacy and healthcare shop in bd.)";

						$sender= 'yesbd.com'; // Need to change
				
						$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
				
						$user = 'jayson'; // Need to change
						$password = 'Abcd@321'; // Need to change
				
						//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
						
						$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$cus_phone.'&Message='.urlencode($message_body);
						
				
						$smsgatewaydata = $smsGatewayUrl.$api_params;
						$url = $smsgatewaydata;
				
						$ch = curl_init();
				
						curl_setopt($ch, CURLOPT_POST, false);
				
						curl_setopt($ch, CURLOPT_URL, $url);
				
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
				
						curl_close($ch);
					
					
					
					
					
					$this->session->set_flashdata('success','Registration successful!');
					redirect($CurrentURL);
				}
				else {
				
					$this->session->set_flashdata('error','Registration Fail!');
					redirect($CurrentURL);
				}   
		
	}
	
	
	
		//Customer registration from checkout page
	
	public function registration1()
	{
		
				$CurrentURL=$this->input->post('currentURL');
				
				$mobile=$this->input->post('mobile');
				$email=$this->input->post('email');
				
				$emailExist=$this->customer_model->checkCustomerEmail($email);
				$mobileNumberExist=$this->customer_model->checkCustomerMobile($mobile);
				if($emailExist==true && $mobileNumberExist==true)
				{
					$this->session->set_flashdata('emailExist1','Dear customer,  this email already registered! Please try different one.');
					
					$this->session->set_flashdata('mobileNumberExist1','Dear customer,  this mobile number already registered! Please try different one.');
					redirect($CurrentURL);
				}
				else if($emailExist==true)
				{
					$this->session->set_flashdata('emailExist1','Dear customer,  this email already registered! Please try different one.');
					redirect($CurrentURL);
				}
				else if($mobileNumberExist==true)
				{
					$this->session->set_flashdata('mobileNumberExist1','Dear customer,  this mobile number already registered! Please try different one.');
					redirect($CurrentURL);
				}
			
				$data = array(
						'name' => $this->input->post('name'),
						'mobile' => $this->input->post('mobile'),
						'email' => $this->input->post('email'),
						'password' => md5($this->input->post('password'))	
					);

				$create = $this->customer_model->register_customer($data);
				if($create == true) {
					
					
						//$cus_phone =$this->input->post('mobile');
						$cus_phone =$this->input->post('mobile');
					
						$message_body="Dear customer, You have successfully completed your registration at shombhob.com( a pioneer online pharmacy and healthcare shop in bd.)";

						$sender= 'yesbd.com'; // Need to change
				
						$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
				
						$user = 'jayson'; // Need to change
						$password = 'Abcd@321'; // Need to change
				
						//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
						
						$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$cus_phone.'&Message='.urlencode($message_body);
						
				
						$smsgatewaydata = $smsGatewayUrl.$api_params;
						$url = $smsgatewaydata;
				
						$ch = curl_init();
				
						curl_setopt($ch, CURLOPT_POST, false);
				
						curl_setopt($ch, CURLOPT_URL, $url);
				
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
				
						curl_close($ch);
					
					
					
					
					
					$this->session->set_flashdata('reg1Success','Registration successful!');
					redirect($CurrentURL);
				}
				else {
				
					$this->session->set_flashdata('reg1Error','Registration Fail!');
					redirect($CurrentURL);
				}   
		
	}
	
	
	
	public function login()
	{
		
		$CurrentURL	=$this->input->post('currentURL1');
		$username 	= $this->input->post('username');
		$password	=md5($this->input->post('password'));
		$str =$username;
		$str =  str_replace('+88', '', $str);
		$str =  str_replace('-', '', $str);
		
		if(is_numeric($str))
		{
			
			$loginData 	= array(
						'mobile'  => $str,
						'password'  => $password,
					);
			$checkLogin=$this->customer_model->customerLoginByPhone($str,$password);
			if($checkLogin==true)
			{
				$activate['active_customer'] = $checkLogin['customer_id'];
				$activate['customr_mobile'] = $checkLogin['mobile'];
				$activate['customr_name'] = $checkLogin['name'];
				$activate['customr_email'] = $checkLogin['email'];
				$activate['custmrLogin'] = TRUE;
				$this->session->set_userdata($activate);
				//echo"<div class='loader' id='loader'></div>";
			$this->session->set_flashdata('success','Login successful!');
			redirect($CurrentURL);
			//redirect('Checkout');
			
			}
			else 
			{	
			$this->session->set_flashdata('error','Login Fail! Username or Password is incorrect.');
			redirect($CurrentURL);
			}
			
			
		}
		else 
		{
			$loginData 	= array(
						'email'  => $str,
						'password'  => $password,
					);
			$checkLogin=$this->customer_model->customerLoginByEmail($str,$password);
			if($checkLogin==true)
			{
				$activate['active_customer'] = $checkLogin['customer_id'];
				$activate['customr_mobile'] = $checkLogin['mobile'];
				$activate['customr_name'] = $checkLogin['name'];
				$activate['customr_email'] = $checkLogin['email'];
				$activate['custmrLogin'] = TRUE;
				$this->session->set_userdata($activate);
				
			$this->session->set_flashdata('success','Login successful!');
			redirect($CurrentURL);
			//redirect('Checkout');
			
			}
			else 
			{	
			$this->session->set_flashdata('error','Login Fail! Username or Password is incorrect.');
			redirect($CurrentURL);
			}
		}
		
					
	}
	
	//login customer from checkout page
	
	public function login1()
	{
		
		$CurrentURL	=$this->input->post('currentURL1');
		$username 	= $this->input->post('username');
		$password	=md5($this->input->post('password'));
		$str =$username;
		$str =  str_replace('+88', '', $str);
		$str =  str_replace('-', '', $str);
		
		if(is_numeric($str))
		{
			
			$loginData 	= array(
						'mobile'  => $str,
						'password'  => $password,
					);
			$checkLogin=$this->customer_model->customerLoginByPhone($str,$password);
			if($checkLogin==true)
			{
				$activate['active_customer'] = $checkLogin['customer_id'];
				$activate['customr_mobile'] = $checkLogin['mobile'];
				$activate['customr_name'] = $checkLogin['name'];
				$activate['customr_email'] = $checkLogin['email'];
				$activate['custmrLogin'] = TRUE;
				$this->session->set_userdata($activate);
				echo"<div class='loader' id='loader'></div>";
			$this->session->set_flashdata('log1Success','Login successful! Redirecting...');
			redirect($CurrentURL);
			//redirect('Checkout');
			
			}
			else 
			{	
			$this->session->set_flashdata('log1Error','Login Fail! Username or Password is incorrect.');
			redirect($CurrentURL);
			}
			
			
		}
		else 
		{
			$loginData 	= array(
						'email'  => $str,
						'password'  => $password,
					);
			$checkLogin=$this->customer_model->customerLoginByEmail($str,$password);
			if($checkLogin==true)
			{
				$activate['active_customer'] = $checkLogin['customer_id'];
				$activate['customr_mobile'] = $checkLogin['mobile'];
				$activate['customr_name'] = $checkLogin['name'];
				$activate['customr_email'] = $checkLogin['email'];
				$activate['custmrLogin'] = TRUE;
				$this->session->set_userdata($activate);
				
			$this->session->set_flashdata('log1Success','Login successful! Redirecting...');
			redirect($CurrentURL);
			//redirect('Checkout');
			
			}
			else 
			{	
			$this->session->set_flashdata('log1Error','Login Fail! Username or Password is incorrect.');
			redirect($CurrentURL);
			}
		}
		
					
	}
	
	
	public function checkEmailOrPhone()
	{
		$CurrentURL	=$this->input->post('currentURL1');
		$username 	= $this->input->post('username');
		$str 		=$username;
		$str 		=  str_replace('+88', '', $str);
		$str 		=  str_replace('-', '', $str);
		if(is_numeric($str))
		{
		//$emailExist=$this->customer_model->checkCustomerEmail($email);
				$mobileNumberExist=$this->customer_model->checkCustomerMobile($str);
				if($mobileNumberExist==true)
				{
					$this->session->set_userdata("customerUsername",$str);
					$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
				}
				else
				{
					$this->session->set_flashdata('mobileOrEmailNotExit','Dear customer, You might not registered with this phone no.! Please check and then try again.');
					redirect($CurrentURL);
				}
		}
		else 
		{
			$emailExist=$this->customer_model->checkCustomerEmail($str);
			if($emailExist==true)
				{
					$this->session->set_userdata("customerUsername",$str);
					$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
				}
				else
				{
					$this->session->set_flashdata('mobileOrEmailNotExit','Dear customer, You might not registered with this email! Please check and then try again.');
					redirect($CurrentURL);
				}
		}
	}
	



public function resetCustomerPassword()
{
    $email=$this->input->post('email');
	$cURL=$this->input->post('currentURL');
		
    $email = $this->input->post('email');
    $findemail = $this->MY_model->ForgotPassword($email);
    if ($findemail) {
        $this->MY_model->sendpassword($findemail);
    } else {
        echo "<script>alert(' $email not found, please enter correct email id')</script>";
        redirect(base_url() . 'MY_controller/index', 'refresh');
    }
}



	public function resetCustomerPassword1()
	{
		$email=$this->input->post('email');
		$cURL=$this->input->post('currentURL');
		
		$emailExist=$this->customer_model->checkCustomerEmail($email);
			if($emailExist==true)
				{
				    $this->customer_model->sendpassword($email);
				
				
				}
				else
				{
					//echo"Email not exits.";
					
					$this->session->set_flashdata('emailError','Dear customer, You might not registered with this email! Please check and then try again.');
					redirect($cURL);
				}
		
	}


	
	
	
	/*
	public function resetPassword()
	{
		$email=$this->input->post('email');
		$cURL=$this->input->post('currentURL');
		
		$emailExist=$this->customer_model->checkCustomerEmail($email);
			if($emailExist==true)
				{
				    
					
					$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => 'info@yesbd.com',
					'smtp_pass' => '123#123#',
					'mailtype'  => 'html', 
					'charset'   => 'iso-8859-1',
					'wordwrap' => TRUE
						);
					$this->email->set_mailtype("html");
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");
					$this->email->from('info@yesbd.com', 'Yesbd.com');
					$this->email->to(array($email)); 
					$this->email->subject('Password Reset Link');
					
					//https://yesbd.com/customer/newPassword
					//$text= "https://yesbd.com/customer/newPassword/".$email;
					
					  $text= "<form action='https://yesbd.com/customer/newPassword/' method='POST''> 
                    	    <input type='hidden' name='email' value='$email'/> <br /> 
                    	    <input type='submit' name='user' style='background:white;color:red;padding:5px;cursor: pointer;'value='Click Here' />
                    	</form>";
					
					$body="Dear Customer, Please click the link below to create new password. <br/>".$text." <br/><b>Regards</b><br/><span>Yesbd.com Team.</span>";
					
					$this->email->message($body); 
					$this->email->send();
			
			
			
			
			$this->session->set_userdata("customerUsername",$email);
			
			
			
					$this->session->set_flashdata('emailSuccess','Dear customer, we have just sent you an email to your given address. Please check your email.');
					
					redirect($cURL);
					
					
					
				}
				else
				{
					//echo"Email not exits.";
					
					$this->session->set_flashdata('emailError','Dear customer, You might not registered with this email! Please check and then try again.');
					redirect($cURL);
				}
		
	}

*/



	
	
	public function newPassword()
	{
		$data=array();
		$data['title']="Customer || Change Password";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/recoverPassword',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
	public function forgotPass()
	{
		//$cus_id=$this->session->userdata('active_customer');
		$data=array();
		//$data['customerInfo']=$this->customer_model->fetchCustomerById($cus_id);
		//$data['customerOrderInfo']=$this->customer_model->fetchCustomerOrderDataById($cus_id);
		$data['title']="Customer || Password Recovery";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/forgotPassword',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
	
	public function forgotPassword()
	{
		//$cus_id=$this->session->userdata('active_customer');
		$data=array();
		//$data['customerInfo']=$this->customer_model->fetchCustomerById($cus_id);
		//$data['customerOrderInfo']=$this->customer_model->fetchCustomerOrderDataById($cus_id);
		$data['page_title']="Forget Password";
		$data['title']="Customer || Password Recovery";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/forgotPass',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function dashboard()
	{
		$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['customerInfo']=$this->customer_model->fetchCustomerById($cus_id);
		$data['customerOrderInfo']=$this->customer_model->fetchCustomerOrderDataById($cus_id);
		$data['title']="Customer || Customer Dashboard";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/dashboard',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	public function customerProfile()
	{
		$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['customerInfo']=$this->customer_model->fetchCustomerById($cus_id);
		$data['title']="Customer || Customer Profile";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/profile',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	public function orderHistory()
	{
		$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['customerOrderInfo']=$this->customer_model->fetchCustomerOrderDataById($cus_id);
		$data['title']="Customer || Customer Profile";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/orderHistory',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	public function cusOrderDetails($orderID)
	{
		$data=array();		
$data['OrderSummary']=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
$data['cusOrderDetails']=$this->customer_model->fetchCustomerOrderDetailsById($orderID);
		$data['title']="Customer || Customer Profile";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/orderDetails',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	public function productWishList()
	{
		$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['customerWishList']=$this->customer_model->fetchCustomerWishListByCusId($cus_id);
		$data['title']="Customer || Customer Profile";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/wishList',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	public function customerDeliveryAddress()
	{
		$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['addressInfo']=$this->customer_model->fetchCustomerAddressByCusId($cus_id);
		$data['title']="Customer || Customer Profile";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/address',$data);
		$this->load->view('front-end/templates/footer');
	}	
	
	
public function editAddress($address_id)
	{
		
		$data=array();
		$data['addressInfo']=$this->customer_model->fetchCustomerAddressByAddressId($address_id);
		$data['title']="Customer || Update Address";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/editAddress',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	// function for update customer address address
	public function updateAddress($address_id)
	{
		
		$CurrentURL=$this->input->post('currentURL');
		//$cus_id=$this->input->post('address_customerId');
		//$cus_firstName=$this->input->post('address_first_name');
		$Name=$this->input->post('name');
		$cus_phone=$this->input->post('address_phone');
		$cus_address=$this->input->post('address_address');
		$cus_area=$this->input->post('address_area');
		
		$deliveryAddressData=array(
		//'address_first_name'=>$cus_firstName,
		'name'=>$Name,
		'address_phone'=>$cus_phone,
		'address_address'=>$cus_address,
		'address_area'=>$cus_area,
		);
		
		$update=$this->customer_model->updateCustomerAddressData($address_id,$deliveryAddressData);
		if($update == true) {
			
			$this->session->set_flashdata('addressUpdateSuccess','Address updated successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('addressUpdateError','Address update fail!. Please try again.');
			redirect($CurrentURL);
		}
		
	}
	
	//Display change password page...
	public function changePassword()
	{
		//$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['title']="Customer || Change Password";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/customer/changePassword',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	public function updateNewPassword()
	{
		$CurrentURL=$this->input->post('currentURL');
		$cus_id=$this->input->post('customerId');
		$password=md5($this->input->post('password'));
		$newPassword=md5($this->input->post('newPassword'));
		//$this->load->model('customer_model');
		$checkExistPassword=$this->customer_model->checkExistPassword($cus_id,$password);
		if($checkExistPassword==false)
		{
			$this->session->set_flashdata('oldPassNotMatched','Old password not Matched!');
			redirect($CurrentURL);
			
		}
		else 
		{
			$update=$this->customer_model->changeOldPassByNewPass($cus_id,$newPassword);
			if($update==true)
			{
				$this->session->set_flashdata('passChangeSuccess','Password Changed successfully!');
				redirect($CurrentURL);
				
			}
			else 
			{
				$this->session->set_flashdata('passChangeError','Password Change fail! Please try again.');
				redirect($CurrentURL);
				
			}
		}
		
	}
	
	
	// Change password by email or pnone no...
	public function recoverPassword()
	{
		$CurrentURL	=$this->input->post('currentURL');
		$username 	= $this->input->post('username');
		$pass 		= md5($this->input->post('password'));
		$str 		=$username;
		$str 		=  str_replace('+88', '', $str);
		$str 		=  str_replace('-', '', $str);
		if(is_numeric($str))
		{
			
			$chngPasswordWithPnone=$this->customer_model->changePasswordWithPhone($str,$pass);
			if($chngPasswordWithPnone==true)
			{
				$this->session->set_flashdata('passChngSuccess','Password changed successfully! You may now login with the changed password.');
				//redirect(base_url('customer/recoverPassword'));
				
					//$this->session->set_userdata("customerUsername",$str);
					$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
				
			}
			else 
			{
				$this->session->set_flashdata('passChngError','Password change fail! Please try again.');
				//redirect(base_url('customer/recoverPassword'));
					$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
			}
		}
		else 
		{
			
			$chngPasswordWithEmail=$this->customer_model->changePasswordWithEmail($str,$pass);
			if($chngPasswordWithEmail==true)
			{
				$this->session->set_flashdata('passChngSuccess','Password changed successfully! You may now login with the changed password.');
				//redirect(base_url('customer/recoverPassword'));
				$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
			}
			else 
			{
				$this->session->set_flashdata('passChngError','Password change fail! Please try again.');
				//redirect(base_url('customer/recoverPassword'));
				$data=array();
					$data['title']="Customer || Change Password";
					$this->load->view('front-end/templates/header',$data);
					$this->load->view('front-end/customer/recoverPassword',$data);
					$this->load->view('front-end/templates/footer');
			}
		}
	}
	
	// Customer Logout
	public function logout()
	{
		$this->session->unset_userdata("custmrLogin");
		$this->session->unset_userdata("active_customer");
		$this->session->unset_userdata("customr_mobile");
		$this->session->unset_userdata("customr_email");
		$this->session->unset_userdata("merchantActive");
		$this->session->unset_userdata('paymentMethod');
		$this->session->unset_userdata('address_id');
		$this->session->unset_userdata('delivery_address');
		redirect(base_url());
	}
	
	
	// Function for prescription upload
	public function uploadPrescription()
	{
		$CurrentURL=$this->input->post('currentURL');
		
		$prescriptionImage 		= $this->uploadPrescriptionImage();
		$data=array(
		'name'				=>$this->input->post('name'),
		'phone'				=>$this->input->post('phone'),
		'email'				=>$this->input->post('email'),
		'prescriptionImage'	=>$prescriptionImage,
		'query'				=>$this->input->post('query'),
		);
		$ins=$this->customer_model->savePrescriptionData($data);
		
		if($ins == true) {
			
			$this->session->set_flashdata('success','Prescription uploaded successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('error','Prescription uploading fail!');
			redirect($CurrentURL);
		}
	}
	
	// function for prescription image upload 
	public function uploadPrescriptionImage()
    {
		
        $config['upload_path'] = 'assets/uploads/prescriptions';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('prescriptionImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['prescriptionImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    }
    
    
    public function customerList()
	{
		//$cus_id=$this->session->userdata('active_customer');
		$data=array();
		$data['customerInfo']=$this->customer_model->fetchUniqueCustomerList();
		$data['title']="Customer || Customer List";
		//$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/reports/customerList',$data);
		//$this->load->view('back-end/templates/footer');
	}
	
	
	public function trackOrder()
	{
		$order_no=$this->input->post('order_no');
		$data=array();
		$data['orderInfo']=$this->customer_model->check_order($order_no);
		//$data['addressInfo']=$this->customer_model->fetchCustomerAddressByAddressId($address_id);
		$data['title']="Customer || Order Info";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/orderInfo',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
}

?>