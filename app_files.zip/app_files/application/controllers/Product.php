<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('dashboardSettings_model');
		$this->load->library('cart');
		$this->load->library('session');
		$this->load->helper('url');
		
		//$this->output->cache(720);
	}
	
	public function index()
	{
	    
		$data=array();
		$this->load->model('product_model');
		$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
		
	}
	
	// function for fetching products sub-category by category 
	public function fetchProductSubCategoryByCategory($category_id)
	{
		
		$data=array();
		$this->load->model('product_model');
		$data['subCategories']=$this->product_model->getProductSubCategoryByCategory($category_id);
		
		$data['title']="Yesbd.com Ltd";
		//$data['category_name']=$category;
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/subCategoryPage',$data);
		$this->load->view('front-end/templates/footer');
		
	}
	
	
	// function for fetching products by sub-category 
	public function fetchProductBySubCategory($subCategorySlug)
	{
	     //$this->output->cache(720);
		$slug=$subCategorySlug;
		//exit();
		$data=array();
		$this->load->model('product_model');
		$data['categoryProduct']=$this->product_model->getProductBySubCategory($slug);
		$data['title']="Yesbd.com Ltd || Products";
		$data['categorySlug']=$slug;
		//$data['subCategory_name']=$subCategory;
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/subCategory',$data);
		$this->load->view('front-end/templates/footer');
		
	}
	

	
	public function updateItemQty(){
        $update = 0;
        
        // Get cart item info
        $rowid = $this->input->get('rowid');
        $qty = $this->input->get('qty');
        
        // Update item in the cart
        if(!empty($rowid) && !empty($qty)){
            $data = array(
                'rowid' => $rowid,
                'qty'   => $qty
            );
            $update = $this->cart->update($data);
        }
        
		
			echo $update?'ok':'err';
		
		
		    $this->session->set_flashdata('cartSuccess','Updated!');
	
        // Return response
        //echo $update?'ok':'err';
    }
	
	
	
	
	
	
	public function fetchOfferByCategory()
		 {
			
		 $cat=$this->input->post('category_id');
			
		  $data = $this->search_model->fetch_filter_data($cat);
		  
		  if($data->num_rows() > 0)
		  {
		   foreach($data->result() as $offer)
		   {
			   
			   echo"Category products...";
			?>
			<div class="col-lg-6 col-sm-6">
				<div class="l_product_item">
					<div class="l_p_img">
					<?php $imgURL=$offer->productImage;?>
						<img src="<?php echo base_url().$imgURL?>" alt="">
						
						<?php 
						$att=$offer->attribute;
						if($att=="prescription_needed")
						{
							echo"<h5 class='sale'>Prescription Needed</h5>";
						}
						else if($att=="new")
						{
							echo"<h5 class='new'>New</h5>";
						}
						else 
						{
						echo"<h5 class='new'>New</h5>";	
						}
						?>
					</div>
					<div class="l_p_text">
					   <ul>
							<li class="p_icon"><a data-toggle="modal" data-target="#productModal" title="Quick View" class="quick-view modal-view detail-link" href="#"><span class="ti-plus"></span></a></li>
							<li><a class="add_cart_btn" href="#">Add To Cart</a></li>
							<li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
						</ul>
						<h4><?php echo$offer->title;?></h4>
						<h6><span>Price:</span> 
						<?php 
						$price=$offer->price;
						$discount=$offer->discountPrice;
						if($discount){
							echo"<del>TK $price</del>";
						}
							?>
						  TK <?php echo$discount;?></h6>
					</div>
				</div>
			</div>
			
			<?php 
		   } 
		  }
		  else
		  {
		   echo"Sorry!No product offer today in this category.<br/><br/><br/>";
		  }		  
		 }
		 
		 
		 public function getOffersByCategory()
		 {
			$cat=$this->input->post('category');
			
		 }



function add_to_cart(){ 
    
        $this->load->model('product_model');
		$pro_id=$this->input->post('product_id');
		$proData=array(
			'product_id' => $this->input->post('product_id')
			);
		$this->product_model->saveProductToViewList($proData);
    
		$data = array(
			'id' => $this->input->post('product_id'), 
			'name' => $this->input->post('product_name'), 
			'image' => $this->input->post('product_image'), 
			'price' => $this->input->post('product_price'), 
			'old_price' => $this->input->post('product_old_price'), 
			'qty' => $this->input->post('quantity'), 
		);
		$this->cart->insert($data);
		
		echo $this->show_cart(); 
		
		$this->session->set_flashdata('cartSuccess','Product added to Bag!');
	
		
	}
	
	
	public function add()
	{
		
		$currentURL=$this->input->post('currentURL');
		$QTY=$this->input->post('quantity');
		if($QTY=="")
		{
			$QTY=1;
		}
		
		$data = array(
			'id' => $this->input->post('product_id'), 
			'name' => $this->input->post('product_name'), 
			'image' => $this->input->post('product_image'), 
			'price' => $this->input->post('product_price'), 
			'old_price' => $this->input->post('product_old_price'), 
			'qty' =>$QTY 
		);
		$this->cart->insert($data);
		 $this->session->set_flashdata('cartSuccess','Product added to Bag!');
		//redirect($currentURL);
		//echo"<script>history.back();</script>";
		//echo"<script>location.reload();</script>";
		redirect($_SERVER['HTTP_REFERER']);
		//echo $this->show_cart(); 
	}
	
	
	
	
	
	public function addMultiple()
	{

		$this->load->model('customer_model');
		$currentURL=$this->input->post('currentURL');
		$order_id=$this->input->post('order_id');
		
		$cusOrderDetails=$this->customer_model->fetchCustomerOrderDetailsById($order_id);
		
		foreach($cusOrderDetails as $details)
		{
			
			
			$proID=$details->details_item_id;
			
			$product=$this->customer_model->orderProductDetailsById($proID);
		
			foreach($product as $pro)
			{
				$this->load->model('product_model');
				$get_default_photo = $this->product_model->get_default_photo($pro->product_id);
				$proImage = $get_default_photo['image_url'];
			if($pro->discountPrice)
				{
				$price=$pro->discountPrice;
				}
				else 
				{
				$price=$pro->price;	
				}
			$result=array(
			
			  'id'  => $pro->product_id,
			  'name'   => $pro->title,
			  'image'   => base_url().$proImage,
			  'price'   => $price,
			  'old_price'   => $pro->price,
			  'qty'   => $details->details_item_quantity
			  );
			$this->cart->insert($result); 
			 
			//print_r($result);
		}
	
	
		}
	
		
redirect($_SERVER['HTTP_REFERER']);
	
		
	}
	
	
	
	
	public function addToWishList()
	{
		
			$currentURL=$this->input->post('currentURL');
			$cus_id=$this->input->post('customer_id');
		
			$data = array(
			'product_id' => $this->input->post('product_id'), 
			'customer_id' => $cus_id, 
			'title' => $this->input->post('product_name'), 
			'image' => $this->input->post('product_image'), 
			'price' => $this->input->post('product_price'), 
			);
			
			$ins=$this->product_model->saveProductWishList($data);
			
			if($ins == true) {
				
				$this->session->set_flashdata('wishlistSuccess','Added to Wishlist successfully!');
				//redirect($CurrentURL);
				redirect($_SERVER['HTTP_REFERER']);
			}
			else {
			
				$this->session->set_flashdata('wishlistError','Add to Wishlist fail!');
				//redirect($CurrentURL);
				redirect($_SERVER['HTTP_REFERER']);
			}
	}
	
	
	public function deleteWishlistProduct($proId)
	{
		$del=$this->product_model->deleteProductFromWishList($proId);
			
		if($del == true) {
			
			//$this->session->set_flashdata('wishlistSuccess','Added to Wishlist successfully!');
			//redirect($CurrentURL);
			redirect($_SERVER['HTTP_REFERER']);
		}
		else {
		
			//$this->session->set_flashdata('wishlistError','Add to Wishlist fail!');
			//redirect($CurrentURL);
			redirect($_SERVER['HTTP_REFERER']);
		}
	}
	
	
	// Add to cart function for offer products
	public function offer_add_cart()
	{
		
		$currentURL=$this->input->post('currentURL');
		$QTY=$this->input->post('quantity');
		if($QTY=="")
		{
			$QTY=1;
		}
		
		$data = array(
			'id' => $this->input->post('offer_id'), 
			'name' => $this->input->post('offer_name'), 
			'image' => $this->input->post('offer_image'), 
			'price' => $this->input->post('offer_price'), 
			'old_price' => $this->input->post('offer_old_price'), 
			'qty' =>$QTY 
		);
		$this->cart->insert($data);
		$this->session->set_flashdata('cartSuccess','Product added to Bag!');
		//redirect($currentURL);
		//echo"<script>history.back();</script>";
		//echo"<script>location.reload();</script>";
		redirect($_SERVER['HTTP_REFERER']);
		//echo $this->show_cart(); 
	}
	
	
	

	//<td><input type="number" value="'.$items['qty'].'" class="update_cart form-control" min="1"id="'.$items['rowid'].'/></td>
	
	/*
	function show_cart(){ 
		$output = '';
		$no = 0;
		foreach ($this->cart->contents() as $items) {
			$no++;
			$output .='
				<tr>
					<td>'.$items['name'].'</td>
					<td><img src="'.$items['image'].'" alt="product image" width="90"height="70" /></td>
					<td>'.number_format($items['price']).'</td>
					
					<td><input type="number"  value="'.$items['qty'].'"class="form-control" min="1" /></td>
					<td>'.number_format($items['subtotal']).'</td>
					<td>
					<div class="romove_cart"id="'.$items['rowid'].'">
					<a href="" class="btn btn-danger"><i class="zmdi zmdi-close"></i></a>
					</div>
					</td>
				</tr>
			';
			
		}
		$output .= '
			<tr>
				<th colspan="4" class="text-right">Delivery Charge</th>
				<th colspan="2">TK 60.00</th>
			</tr>
			<tr>
				<th colspan="4" class="text-right">Grand Total</th>
				<th colspan="2">'.'TK '.number_format($this->cart->total()).'.00</th>
			</tr>
		';
		return $output;
		
	}
	*/
	
	
	function show_cart(){ 
		//$output = '';
		$no = 0;
		
		foreach ($this->cart->contents() as $items) {
		    
		    
		     
		     $proId=$items['id'];
		      /*
		     if($proId==2664 || $proId==7406 || $proId=2664)
		     {
		      $qty=$items['qty'];
				    if($qty>3)
				    {
				        $data = array(
                                    'rowid' => $items["rowid"],
                                    'qty'   => 3
                            );
		             $this->cart->update($data);
		             
				    }
		     }
		     
		     */
		     
		     
			
		?>
				<tr>
				    
				    
				    
				    
				    <td>
				        
				        
				        
				        
				        
				     <?php 					
					$productId=$items['id'];
					$p = $this->product_model->getSingleProductInfo($productId);
					foreach($p as $pro)
					{
						
						$pID=$pro->product_id;
						$pQty=$pro->product_quantity;
						//$pQty=4;
						$cQty=$items['qty'];
						$uQty=$pQty-$cQty;
						if($cQty>=$pQty-1)
						{
							echo"<span style='color:red'>Only ".$pQty. " product(s) available</span>";
						
						?>
						
									
						
						
				        
	 <div class="def-number-input number-input safari_only">
                          <!--<button http://jsfiddle.net/wvye2u0t/ </button>-->
      

<input class="equipCatValidation" type="number" name="quantity" min="1" max="<?php echo$pQty;?>" value="<?php echo$items['qty']?>" onchange="updateCartItem(this, '<?php echo $items["rowid"]; ?>')"  autocomplete="off"/>
						  
                     </div> 
                     
                     
                    
                     
                     
					 
					 <script type="text/javascript"> 
	$('.equipCatValidation').on('keyup keydown', function(e){
    console.log($(this).val() > <?php echo$pQty;?>)
        if ($(this).val() > <?php echo$pQty;?> 
            && e.keyCode !== 46
            && e.keyCode !== 8
           ) {
           e.preventDefault();     
           $(this).val(<?php echo$pQty;?>);
        }
    });
	</script>
					 
						<?php 
						}
						else 
						{
							?>
							
 <div class="def-number-input number-input safari_only">
                          <!--<button http://jsfiddle.net/wvye2u0t/ </button>-->

 
   <!--    <input type="text" class="item-count" data-name="Lemon" value="5" style="width:20%;padding:3px"> -->
   
   <!-- Original  
    <input class="equipCatValidation" type="number" name="quantity" min="1" max="<?php //if( $pID==2664 || $proId==7406){echo"3";} else{echo"100";}?>" value="<?php //echo$items['qty']?>" onchange="updateCartItem(this, '<?php //echo $items["rowid"]; ?>')" autocomplete="off"/>
    
     -->  
    
<!--       

<button class="btn btn-default btnMinus" style="height:29px;width:0px;
">
<span class="glyphicon glyphicon-minus" style="top:-3px;right:7px"></span></button>
            
<input type="button" value="+" id="plus" onclick="plus()">

-->
    
    
<div class='main'>
  <!--  
  <button class='down_count' title='Down'><i class='icon-minus'></i></button>
  -->
  <input class="equipCatValidation counter" type="number" name="quantity" min="1" max="<?php if( $pID==2664 || $proId==7406){echo"3";} else{echo"100";}?>" value="<?php echo$items['qty']?>" onchange="updateCartItem(this, '<?php echo $items["rowid"]; ?>')" autocomplete="off"/>
  
  <!--
  <button class='up_count' title='Up' ><i class='icon-plus'></i></button>
  -->
  
</div>
    



					  
</div> 
      
<script type="text/javascript"> 

     $('button').click(function(e){
        var button_classes, value = +$('.counter').val();
        button_classes = $(e.currentTarget).prop('class');        
        if(button_classes.indexOf('up_count') !== -1){
            value = (value) + 1;            
        } else {
            value = (value) - 1;            
        }
        value = value < 0 ? 0 : value;
        $('.counter').val(value);
    });  
    $('.counter').click(function(){
        $(this).focus().select();
    });

</script>
      
      
	  
	   <script type="text/javascript"> 
	$('.equipCatValidation').on('keyup keydown', function(e){
    console.log($(this).val() ><?php if($pID==2664 || $pID==7406){echo"3";} else{echo"100";}?>)
        if ($(this).val() ><?php if($pID==2664 || $pID==7406){echo"3";} else{echo"100";}?> 
            && e.keyCode !== 46
            && e.keyCode !== 8
           ) {
           e.preventDefault();     
           $(this).val(<?php if($pID==2664 || $pID==7406){echo"3";} else{echo"100";}?>);
        }
    });
	</script>
	  
							<?php 
							
						}
					
?>



<?php 

					
					}
	?>
				        
				        
					    
					    <!--<input type="number"  value="<?php //echo $items['qty'];?>" onchange="updateCartItem(this, '<?php //echo $items["rowid"]; ?>')" class="form-control" min="1" />--></td>
					<td><?php echo $items['name'];?></td>
					<td><img src="<?php echo$items['image']; ?>" alt="product image" width="70"height="40" /></td>
				
				<!--	<td><?php //echo number_format($items['price']);?></td>-->
					
					
					<td><?php echo number_format($items['subtotal'],2);?></td>
					<td>
					<span class="romove_cart"id="<?php echo $items['rowid'];?>">
					<a href="" title="Remove"><i class="zmdi zmdi-close"></i></a>
					</span>
					</td>
				</tr>
			
		<?php 	
		
		
		}
		?>
			
			<?php if(number_format($this->cart->total())>0){
			
			
				?>
				
    			
    			
    				
		
			
			
			
			<?php
			
				if($this->session->userdata('applcopn_code') !== null)
			    {
				
				$coupon_code=$this->session->userdata('applcopn_code');
				$this->load->model('Coupon_model');
				//$cnp_applied=$this->Coupon_model->customer_has_applied_coupon($coupon_code);
				$cnp_applied= $this->Coupon_model->customer_has_applied_coupon($coupon_code);
				if($cnp_applied==true)
				{
					if($cnp_applied['coupon_discount_type']==1)
					{
						$disAmount=$cnp_applied['coupon_discount_amount'];
					}
					else 
					{
						$main_price=$this->cart->total();
						$disAmount=($main_price / 100) * intval($cnp_applied['coupon_discount_price']);
					}
				}
				
				?>
				
				
				 <tr>
				    <th colspan="3" class="text-right">Sub-Total (TK):</th>
				    <th colspan="2" class="text-left"> <?php echo number_format($this->cart->total(),2)?></th>
		    	</tr>
				
				<tr>
				    <th colspan="3" class="text-right">Delivery Charge (TK):</th>
				    <th colspan="2" class="text-left"> &nbsp; 0.00</th>
			    </tr>
				
				<tr>
				    <th colspan="3" class="text-right">Applied Coupon:</th>
				    <th colspan="2" class="text-left"> <?php echo$coupon_code;?></th>
			    </tr>
			
		       	<tr>
				    <th colspan="3" class="text-right">Coupon Discount:</th>
				    <th colspan="2" class="text-left"> Tk <?php echo$disAmount;?></th>
			    </tr>
			    
			    <tr>
				<th colspan="3" class="text-right">Grand Total (TK):</th>
				<th colspan="2" class="text-left"> <?php  $grndTotal=($this->cart->total()-$disAmount+0);
				echo number_format(($grndTotal), 2)
				?></th>
			</tr>
			    
			<?php 
			    }
			    else 
			    {
			?>
			
		    <tr>
				<th colspan="3" class="text-right">Sub-Total (TK):</th>
				<th colspan="2" class="text-left"> <?php echo number_format($this->cart->total(),2)?></th>
			</tr>
			<tr>
				<th colspan="3" class="text-right">Delivery Charge (TK):</th>
				<th colspan="2" class="text-left"> &nbsp; 0</th>
			</tr>
			<tr>
				<th colspan="3" class="text-right">Grand Total (TK):</th>
				<th colspan="2" class="text-left">  <?php 
			echo number_format(($this->cart->total()+0),2)
			;?></th>
			</tr>
			
			<?php 
			    }
			}
			
			
			
			else {
				
				echo"<tr> <br /><td colspan='6' class='text text-danger'>Your shopping bag is Empty!</td></tr>";
				
			}
			
			
			
			
			
	}
			
			
	
	
	
	
	

	function load_cart(){ 
		echo $this->show_cart();
	}
	
	function delete_cart(){ 
		$data = array(
			'rowid' => $this->input->post('row_id'), 
			'qty' => 0, 
		);
		$this->cart->update($data);
		echo $this->show_cart();
		
		$this->session->set_flashdata('error','Product removed from Bag!');
	}


		public function getSingleProductDetails($slug)
		{
			
			$details = $this->product_model->getSingleProductDetailsBySlug1($slug);
			foreach($details as $d)
			{
			    $proID=$d->product_id;
			}
			//echo$proID;
			//exit();
			
			$this->load->model('product_model');
			//$pro_id=$this->input->post('product_id');
			$proData=array(
			'product_id' => $proID
			);
			$this->product_model->saveProductToViewList($proData);
			
			
			$pro_slug=$slug;
			//exit();
			$data=array();
			$data['title']="Yesbd.com || Single product details";
			//$data['productDetails'] = $this->product_model->getSingleProductDetailsById($proId);
			$data['productDetails'] = $this->product_model->getSingleProductDetailsBySlug($pro_slug);
			
			
			
			
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/productDetails',$data);
			$this->load->view('front-end/templates/footer');
			
		}
		
	
	
	
	public function productRestockRequest()
		{
			
			$proId=$this->input->post('product_id');
			$currentURL11=$this->input->post('url');
			$data=array(
			    "product_id"=>$proId
			    );
		    $save = $this->product_model->saveproductRestockRequest($data);
		    if($save)
    		{
    		    $this->session->set_flashdata('success','Product re-stock request sent successfully!!');
    		    
    		   // echo"<script> alert('Product re-stock request sent successfully!')</script>";
    		    redirect($currentURL11);
    		   //redirect($_SERVER['HTTP_REFERER']);
    		    ?>
    		<!--
    		    <script>
                window.alert("Product re-stock request sent successfully!");
                window.setTimeout(function () {
                    location.href = "<?php //redirect($CurrentURL); ?>";
                }, 5000);
                
                </script>
               -->
                <?php
		   // $this->session->set_flashdata('wishlistSuccess','Added to Wishlist successfully!');
				//redirect($CurrentURL);
				//redirect($_SERVER['HTTP_REFERER']);
		    }
		    else 
		    {
		         $this->session->set_flashdata('error','Something went wrong! Product restock request not sent.');
		        //echo"<script> alert('Something went wrong! Product restock request not sent.')</script>";
    		    redirect($currentURL);
		        //redirect($_SERVER['HTTP_REFERER']);
		        ?>
		        	<!--
    		    <script>
                window.alert("Something went wrong! Product restock request not sent.");
                window.setTimeout(function () {
                    location.href = "<?php //redirect($currentURL); ?>";
                }, 5000);
                
                </script>
                   -->
                <?php
		    }
			
		}
			
		
		
		
		
	
		
		
		
		
		public function getSingleOfferProductDetails($offerId)
		{
			$data=array();
			$data['title']="Yesbd.com || Offer Details";
			$data['offerProductDetails'] = $this->product_model->getSingleOfferProductDetailsById($offerId);
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/offerProductDetails',$data);
			$this->load->view('front-end/templates/footer');
			
		}
		
		
		public function filterProducts()
		{
			/*
			if(isset($_POST['filterBy']))
			{
				
				$currntURL=$this->input->post('currentURL');
				$filterKeyword=$_POST['filterBy'];
				if($filterKeyword=='lowToHigh')
				{
					$this->product_model->getSingleOfferProductDetailsById($offerId);
				}
			
			}
			*/
			
		}
		
		 
}

?>