<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardCustomer extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboardCustomer_model');
		//$this->load->library('cart');
		
		$login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('yesAdmin'));
		}
		//$this->output->cache(720);
	}
	

	public function index()
	{
		$data=array();
		$data['customers']=$this->dashboardCustomer_model->get_all_customer();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/customers/customerList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	//fetch single customer by id 
	public function viewCustomer($id)
	{
		$data=array();
		$data['customer']=$this->dashboardCustomer_model->getCustomerById($id);
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/customers/viewCustomer',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	//Function for deleting customer by id
	public function deleteCustomer($id)
	{
		$delete=$this->dashboardCustomer_model->deleteCustomerById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Customer Succesfully deleted!');
					redirect(base_url('admin/customerList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Customer not deleted');
					redirect(base_url('admin/customerList'));
				}
		
	}	
	
	public function subscriberList()
	{
		$data=array();
		$data['subscribers']=$this->dashboardCustomer_model->get_all_subscriber();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/subscribers/subscriberList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	//Function for deleting subscriber by id
	public function deleteSubscriber($id)
	{
		$delete=$this->dashboardCustomer_model->deleteSubscriberById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Subscriber Succesfully deleted!');
					redirect(base_url('admin/subscriberList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Subscriber not deleted');
					redirect(base_url('admin/subscriberList'));
				}
		
	}
	
	
  
	
	
}
