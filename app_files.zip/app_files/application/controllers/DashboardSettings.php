<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardSettings extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboardProduct_model');
		$this->load->model('dashboardCategory_model');
		$this->load->model('dashboardSettings_model');
		//$this->load->library('cart');
		$login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('yesAdmin'));
		}
		
	}
	

	public function generalSettings()
	{
		$data=array();
		$data['settings']=$this->dashboardSettings_model->fetchGeneralSettings();
		$data['title']="Yesbd.com Ltd. Admin panel || General Settings";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/settings/general_settings',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	public function socialSettings()
	{
		$data=array();
		$data['categories']		=$this->dashboardCategory_model->get_all_category();
		$data['products']		=$this->dashboardProduct_model->get_all_products();
		$data['socialLinks']	=$this->dashboardSettings_model->fetchSocialLinks();
		$data['title']="Yesbd.com Ltd. Admin panel || Social Settings";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/settings/social_settings',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	// function for updating social settings
	public function updateSocialSettings()
	{
		$data=array(
		'facebook'			=>$this->input->post('facebook'),
		'googlePlus'		=>$this->input->post('googlePlus'),
		'linkedIn'			=>$this->input->post('linkedIn'),
		'twitter'			=>$this->input->post('twitter'),
		'flicker'			=>$this->input->post('flicker'),
		'instagram'			=>$this->input->post('instagram'),
		);
		$update=$this->dashboardSettings_model->modifySocialSettings($data);
		
		if($update == true) {
			
			$this->session->set_flashdata('success','Social setting updated successfully!');
			redirect(base_url('admin/socialSettings'));
		}
		else {
		
			$this->session->set_flashdata('error','Social setting not updated!');
			redirect(base_url('admin/socialSettings'));
		}
		
	}
	
	
	
	// function for updating general settings data 
	public function updateGeneralSettings($id)
	{
		if(!empty($_FILES['logoImage']['name'])){
	
			$logoImage 			= $this->uploadLogoImage();
			$data=array(
				'seoTitle'				=>$this->input->post('seoTitle'),
				'seoMetaKeyword'		=>$this->input->post('seoMetaKeyword'),
				'seoMetaDescription'	=>$this->input->post('seoMetaDescription'),
				'companyAddress'		=>$this->input->post('companyAddress'),
				'companyEmail'			=>$this->input->post('companyEmail'),
				'companyOpeningClosing'	=>$this->input->post('companyOpeningClosing'),
				'logoImage'				=>$logoImage,
				'companyPhone'			=>$this->input->post('companyPhone'),
				'deliveryInsideDhaka'	=>$this->input->post('deliveryInsideDhaka'),
				'deliveryOutsideDhaka'	=>$this->input->post('deliveryOutsideDhaka'),
				'copyrightText'			=>$this->input->post('copyrightText'),
				
				);
			$update=$this->dashboardSettings_model->modifyGeneralSettings($data);
			if($update == true) {
				
				$this->session->set_flashdata('success','General Settings updated successfully!');
				redirect(base_url('admin/generalSettings'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','General Settings not updated!');
				redirect(base_url('admin/generalSettings'));
        	}
		}
		else
		{
			// for empty img
			$data=array(
				'seoTitle'				=>$this->input->post('seoTitle'),
				'seoMetaKeyword'		=>$this->input->post('seoMetaKeyword'),
				'seoMetaDescription'	=>$this->input->post('seoMetaDescription'),
				'companyAddress'		=>$this->input->post('companyAddress'),
				'companyEmail'			=>$this->input->post('companyEmail'),
				'companyOpeningClosing'	=>$this->input->post('companyOpeningClosing'),
				'companyPhone'			=>$this->input->post('companyPhone'),
				'deliveryInsideDhaka'	=>$this->input->post('deliveryInsideDhaka'),
				'deliveryOutsideDhaka'	=>$this->input->post('deliveryOutsideDhaka'),
				'copyrightText'			=>$this->input->post('copyrightText'),
				);
			$update=$this->dashboardSettings_model->modifyGeneralSettings($data);
			if($update == true) {
				
				$this->session->set_flashdata('success','General Settings updated successfully!');
				redirect(base_url('admin/generalSettings'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','General Settings not updated!');
				redirect(base_url('admin/generalSettings'));
        	}
			
		  
		}
	}
	
	// function for logoImage upload
	public function uploadLogoImage()
    {
		
        $config['upload_path'] = 'assets/uploads/logo';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('logoImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['logoImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	
	// List all pages
	public function managePages()
	{
		$data=array();
		//$data['categories']		=$this->dashboardCategory_model->get_all_category();
		//$data['products']		=$this->dashboardProduct_model->get_all_products();
		$data['pages']	=$this->dashboardSettings_model->fetchPages();
		$data['title']="Yesbd.com Ltd. Admin panel || Social Settings";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/pages/managePages',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Create New page 
	public function createPage()
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Social Settings";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/pages/createPage',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Save new page data
	public function savePage()
	{
		$data=array(
		'pageTitle'			=>$this->input->post('pageTitle'),
		'pageContent'		=>$this->input->post('pageContent'),
		);
		$save=$this->dashboardSettings_model->saveNewPageData($data);
		
		if($save == true) {
			
			$this->session->set_flashdata('success','New page created successfully!');
			redirect(base_url('admin/page/create'));
		}
		else {
		
			$this->session->set_flashdata('error','Sorry! New page not created!');
			redirect(base_url('admin/page/create'));
		}
	}
	
	// Create New page 
	public function editPage($id)
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Update Page";
		$data['page']	=$this->dashboardSettings_model->fetchPageById($id);
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/pages/editPage',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Save update data of page
	public function updatePage($id)
	{
		$data=array(
		'pageTitle'			=>$this->input->post('pageTitle'),
		'status'			=>$this->input->post('status'),
		'pageContent'		=>$this->input->post('pageContent'),
		);
		$update=$this->dashboardSettings_model->saveUpdatePageData($data,$id);
		
		if($update == true) {
			
			$this->session->set_flashdata('success','Page update successfully!');
			redirect(base_url('admin/managePages'));
		}
		else {
		
			$this->session->set_flashdata('error','Sorry! Page not updated!');
			redirect(base_url('admin/managePages'));
		}
	}
	
	//Function for deleting page by id
	public function deletePage($id)
	{
				$delete=$this->dashboardSettings_model->deletePageById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Page Succesfully deleted!');
					redirect(base_url('admin/managePages'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Page not deleted');
					redirect(base_url('admin/managePages'));
				}
		
	}
	
	
	
	
	

	
	// Create New slider 
	public function createSlider()
	{
		$data=array();		
		$data['title']="Yesbd.com Ltd. Admin panel || Create Slider";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sliders/createSlider',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	// Save new slider data
	public function saveSlider()
	{
		$sliderImage=$this->uploadSliderImage();
		$data=array(
		'sliderTitle' =>$this->input->post('sliderTitle'),
		'sliderURL' =>$this->input->post('sliderURL'),
		'sliderImage' =>$sliderImage,
		);
		$save=$this->dashboardSettings_model->saveNewSlider($data);
		
		if($save == true) {
			
			$this->session->set_flashdata('success','New Slider created successfully!');
			redirect(base_url('admin/slider/create'));
		}
		else {
		
			$this->session->set_flashdata('error','Sorry! New slider not created!');
			redirect(base_url('admin/slider/create'));
		}
	}
	
	// function for sliderImage upload
	public function uploadSliderImage()
    {
		
        $config['upload_path'] = 'assets/uploads/slider';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('sliderImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['sliderImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    }
	
	
	// List all sliders
	public function manageSliders()
	{
		$data=array();
		$data['sliders']=$this->dashboardSettings_model->fetchSliders();
		$data['title']="Yesbd.com Ltd. Admin panel || Manage Sliders";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sliders/manageSliders',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Edit Slider 
	public function editSlider($id)
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Update Slider";
		$data['slider']	=$this->dashboardSettings_model->fetchSliderById($id);
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sliders/editSlider',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Save update data of slider
	public function updateSlider($id)
	{
		if(!empty($_FILES['sliderImage']['name'])){
	
			$sliderImage = $this->uploadSliderImage();
			$data=array(
				'sliderImage'=>$sliderImage,
				'status'=>$this->input->post('status'),
				'sliderTitle'=>$this->input->post('sliderTitle'),
				'sliderURL'=>$this->input->post('sliderURL'),
				);
			$update=$this->dashboardSettings_model->updateSliderById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Slider updated successfully!');
				redirect(base_url('admin/manageSliders'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Slider not updated!');
				redirect(base_url('admin/manageSliders'));
        	}
		}
		else 
		{
			//for empty image 
			$data=array(
				'status'=>$this->input->post('status'),
				'sliderTitle'=>$this->input->post('sliderTitle'),
				'sliderURL'=>$this->input->post('sliderURL'),
				);
			$update=$this->dashboardSettings_model->updateSliderById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Slider updated successfully!');
				redirect(base_url('admin/manageSliders'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Slider not updated!');
				redirect(base_url('admin/manageSliders'));
        	}
		}
		
	}
	
	//Function for deleting slider by id
	public function deleteSlider($id)
	{
				$delete=$this->dashboardSettings_model->deleteSliderById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Slider Succesfully deleted!');
					redirect(base_url('admin/manageSliders'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Slider not deleted');
					redirect(base_url('admin/manageSliders'));
				}
		
	}
	
	// List all Banners
	public function manageBanners()
	{
		$data=array();
		//$data['categories']		=$this->dashboardCategory_model->get_all_category();
		//$data['products']		=$this->dashboardProduct_model->get_all_products();
		$data['banners']	=$this->dashboardSettings_model->fetchBanners();
		$data['title']="Yesbd.com Ltd. Admin panel || Manage Banners";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/banners/manageBanners',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Create New banner 
	public function createBanner()
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Social Settings";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/banners/createBanner',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Save new banner data
	public function saveBanner()
	{
		$bannerImage=$this->uploadBannerImage();
		$data=array(
		'bannerImage' =>$bannerImage,
		);
		$save=$this->dashboardSettings_model->saveNewBanner($data);
		
		if($save == true) {
			
			$this->session->set_flashdata('success','New banner created successfully!');
			redirect(base_url('admin/banner/create'));
		}
		else {
		
			$this->session->set_flashdata('error','Sorry! New banner not created!');
			redirect(base_url('admin/banner/create'));
		}
	}
	
	// function for bannerImage upload
	public function uploadBannerImage()
    {
		
        $config['upload_path'] = 'assets/uploads/banner';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('bannerImage'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['bannerImage']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    }
	
	//Function for deleting banner by id
	public function deleteBanner($id)
	{
				$delete=$this->dashboardSettings_model->deleteBannerById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Banner Succesfully deleted!');
					redirect(base_url('admin/manageBanners'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Banner not deleted');
					redirect(base_url('admin/manageBanners'));
				}
		
	}
	
	// Edit Banner 
	public function editBanner($id)
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Update banner";
		$data['banner']	=$this->dashboardSettings_model->fetchBannerById($id);
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/banners/editBanner',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Save update data of Banner
	public function updateBanner($id)
	{
		if(!empty($_FILES['bannerImage']['name'])){
	
			$bannerImage = $this->uploadBannerImage();
			$data=array(
				'bannerImage'=>$bannerImage,
				'status'=>$this->input->post('status'),
				);
			$update=$this->dashboardSettings_model->updateBannerById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Banner updated successfully!');
				redirect(base_url('admin/manageBanners'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Banner not updated!');
				redirect(base_url('admin/manageBanners'));
        	}
		}
		else 
		{
			//for empty image 
			$data=array(
				'status'=>$this->input->post('status'),
				);
			$update=$this->dashboardSettings_model->updateBannerById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Banner updated successfully!');
				redirect(base_url('admin/manageBanners'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Banner not updated!');
				redirect(base_url('admin/manageBanners'));
        	}
		}
		
	}
	
	
}
