<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		
		//$this->load->library('session');
		$this->load->model('contact_model');
		$this->load->helper('url', 'form');
		$this->load->library('form_validation');
		//$this->output->cache(720);
	}
	
	public function save()
	{
	    //print("inside...");
	    
	    $CurrentURL=$this->input->post('currentURL');
	   $data=array(
            		'name'				=>$this->input->post('name'),
            		'email'				=>$this->input->post('email'),
            		'message'			=>$this->input->post('message'),
		);
		$ins_data=$this->contact_model->saveContactData($data);
		
		if($ins_data == true) {
			
			$this->session->set_flashdata('cSuccess','Contact data sent successfully!');
			redirect($CurrentURL);
		}
		else {
		
			$this->session->set_flashdata('cError','Data sending fail!');
			redirect($CurrentURL);
		}
	    
       
        
	    
	}
	
	
	public function query_list()
	{
	    $data=array();
		$data['query']=$this->contact_model->get_all_query();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/customer_query/queryList',$data);
		$this->load->view('back-end/templates/footer');
	}
	

	
	
}

?>