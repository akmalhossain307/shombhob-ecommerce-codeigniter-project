<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('Order_model');
		$this->load->model('dashboardOrder_model');
		$this->load->library('cart');
		$this->load->library('sslcommerz');
		$this->load->library('session');
		$this->load->model('customer_model');
		
		date_default_timezone_set("Asia/Dhaka");
		//$this->output->cache(720);
	}
	
	public function confirmOrder()
	{
		$grand_total = $this->input->post('grandTotal');
		$deliveryDate = $this->input->post('deliveryDate');
		$deliverySlot = $this->input->post('deliverySlot');
		$payMethod=$this->session->userdata('paymentMethod');
		if($payMethod == 'COD')
		{
			$p_status = 'Processing';
		}else
		{
			$p_status = 'Unpaid';
		}
		
		$get_email = $this->Order_model->get_customer_email($this->session->userdata('active_customer'));
		
		$order_data = array(
							'order_customerid'      => $this->session->userdata('active_customer'),
							'order_addressid'       => $this->input->post('address_id'),
							'order_payment_method'  => $payMethod,
							'order_payment_status'  => $p_status,
							'order_total_amount'    => ceil($this->input->post('cartTotal')),
							//'order_total_vat'       => $this->input->post('total_vat'),
							
							'order_delivery_cost'   =>$this->input->post('delivery_cost'),
							'order_applied_coupon'   =>$this->input->post('coupon_code'),
							'order_coupon_discount'   =>$this->input->post('coupon_discount_amount'),
							'order_grand_total'     => $grand_total,
							'order_delivery_date'   => $deliveryDate,
							'order_delivery_slot'   => $deliverySlot,
							'order_delivery_status' => 'Pending',
							'order_date'            => date('Y-m-d H:i:s'),
					  );
					  
					 // print_r($order_data);
					  
					 // exit();
					  
		$get_id 	 = $this->Order_model->save_order($order_data);
		$order_id 	 = $this->db->insert_id($get_id);
		$order_count = $this->Order_model->total_count();
		
		//Insert mapping
		$mapping = array(
						'mapping_orderid' => $order_id,
						'mapping_day' => date("l"),
						'mapping_month' => date("F"),
					);
		$this->Order_model->insert_mapping($mapping);
		
		//Update order number.
		//$order_number = date("Y").$order_count;
		
		$ord_part=$order_count;
		if($ord_part<10)
		{
		    $inv_part='0'.$ord_part;
		}
		else 
		{
		     $inv_part=$ord_part;
		}
		
		$order_number = date("ymd").date("s")."000".$order_count;
		//$order_number = $order_count;
		$inv['invoice_number'] = 'DK'.date("my").$inv_part;
		$inv['invoice_order_id'] = $order_id;
		//$inv['invoice_order_id'] = $order_id;
		$this->Order_model->update_ordernumber($order_id, $order_number);
		$this->Order_model->save_invoice($inv);
		
		//Save order details.
		$order_items = $this->cart->contents();
		foreach($order_items as $item){
			$item_data = array(
						'details_orderid'              => $order_id,
						'details_item_id'              => $item['id'],
						'details_item_quantity'        => $item['qty'],
						'details_item_unitprice'       => $item['price'],
						//'details_item_unitoldprice'	   => $item['old_price'],
						'details_item_subtotal'        => $item['subtotal']
					);
					
					
					
				$productId=$item['id'];
					$p = $this->product_model->getSingleProductInfo($productId);
					foreach($p as $pro)
					{
						
						$pID=$pro->product_id;
						$pQty=$pro->product_quantity;
						$cQty=$item['qty'];
						$uQty=$pQty-$cQty;
						$data=array('product_quantity'=>$uQty);
						$this->product_model->updateSingleProductQtyById($data,$pID);
					}	
			
		$this->Order_model->save_order_details($item_data);
			
		}	
		
		
		
		$get_phone = $this->Order_model->get_customer_phone($this->input->post('address_id'));
		$mobile_number = $get_phone['address_phone'];
		
		
		$sess['order_placed'] = TRUE;
		$sess['payer_order']  = $order_id;
		$sess['odrnmr'] 	  = $order_number;
		$sess['mobile'] 	  = $mobile_number;
		$sess['order_grand_total'] 	  = $grand_total;
		//$sess['shipping'] 	  = ceil($this->input->post('total_shipamnt'));
		$this->session->set_userdata($sess);
		
		redirect(base_url('order/success'));
		
	}
	
	
	
	public function success()
	{
		$this->cart->destroy();
		if($this->session->userdata('order_placed') !== TRUE)
		{
			redirect('unknown', 'refresh', true);
		}else
		{
		
		    $order_no=$this->session->userdata('odrnmr');
			$get_email = $this->Order_model->get_customer_email($this->session->userdata('active_customer'));
			$to_customer_email = $get_email['email'];
			//$data['order_number'] = $this->session->userdata('odrnmr');
			
			$message_body = $this->load->view('front-end/order_email','',true);
			$config = Array(
				'protocol' => 'smtp',
				'smtp_host' => 'ssl://smtp.googlemail.com',
				'smtp_port' => 465,
				'smtp_user' => 'info@yesbd.com',
				'smtp_pass' => '123#123#',
				'mailtype'  => 'html', 
				'charset'   => 'iso-8859-1',
				'wordwrap' => TRUE
			);

			
			$this->email->set_mailtype("html");
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->from('info@shombhob.com', 'Shombhob.com');
			$this->email->to(array($to_customer_email)); 
			
			//$this->email->bcc(array('akmal110130@gmail.com','akmal@yesbd.com','shuchi@yesbd.com'));
			
			//$this->email->bcc(array('azra.salim@jaysonbd.com','anistarafder@jaysonbd.com'));
			$this->email->bcc(array('azra.salim@shombhob.com'));
			
			//$this->email->bcc('azra64@hotmail.com');
			
			//$this->email->cc('saikatzamanit@gmail.com');
			$this->email->subject('Your Shombhob.com Order'.'('.$order_no.')');
			//$this->email->set_header('MIME-Version', '1.0; charset=utf-8');
			//$this->email->set_header('Content-type', 'text/html');
			$this->email->message($message_body); 
			$this->email->send();
			
		
			
			//$this->session->unset_userdata('shipping_addrss');
			
			/*
			$this->session->unset_userdata('paymethod');
			$this->session->unset_userdata('order_placed');
			$this->session->unset_userdata('payer_order');
			$this->session->unset_userdata('shipping');
			*/
			
			
			
			
			// send phone sms
	 
	 
	 
			$mobile_number = $this->session->userdata('mobile');
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="Thank you for placing an order with us. You will receive a phone call to verify the order verbally. We appreciate your co-operation- Shombhob Team. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$mobile_number.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
    
    		//if(!$output){ $output = file_get_contents($smsgatewaydata); }
    	//	if($return == '1'){ return $output; }else{ echo null; }
			
			
			
			
			
			// send phone sms to Md. Akmal Hossain
	 
			$m1 = '01738279545';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m1.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
			
		
			
			
			
				// send phone sms to IT Manager
	 
			$m2 = '01711664939';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m2.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
    		
    		
    		
    		// send phone sms to Shamsia jafrin shuchi
	 
			$m3 = '01557474198';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m3.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
			
			
			
			
			
			
			
		
			
			
			
			
			
			$data=array();
			
			$data['title']="Yesbd.com Ltd || Order Success";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/orderSuccess',$data);
			$this->load->view('front-end/templates/footer');
			
			$this->session->unset_userdata('address_id');
			$this->session->unset_userdata('delivery_address');
			$this->session->unset_userdata('paymentMethod');
			$this->session->unset_userdata('merchantActive');
			
			
			
			
		}
	}
	
	
	public function fail()
	{
		   // $this->cart->destroy();
		

			$data=array();
			
			$data['title']="Yesbd.com Ltd || Order Success";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/orderFail',$data);
			$this->load->view('front-end/templates/footer');
			
			$this->session->unset_userdata('address_id');
			$this->session->unset_userdata('delivery_address');
			$this->session->unset_userdata('paymentMethod');
			
	}
	
	
	
	
	public function cancel()
	{
		    //$this->cart->destroy();
		

			$data=array();
			
			$data['title']="Shombhob.com Ltd || Order Success";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/orderCancel',$data);
			$this->load->view('front-end/templates/footer');
			
			$this->session->unset_userdata('address_id');
			$this->session->unset_userdata('delivery_address');
			$this->session->unset_userdata('paymentMethod');
			
	}
	
	
	
	
	
	

	
	
	// for payment with ssl commerz
	
	public function request_api_hosted()
	{
	    
	    
	    //echo"Here...";
	    //exit();
	    
	    $grand_total = $this->input->post('grandTotal');
		$deliveryDate = $this->input->post('deliveryDate');
		$deliverySlot = $this->input->post('deliverySlot');
		$payMethod=$this->session->userdata('paymentMethod');
		
		/*
		if($payMethod == 'COD')
		{
			$p_status = 'Processing';
		}else
		{
			$p_status = 'Unpaid';
		}
		*/
		
		$order_data = array(
							'order_customerid'      => $this->session->userdata('active_customer'),
							'order_addressid'       => $this->input->post('address_id'),
							'order_payment_method'  => $payMethod,
							'order_payment_status'  => 'Pending',
							'order_total_amount'    => ceil($this->input->post('cartTotal')),
							//'order_total_vat'       => $this->input->post('total_vat'),
							
							'order_delivery_cost'   =>$this->input->post('delivery_cost'),
							'order_applied_coupon'   =>$this->input->post('coupon_code'),
							'order_coupon_discount'   =>$this->input->post('coupon_discount_amount'),
							'order_grand_total'     => $grand_total,
							'order_delivery_date'   => $deliveryDate,
							'order_delivery_slot'   => $deliverySlot,
							'order_delivery_status' => 'Pending',
							'order_date'            => date('Y-m-d H:i:s'),
					  );
		$get_id 	 = $this->Order_model->save_order($order_data);
		$order_id 	 = $this->db->insert_id($get_id);
		$order_count = $this->Order_model->total_count();
		
		
	    $ord_part=$order_count;
		//Insert mapping
		$mapping = array(
						'mapping_orderid' => $order_id,
						'mapping_day' => date("l"),
						'mapping_month' => date("F"),
					);
		$this->Order_model->insert_mapping($mapping);
		
		
	
		if($ord_part<10)
		{
		    $inv_part='0'.$ord_part;
		}
		else 
		{
		     $inv_part=$ord_part;
		}
		
			$order_number = date("ymd").date("s")."000".$order_count;
		//$order_number = $order_count;
		$inv['invoice_number'] = 'DK'.date("my").$inv_part;
		$inv['invoice_order_id'] = $order_id;
		//$inv['invoice_order_id'] = $order_id;
		$this->Order_model->update_ordernumber($order_id, $order_number);
		$this->Order_model->save_invoice($inv);
		
		
		
		
		
		
		
		//Save order details.
		$order_items = $this->cart->contents();
		foreach($order_items as $item){
			$item_data = array(
						'details_orderid'              => $order_id,
						'details_item_id'              => $item['id'],
						'details_item_quantity'        => $item['qty'],
						'details_item_unitprice'       => $item['price'],
						//'details_item_unitoldprice'	   => $item['old_price'],
						'details_item_subtotal'        => $item['subtotal']
					);
					
					
					
				$productId=$item['id'];
					$p = $this->product_model->getSingleProductInfo($productId);
					foreach($p as $pro)
					{
						
						$pID=$pro->product_id;
						$pQty=$pro->product_quantity;
						$cQty=$item['qty'];
						$uQty=$pQty-$cQty;
						$data=array('product_quantity'=>$uQty);
						$this->product_model->updateSingleProductQtyById($data,$pID);
					}	
					
					
					
		
		$this->Order_model->save_order_details($item_data);
			
		}	
		
		$sess['order_placed'] = TRUE;
		$sess['payer_order']  = $order_id;
		$sess['odrnmr'] 	  = $order_number;
		$sess['order_grand_total'] 	  = $grand_total;
		//$sess['shipping'] 	  = ceil($this->input->post('total_shipamnt'));
		$this->session->set_userdata($sess);
		
		//redirect(base_url('order/success'));
	    
	    
	    
	    
	    
	    
	    
	    
	    
		//if($this->input->get_post('placeorder'))
		//{
		    
			$post_data = array();
			$post_data['total_amount'] = $grand_total;
			//$post_data['total_amount'] = 10;
			$post_data['currency'] = "BDT";
			$post_data['tran_id'] = "SSLC".uniqid();
			$post_data['success_url'] = base_url()."success";
			$post_data['fail_url'] = base_url()."fail";
			$post_data['cancel_url'] = base_url()."cancel";
			$post_data['ipn_url'] = base_url()."ipn";
			#$post_data['multi_card_name'] = "internetbank,mobilebank,othercard,visacard,mastercard,amexcard";
			
			# $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

			# EMI INFO
			// $post_data['emi_option'] = "1";
			// $post_data['emi_max_inst_option'] = "9";
			// $post_data['emi_selected_inst'] = "9";

			# CUSTOMER INFORMATION
			$post_data['cus_name'] = $this->input->post('fname');
			$post_data['cus_email'] = $this->input->post('email');
			$post_data['cus_add1'] = $this->input->post('address');
			$post_data['cus_city'] = $this->input->post('city');
			$post_data['cus_state'] = $this->input->post('state');
			$post_data['cus_postcode'] = $this->input->post('postcode');
			$post_data['cus_country'] = $this->input->post('country');
			$post_data['cus_phone'] = $this->input->post('phone');

			# SHIPMENT INFORMATION
			$post_data['ship_name'] = $this->input->post('fname');
			$post_data['ship_add1'] = $this->input->post('address');
			$post_data['ship_city'] = $this->input->post('city');
			$post_data['ship_state'] = $this->input->post('state');
			$post_data['ship_postcode'] = $this->input->post('postcode');
			$post_data['ship_country'] = $this->input->post('country');

			# OPTIONAL PARAMETERS
			$post_data['value_a'] = "ref001";
			$post_data['value_b'] = "ref002";
			$post_data['value_c'] = "ref003";
			$post_data['value_d'] = "ref004";

			$post_data['product_profile'] = "physical-goods";
			$post_data['shipping_method'] = "YES";
			$post_data['num_of_item'] = $this->input->post('items');
			$post_data['product_name'] = "Pharmacy,Healthcare, Beauty";
			$post_data['product_category'] = "Ecommerce";

			$this->load->library('session');

			$session = array(
				'tran_id' => $post_data['tran_id'],
				'amount' => $post_data['total_amount'],
				'currency' => $post_data['currency']
			);
			$this->session->set_userdata('tarndata', $session);

			echo "<pre>";
			print_r($post_data);
			
			//exit();
			
			if($this->sslcommerz->RequestToSSLC($post_data, SSLCZ_STORE_ID, SSLCZ_STORE_PASSWD))
			{
				echo "Pending";
				
				/***************************************
				# Change your database status to Pending.
				****************************************/
				$status="Pending";
				$orderID = $this->session->userdata('payer_order');
			
				$data=array('order_payment_status'=>$status);
				$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
					
				
				
			}
		//}
	}






	public function success_payment()
	{
	    
	
	    $orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		
		$sesdata = $this->session->userdata('tarndata');

		if(($sesdata['tran_id'] == $_POST['tran_id']) && ($sesdata['amount'] == $_POST['currency_amount']) && ($sesdata['currency'] == 'BDT'))
		{
			if($this->sslcommerz->ValidateResponse($_POST['currency_amount'], $sesdata['currency'], $_POST))
			{
				if(@$database_order_status == 'Pending')
				{
				    
				    
				    //$status="Processing";
				    $status="PAID";
				    $tnxID=$_POST['tran_id'];
					$payChannel=$_POST['card_type'];
					$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID,'paymentChannel'=>$payChannel);
					$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
				   
			        redirect(base_url('order/success'));
		        }
				    
				   
				   
				  redirect(base_url('order/success')); 
				    
				    
					/*****************************************************************************
					# Change your database status to Processing & You can redirect to success page from here
					******************************************************************************/
					echo "Transaction Successful<br>";
					echo "PAID";
					echo "<pre>";
					print_r($_POST);exit;
				}
				else
				{
				    
				    
				    $data=array();
			
        			$data['title']="Shombhob.com Ltd || Order Success";
        			$this->load->view('front-end/templates/header',$data);
        			$this->load->view('front-end/orderSuccess',$data);
        			$this->load->view('front-end/templates/footer');
        			
        			
        			$this->session->unset_userdata('delivery_address');
        			$this->session->unset_userdata('paymentMethod');
				    
				    
					/******************************************************************
					# Just redirect to your success page status already changed by IPN.
					******************************************************************/
					echo "Just redirect to your success page";
				}
			}
		}
		
		
		
		
	
	public function fail_payment()
	{
	    //$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
	    $orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		if($database_order_status == 'Pending')
		{
		    
		    $status="FAILED";
		    $tnxID=$_POST['tran_id'];
			$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID);
			$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
			
		    redirect(base_url('order/fail'));
		    
			/*****************************************************************************
			# Change your database status to FAILED & You can redirect to failed page from here
			******************************************************************************/
			echo "<pre>";
			print_r($_POST);
			echo "Transaction Faild";
		}
		else
		{
			/******************************************************************
			# Just redirect to your success page status already changed by IPN.
			******************************************************************/
			echo "Just redirect to your failed page";
			
			redirect(base_url('order/fail'));
		}	
	}
	public function cancel_payment()
	{
		//$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
		$orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		
		if(@$database_order_status == 'Pending' || @$database_order_status == 'Unpaid' )
		{
		    
		    
		    $status="CANCELLED";
		    $tnxID=$_POST['tran_id'];
			$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID);
			$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
			
		    redirect(base_url('order/cancel'));
		    
		    
			/*****************************************************************************
			# Change your database status to CANCELLED & You can redirect to cancelled page from here
			******************************************************************************/
		
		/*
		
			echo "<pre>";
			print_r($_POST);
			echo "Transaction Canceled";
			
		*/	
			
			
		}
		else
		{
			/******************************************************************
			# Just redirect to your cancelled page status already changed by IPN.
			******************************************************************/
			redirect(base_url('order/cancel'));
			
			echo "Just redirect to your failed page";
		}
	}
	public function ipn_listener()
	{
		$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
		$store_passwd = SSLCZ_STORE_PASSWD;
		if($ipn = $this->sslcommerz->ipn_request($store_passwd, $_POST))
		{
			if(($ipn['gateway_return']['status'] == 'VALIDATED' || $ipn['gateway_return']['status'] == 'VALID') && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS')
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'Processing'.
					******************************************************************************/
				}
			}
			elseif($ipn['gateway_return']['status'] == 'FAILED' && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS')
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'FAILED'.
					******************************************************************************/
				}
			}
			elseif ($ipn['gateway_return']['status'] == 'CANCELLED' && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS') 
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'CANCELLED'.
					******************************************************************************/
				}
			}
			else
			{
				if($database_order_status == 'Pending')
				{
					echo "Order status not ".$ipn['gateway_return']['status'];
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'FAILED'.
					******************************************************************************/
				}
			}
			echo "<pre>";
			print_r($ipn);
		}
	}
	

	
	
	
	// Below are the functions for performing re-order or re-payment
	// Function for re-order page
	
	public function re_order($order_id)
	{
		    //$this->cart->destroy();
		
			$data=array();
		    $OrderSummary=$this->customer_model->fetchCustomerOrderByOrderId($order_id);
		    $data['orderInfo']=$this->customer_model->fetchCustomerOrderByOrderId($order_id);
            //$data['cusOrderDetails']=$this->customer_model->fetchCustomerOrderDetailsById($orderID);
           
           /* foreach($OrderSummary as $s)
            {
                $addressID=$s->order_addressid;
            }
            */
           $addressID=$OrderSummary['order_addressid'];
           $data['addressInfo']=$this->customer_model->fetchCustomerDeliveryAddressByAddressId($addressID);
           
           $data['cusOrderDetails']=$this->customer_model->fetchCustomerOrderDetailsById($order_id);
			$data['title']="Yesbd.com Ltd || Re-Order page";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/reorder',$data);
			$this->load->view('front-end/templates/footer');
			
	}	
		
	
	
	

	
	
	// for payment with ssl commerz
	
	public function request_api_hosted1()
	{
	    
	    $order_number   = $this->input->post('order_number');
	    $order_id       = $this->input->post('order_id');
	   $cus_email       = $this->input->post('email');
	   $cus_phone       = $this->input->post('phone');
	   
	   //exit();
	    
	    $grand_total    = $this->input->post('grandTotal');
		
		
		$sess['order_repayment'] = TRUE;
		$sess['payer_order']  = $order_id;
		$sess['cus_phone']  = $cus_phone;
		$sess['odrnmr'] 	  = $order_number;
		$sess['customer_email'] =$cus_email;
		$sess['order_grand_total'] 	  = $grand_total;
		//$sess['shipping'] 	  = ceil($this->input->post('total_shipamnt'));
		$this->session->set_userdata($sess);
		
		//redirect(base_url('order/success'));
	    
	    
	    
		//if($this->input->get_post('placeorder'))
		//{
		    
			$post_data = array();
			$post_data['total_amount'] = $grand_total;
			$post_data['currency'] = "BDT";
			$post_data['tran_id'] = "SSLC".uniqid();
			$post_data['success_url'] = base_url()."success1";
			$post_data['fail_url'] = base_url()."fail1";
			$post_data['cancel_url'] = base_url()."cancel1";
			$post_data['ipn_url'] = base_url()."ipn1";
			#$post_data['multi_card_name'] = "internetbank,mobilebank,othercard,visacard,mastercard,amexcard";
			
			# $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

			# EMI INFO
			// $post_data['emi_option'] = "1";
			// $post_data['emi_max_inst_option'] = "9";
			// $post_data['emi_selected_inst'] = "9";

			# CUSTOMER INFORMATION
			$post_data['cus_name'] = $this->input->post('fname');
			$post_data['cus_email'] = $this->input->post('email');
			$post_data['cus_add1'] = $this->input->post('address');
			$post_data['cus_city'] = $this->input->post('city');
			$post_data['cus_state'] = $this->input->post('state');
			$post_data['cus_postcode'] = $this->input->post('postcode');
			$post_data['cus_country'] = $this->input->post('country');
			$post_data['cus_phone'] = $this->input->post('phone');

			# SHIPMENT INFORMATION
			$post_data['ship_name'] = $this->input->post('fname');
			$post_data['ship_add1'] = $this->input->post('address');
			$post_data['ship_city'] = $this->input->post('city');
			$post_data['ship_state'] = $this->input->post('state');
			$post_data['ship_postcode'] = $this->input->post('postcode');
			$post_data['ship_country'] = $this->input->post('country');

			# OPTIONAL PARAMETERS
			$post_data['value_a'] = "ref001";
			$post_data['value_b'] = "ref002";
			$post_data['value_c'] = "ref003";
			$post_data['value_d'] = "ref004";

			$post_data['product_profile'] = "physical-goods";
			$post_data['shipping_method'] = "YES";
			$post_data['num_of_item'] = $this->input->post('items');
			$post_data['product_name'] = "Pharmacy,Healthcare, Beauty";
			$post_data['product_category'] = "Ecommerce";

			$this->load->library('session');

			$session = array(
				'tran_id' => $post_data['tran_id'],
				'amount' => $post_data['total_amount'],
				'currency' => $post_data['currency']
			);
			$this->session->set_userdata('tarndata', $session);

			echo "<pre>";
			print_r($post_data);
			
			//exit();
			
			if($this->sslcommerz->RequestToSSLC($post_data, SSLCZ_STORE_ID, SSLCZ_STORE_PASSWD))
			{
				echo "Pending";
				
				/***************************************
				# Change your database status to Pending.
				****************************************/
				$status="Pending";
				$orderID = $this->session->userdata('payer_order');
			
				$data=array('order_payment_status'=>$status);
				$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
					
				
				
			}
		//}
	}






	public function success_payment1()
	{
	    
	
	    $orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		
		$sesdata = $this->session->userdata('tarndata');

		if(($sesdata['tran_id'] == $_POST['tran_id']) && ($sesdata['amount'] == $_POST['currency_amount']) && ($sesdata['currency'] == 'BDT'))
		{
			if($this->sslcommerz->ValidateResponse($_POST['currency_amount'], $sesdata['currency'], $_POST))
			{
				if($database_order_status == 'Pending' || $database_order_status == 'Cancel' || $database_order_status == 'CANCELLED'|| $database_order_status == 'Processing')
				{
				    
				    
				    //$status="Processing";
				    $status="PAID";
				    $tnxID=$_POST['tran_id'];
					$payChannel=$_POST['card_type'];
					$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID,'paymentChannel'=>$payChannel);
					$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
				   
			        redirect(base_url('order/success1'));
		        }
				    
				    
				    
					/*****************************************************************************
					# Change your database status to Processing & You can redirect to success page from here
					******************************************************************************/
					//echo "Transaction Successful<br>";
					//echo "PAID";
					//echo "<pre>";
					//print_r($_POST);exit;
				//	redirect(base_url('order/success1'));
				}
				else
				{
				    
				    
				    $data=array();
			
        			$data['title']="Yesbd.com Ltd || Order Success";
        			$this->load->view('front-end/templates/header',$data);
        			$this->load->view('front-end/orderSuccess',$data);
        			$this->load->view('front-end/templates/footer');
        			
        			$this->session->unset_userdata('address_id');
        			$this->session->unset_userdata('delivery_address');
        			$this->session->unset_userdata('paymentMethod');
				    
				    
					/******************************************************************
					# Just redirect to your success page status already changed by IPN.
					******************************************************************/
					echo "Just redirect to your success page";
				}
			}
		}
		
		
		
		
	
	public function fail_payment1()
	{
	    //$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
	    $orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		if($database_order_status == 'Pending')
		{
		    
		    $status="FAILED";
		    $tnxID=$_POST['tran_id'];
			$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID);
			$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
			
		    redirect(base_url('order/fail'));
		    
			/*****************************************************************************
			# Change your database status to FAILED & You can redirect to failed page from here
			******************************************************************************/
			echo "<pre>";
			print_r($_POST);
			echo "Transaction Faild";
		}
		else
		{
			/******************************************************************
			# Just redirect to your success page status already changed by IPN.
			******************************************************************/
			echo "Just redirect to your failed page";
			
			redirect(base_url('order/fail'));
		}	
	}
	public function cancel_payment1()
	{
		//$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
		$orderID = $this->session->userdata('payer_order');
	    
	    $order_info=$this->customer_model->fetchCustomerOrderSummaryById($orderID);
	    foreach($order_info as $order)
	    {
		$database_order_status =$order->order_payment_status ; // Check this from your database here Pending is dummy data,
		
	    }
		
		
		if($database_order_status == 'Pending' || $database_order_status == 'CANCELLED')
		{
		    
		    
		    $status="CANCELLED";
		    $tnxID=$_POST['tran_id'];
			$data=array('order_payment_status'=>$status,'order_payment_trnx_id'=>$tnxID);
			$update=$this->customer_model->updatePaymentStatusData($orderID,$data);
			
		    redirect(base_url('order/cancel'));
		    
		    
			/*****************************************************************************
			# Change your database status to CANCELLED & You can redirect to cancelled page from here
			******************************************************************************/
		
		/*
		
			echo "<pre>";
			print_r($_POST);
			echo "Transaction Canceled";
			
		*/	
			
			
		}
		else
		{
			/******************************************************************
			# Just redirect to your cancelled page status already changed by IPN.
			******************************************************************/
			redirect(base_url('order/cancel'));
			
			echo "Just redirect to your failed page";
		}
	}
	public function ipn_listener1()
	{
		$database_order_status = 'Pending'; // Check this from your database here Pending is dummy data,
		$store_passwd = SSLCZ_STORE_PASSWD;
		if($ipn = $this->sslcommerz->ipn_request($store_passwd, $_POST))
		{
			if(($ipn['gateway_return']['status'] == 'VALIDATED' || $ipn['gateway_return']['status'] == 'VALID') && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS')
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'Processing'.
					******************************************************************************/
				}
			}
			elseif($ipn['gateway_return']['status'] == 'FAILED' && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS')
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'FAILED'.
					******************************************************************************/
				}
			}
			elseif ($ipn['gateway_return']['status'] == 'CANCELLED' && $ipn['ipn_result']['hash_validation_status'] == 'SUCCESS') 
			{
				if($database_order_status == 'Pending')
				{
					echo $ipn['gateway_return']['status']."<br>";
					echo $ipn['ipn_result']['hash_validation_status']."<br>";
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'CANCELLED'.
					******************************************************************************/
				}
			}
			else
			{
				if($database_order_status == 'Pending')
				{
					echo "Order status not ".$ipn['gateway_return']['status'];
					/*****************************************************************************
					# Check your database order status, if status = 'Pending' then chang status to 'FAILED'.
					******************************************************************************/
				}
			}
			echo "<pre>";
			print_r($ipn);
		}
	}
	
	
	
	
public function success1()
	{
	    
		//$this->cart->destroy();
		if($this->session->userdata('order_repayment') !== TRUE)
		{
			redirect('unknown', 'refresh', true);
		}
		else
		{
		    
	   
		
		    $order_no=$this->session->userdata('odrnmr');
			//$get_email = $this->Order_model->get_customer_email($this->session->userdata('active_customer'));
			$to_customer_email = $this->session->userdata('customer_email');
			$cus_phone = $this->session->userdata('cus_phone');
			
			//$data['order_number'] = $this->session->userdata('odrnmr');
			
			$message_body = $this->load->view('front-end/order_email','',true);
			$config = Array(
				'protocol' => 'smtp',
				'smtp_host' => 'ssl://smtp.googlemail.com',
				'smtp_port' => 465,
				'smtp_user' => 'info@yesbd.com',
				'smtp_pass' => '123#123#',
				'mailtype'  => 'html', 
				'charset'   => 'iso-8859-1',
				'wordwrap' => TRUE
			);

			
			$this->email->set_mailtype("html");
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->from('info@yesbd.com', 'Yesbd.com');
			$this->email->to(array($to_customer_email)); 
			
			//$this->email->bcc(array('akmalhossain307@gmail.com','akmal@yesbd.com','shuchi@yesbd.com'));
			
			
			
				//$this->email->bcc(array('azra.salim@jaysonbd.com','anistarafder@jaysonbd.com'));
			$this->email->bcc(array('order@yesbd.com'));
			
			//$this->email->bcc('azra64@hotmail.com');
			
			//$this->email->cc('saikatzamanit@gmail.com');
			$this->email->subject('Your Yesbd.com Order'.'('.$order_no.')');
			//$this->email->set_header('MIME-Version', '1.0; charset=utf-8');
			//$this->email->set_header('Content-type', 'text/html');
			$this->email->message($message_body); 
			$this->email->send();
			
		
			
			//$this->session->unset_userdata('shipping_addrss');
			
			/*
			$this->session->unset_userdata('paymethod');
			$this->session->unset_userdata('order_placed');
			$this->session->unset_userdata('payer_order');
			$this->session->unset_userdata('shipping');
			*/
			
			
			
			
			// send phone sms
	 
	 
	 
			$mobile_number = $cus_phone;
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="Thank you for placing an order with us. You will receive a phone call to verify the order verbally. We appreciate your co-operation- Yesbd Team. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$mobile_number.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
    
    		//if(!$output){ $output = file_get_contents($smsgatewaydata); }
    	//	if($return == '1'){ return $output; }else{ echo null; }
			
			
			
			
			
			// send phone sms to Md. Akmal Hossain
	 
			$m1 = '01738279545';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m1.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
			
			
			
			
			
			
			
				// send phone sms to IT Manager
	 
			$m2 = '01711664939';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m2.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
    		
    		
    		
    		// send phone sms to Shamsia jafrin shuchi
	 
			$m3 = '01557474198';
			$order_number = $this->session->userdata('odrnmr');
			
			$message_body="An order has been placed in yesbd.com. Order No:".$order_number.' and Total Order Amount TK:'.number_format($this->session->userdata('order_grand_total'), 2);

    		$sender= 'yesbd.com'; // Need to change
    
    		$smsGatewayUrl = 'https://api.mobireach.com.bd/SendTextMessage';
    
    		$user = 'jayson'; // Need to change
    		$password = 'Abcd@321'; // Need to change
    
    		//$api_params = 'SendTextMessage'.'?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$number.'&Message='.urlencode($message_body)';
    		
    		$api_params ='?Username='.$user.'&Password='.$password.'&From='.$sender.'&To='.$m3.'&Message='.urlencode($message_body);
    		
    
            $smsgatewaydata = $smsGatewayUrl.$api_params;
    		$url = $smsgatewaydata;
    
    		$ch = curl_init();
    
    		curl_setopt($ch, CURLOPT_POST, false);
    
    		curl_setopt($ch, CURLOPT_URL, $url);
    
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $output = curl_exec($ch);
    
    		curl_close($ch);
			
			
			
			$data=array();
			
			$data['title']="Yesbd.com Ltd || Order Success";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/orderSuccess',$data);
			$this->load->view('front-end/templates/footer');
			
			$this->session->unset_userdata('address_id');
			$this->session->unset_userdata('delivery_address');
			$this->session->unset_userdata('paymentMethod');
			$this->session->unset_userdata('merchantActive');
			
			
			
		}	
		
	}
	
	
	
		 
}

?>