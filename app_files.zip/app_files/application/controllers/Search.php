<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('search_model');
		$this->load->library('cart');
		//$this->output->cache(720);
	}
	

	public function index()
	{
		$data=array();
		$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/search');
		$this->load->view('front-end/templates/footer');
	}
	
// Search option for user entered searched keywords...
	public function productSearch()
	{
		$data=array();
		$keyword=$this->input->get('search_data');
		
		
		if($keyword==null || $keyword=="")
		{
			$data['emptyKeyword']="You didn't type anything. Please type something then search again.";
			$data['title']="Yesbd.com Ltd";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/search',$data);
			$this->load->view('front-end/templates/footer');
		}
		else 
		{
		    
		    $searchKeywords = array(
			'keywords' => $keyword
			);
			$this->search_model->saveSearchKeyword($searchKeywords);
			$data['searchedProducts']=$this->search_model->searchByKeyword($keyword);
			$data['title']="Yesbd.com Ltd";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/search',$data);
			$this->load->view('front-end/templates/footer');
		}
	}
	
	
	// for autocomplete search option
	public function fetch()
	{
		
	  //$this->load->model('autocomplete_model');
	  //echo $this->Qbuilder_model->fetch_data($this->uri->segment(3));
	  //echo $this->Qbuilder_model->fetch_data($this->uri->segment(3));
	 echo $this->search_model->fetch_data($this->uri->segment(3));
	}
	
	
	
	public function fetchSearchResult()
		 {
		  //$output = '';
		  $query = '';
		  
		  if($this->input->get('query'))
		  {
		   $query = $this->input->get('query');
		  }
		  $data = $this->search_model->fetch_search_data($query);
		  
		  
		  if($data->num_rows() > 0)
		  {
		   foreach($data->result() as $row)
		   {
			   /*
			$output .= '
			  <tr>
			   <td>'.$row->CustomerName.'</td>
			   <td>'.$row->Address.'</td>
			   <td>'.$row->City.'</td>
			   <td>'.$row->PostalCode.'</td>
			   <td>'.$row->Country.'</td>
			  </tr>
			';
			*/
			?>
			<div class="col-lg-4 col-sm-6">
				<div class="l_product_item">
					<div class="l_p_img">
						<img src="<?php //echo base_url('assets/front-end/images/product/'.$row->product_image);?>" alt="">
						
						<a title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$row->product_id;?>"> <img src="<?php echo base_url().$row->productImage;?>" alt=""> </a>
						 <?php 
								$att=$row->attribute;
								if($att=="prescription_needed")
								{
									echo"<h5 class='sale'>Prescription Needed</h5>";
								}
								else if($att=="featured")
								{
								echo"<h5 class='sale'>Featured</h5>";	
								}else if($att=="hot")
								{
								echo"<h5 class='new'>Hot</h5>";	
								}else if($att=="normal")
								{
								echo"<h5 class='new'>Hot</h5>";	
								}else if($att=="new")
								{
								echo"<h5 class='new'>Hot</h5>";	
								}
								?>
					</div>
					<div class="l_p_text">
					   <ul>
							<li class="p_icon"><a  title="Click to View Details" class="quick-view modal-view detail-link" href="<?php echo base_url('productDetails/').$row->product_id;?>"><span class="ti-plus"></span></a></li>
							<li>
							
							
							
							
							
							
							
							<form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">	
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>	
										
							<input type="hidden"name="currentURL" value="<?php echo$currentURL;?>"/>
							<input type="hidden"name="product_id" value="<?php echo$row->product_id;?>"/>
							<input type="hidden"name="product_name" value="<?php echo$row->title;?>"/>
							<input type="hidden"name="product_price" value="<?php			
													if($row->discountPrice)
													{
													$price=$row->discountPrice;
													}
													else 
													{
													$price=$row->price;	
													}
										echo$price;?>"/>
							<input type="hidden"name="product_old_price" value="<?php echo$row->price;?>"/>
							<input type="hidden"name="quantity" value="1"/>
							<input type="hidden"name="product_image" value="<?php echo$row->productImage;?>"/>
							
							<input class="add_cart_btn" type="submit" value="Add To Cart" />
							
							</form>
							
							
							
							
							
							
							<!--<button class="add_cart_btn">Add To Cart</button>
							-->
						
							
							</li>
							<li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
						</ul>
						<h4><?php echo$row->title;?></h4>
						<p><?php echo$row->measuringType;?></p>
						<h6><span>Price:</span> 
												
							<?php if($row->discountPrice)
							{
							?>	
							
							
							<del style="color:red">TK <?php echo $row->price;?></del> TK <?php echo$row->discountPrice;
							}
							else 
							{
								?>
								TK  <?php echo$row->price;?>
							
							<?php 
							}
							?>
							
							</h6>
					</div>
				</div>
			</div>
			
			<?php 
			
			
		   }
		  }
		  else
		  {
		   echo"No product found matching your search criteria.<br/><br/><br/>";
		   
		   
		   ?>
		   
		   <div class="row"> 
			<div class="col-md-10"> 
			<h2 class="text text-info">Send Product Request</h2> <br />
				<form action="<?php echo base_url('search/productRequest')?>" method="POST">
				  <div class="form-group">
					<label for="exampleFormControlInput1">Name</label>
					<input type="text" name="name"class="form-control" id="exampleFormControlInput1" placeholder="enter your name" required>
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1">Phone Number</label>
					<input type="text" name="phone"class="form-control" id="exampleFormControlInput1" placeholder="enter your phone number" required >
				  </div>
				  <div class="form-group">
					<label for="exampleFormControlInput1">Email(Optional)</label>
					<input type="email" name="email"class="form-control" id="exampleFormControlInput1" placeholder="enter email">
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Address</label>
					<textarea class="form-control" name="address"id="exampleFormControlTextarea1" rows="3" required></textarea>
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Product Request</label>
					<textarea class="form-control" name="productName"id="exampleFormControlTextarea1"rows="3" required > </textarea>
				  </div>
				  
				  <div class="text-left"> 
				  <input type="submit" class="btn btn-success btn-lg" value="Send Request" />
				  </div>
				</form>
				<br />
				<br />
			</div>
		   </div>
		   
		   <?php
		   
		  }
				
		  
		 }
		 
		 
	// Save customer's product request
	public function saveProductRequest()
	{
		$name		=$this->input->post('name');
		$phone		=$this->input->post('phone');
		$email		=$this->input->post('email');
		$address	=$this->input->post('address');
		$productName=$this->input->post('productName');
			
			$data = array(
			'name' => $name,
			'phone' => $phone,
			'email' => $email,
			'address' => $address,
			'address' => $address,
			'productName' => $productName,	
			);
			$insert=$this->search_model->saveProductRequestData($data);
			if($insert == true) {
				
				?>
				
				<script>
				alert('Product request sent successfully!');
				
				window.location='<?php echo base_url();?>';
				</script>
				
				<?php 
        	}
        	else {
        	
			?>
				<script>
				alert('Product request sending fail! Please try again.');
				
				window.location='<?php echo base_url();?>';
				</script>
				<?php
				
        	}
	}
	
	// Save subscriber's email
	public function saveSubscriber()
	{
		$email		=$this->input->post('email');
		
			
			$data = array(
			'email' => $email,	
			);
			$insert=$this->search_model->saveSubscriberData($data);
			if($insert == true) {
				
				?>
				
				<script>
				alert('Thanks! Your subscription is complete.');
				
				window.location='<?php echo base_url();?>';
				</script>
				
				<?php 
        	}
        	else {
        	
			?>
				<script>
				alert('Sorry! your subscription is failed. Please try again.');
				
				window.location='<?php echo base_url();?>';
				</script>
				<?php
				
        	}
	}
	
	
	public function fetchOfferByCategory()
		 {
			 
			if(isset($_POST["category_id"]))  
			 {
				echo$cat=$_POST["category_id"];
				exit();
			 }	 
			 
		  //$output = '';
		  $cat = '';
		  
		  if($this->input->get('category'))
		  {
		   $cat = $this->input->get('category');
		  }
		  $data = $this->search_model->fetch_filter_data($cat);
		  
		  if($data->num_rows() > 0)
		  {
		   foreach($data->result() as $offer)
		   {
			   
			   echo"Category products...";
			?>
			<div class="col-lg-6 col-sm-6">
				<div class="l_product_item">
					<div class="l_p_img">
					<?php $imgURL=$offer->productImage;?>
						<img src="<?php echo base_url().$imgURL?>" alt="">
						
						<?php 
						$att=$offer->attribute;
						if($att=="prescription_needed")
						{
							echo"<h5 class='sale'>Prescription Needed</h5>";
						}
						else if($att=="new")
						{
							echo"<h5 class='new'>New</h5>";
						}
						else 
						{
						echo"<h5 class='new'>New</h5>";	
						}
						?>
					  
						
					</div>
					<div class="l_p_text">
					   <ul>
							<li class="p_icon"><a data-toggle="modal" data-target="#productModal" title="Quick View" class="quick-view modal-view detail-link" href="#"><span class="ti-plus"></span></a></li>
							<li><a class="add_cart_btn" href="#">Add To Cart</a></li>
							<li class="p_icon"><a href="#" title="Wishlist"><i class="icon_heart_alt"></i></a></li>
						</ul>
						<h4><?php echo$offer->title;?></h4>
						<h6><span>Price:</span> 
						<?php 
						$price=$offer->price;
						$discount=$offer->discountPrice;
						if($discount){
							echo"<del>TK $price</del>";
						}
							?>
						  TK <?php echo$discount;?></h6>
					</div>
				</div>
			</div>
			
			<?php 
		   }
		   
		  }
		  else
		  {
		   echo"Sorry!No product offer today in this category.<br/><br/><br/>";
		   
		   
		  }
		  
		 }
		 
		 
		 
		 
		 public function autocomplete()
			{
				 // load model
				 //$this->load->model('Welcome_model');

				 $search_data = $this->input->post('search_data');

				 $result = $this->search_model->get_autocomplete($search_data);

				 if (!empty($result))
				 {
					 foreach ($result as $row):
					 ?>
					 <li> 
					 
					  <form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">
					 <?php
					 $this->load->model('Product_model');
					 $get_default_photo = $this->Product_model->get_default_photo($row->product_id);
					$proImage = $get_default_photo['image_url'];
					 ?>
					 
					 <img src="<?php echo base_url().$proImage;?>" width="70px" height="40px"alt="<?php echo $row->title;?>" />
					 
					 	
					 <a href='<?php echo base_url().$row->slug;?>'><?php echo $row->title;?> (<?php echo$row->measuringType;?>) <?php if($row->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $row->price;?></del> TK <?php echo$row->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$row->price;?>
												
												<?php 
												}
												?>   &nbsp;&nbsp;&nbsp; 
					 
					 </a>
					
					 <a style="color:white"href="<?php echo base_url().$row->slug;?>" class="btn btn-warning btn-sm">Details</a>
					 
					
					


					
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>	
										
							<input type="hidden"name="currentURL" value="<?php echo$currentURL;?>"/>
							<input type="hidden"name="product_id" value="<?php echo$row->product_id;?>"/>
							<input type="hidden"name="product_name" value="<?php echo$row->title;?>"/>
							<input type="hidden"name="product_price" value="<?php			
													if($row->discountPrice)
													{
													$price=$row->discountPrice;
													}
													else 
													{
													$price=$row->price;	
													}
										echo$price;?>"/>
							<input type="hidden"name="product_old_price" value="<?php echo$row->price;?>"/>
							<input type="hidden"name="quantity" value="1"/>
							
							<input type="hidden"name="product_image" value="<?php echo base_url().$proImage;?>"/>
							
							<?php $pres=$row->product_need_prescription;
							if($pres==1)
							{
							?>
							
<!-- Button trigger modal -->

<!--
<a href="#prescriptionUploadModal" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary btn-sm" data-toggle="modal">Add to Bag</a>
-->
						
							
	<a href="<?php echo base_url('').$row->slug;?>" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary btn-sm" >Add to Bag</a>				
							
							
							
							
							
							<?php 
							}
							else 
							{
								?>
								
								<?php
        									$qty=$row->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
        									    
        									    <span style="color:red;font-size:18px">Product Out of stock</span>
								
								<input class="btn btn-primary btn-sm disabled" type="text" value="Add To Bag" title="Product Out of Stock" />
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									  <input class="btn btn-primary btn-sm " type="submit" value="Add To Bag" />
        									    <?php 
        									}
								
								?>
								
								
								
								<?php 
							}
							?>
							
							</form>
					 
					 
					 
					 
					
					 
					 
					 </li>
					 
					 <?php 
					    
					  endforeach;
				 }
				 else
				 {
					   echo "<li> <em style='color:red'> No product found matching your search keyword... </em> </li>";
					   ?>
					   
					   
			<!--		   
			<li>		   
	
			 
			<h2 class="text text-info">Send Product Request</h2>
				<form action="<?php //echo base_url('search/productRequest')?>" method="POST">
			
				  <div class="form-group">
					<label for="exampleFormControlInput1">Name</label>
					<input type="text" size="10"name="name"class="form-control" id="exInput" placeholder="name" required>
				  </div>
				  <div class="form-group">
				  
					<label for="exampleFormControlTextarea1">Phone Number</label>
					 
					<input type="text" name="phone"class="form-control" id="exInput" placeholder="phone number" required >
					
				</div>
				 
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Address</label>
					<textarea class="form-control" name="address"id="exampleFormControlTextarea1" rows="1" required></textarea>
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Product Request</label>
					<textarea class="form-control" name="productName"id="exampleFormControlTextarea1"rows="1" required > </textarea>
				  </div>
				  
				  <div class="text-left"> 
				  <input type="submit" class="btn btn-success btn-lg" value="Send Request" />
				  </div>
			
				  
				</form>
				
		 
		   </li>
		   
		   -->
					   
					   <?php 
					   
					   
				 }
			 }
			 
			 
		// searching for mobile devices	 
		public function autocomplete1()
			{
				 // load model
				 //$this->load->model('Welcome_model');

				 $search_data = $this->input->post('search_data1');

				 $result = $this->search_model->get_autocomplete1($search_data);

				 if (!empty($result))
				 {
					 foreach ($result as $row):
					 ?>
					 <li> 
					 
					  <form action="<?php echo base_url('product/add');?>" method="POST" enctype="multipart/form-data">
					 <?php
					 $this->load->model('Product_model');
					 $get_default_photo = $this->Product_model->get_default_photo($row->product_id);
					$proImage = $get_default_photo['image_url'];
					 ?>
					 
					 <img src="<?php echo base_url().$proImage;?>" width="70px" height="40px"alt="<?php echo $row->title;?>" />
					 
					 
					 
					
	
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 <a href='<?php echo base_url('product/').$row->slug;?>'><?php echo $row->title;?> (<?php echo$row->measuringType;?>) <?php if($row->discountPrice)
												{
												?>	
												
												
												<del style="color:red">TK <?php echo $row->price;?></del> TK <?php echo$row->discountPrice;
												}
												else 
												{
													?>
													TK  <?php echo$row->price;?>
												
												<?php 
												}
												?>   &nbsp;&nbsp;&nbsp; 
					 
					 </a>
					
					 <a style="color:white"href="<?php echo base_url().$row->slug;?>" class="btn btn-warning btn-sm">Details</a>
					 
					
					


					
										<?php 
										$this->load->helper('url');
										$currentURL = current_url();
										
										?>	
										
							<input type="hidden"name="currentURL" value="<?php echo$currentURL;?>"/>
							<input type="hidden"name="product_id" value="<?php echo$row->product_id;?>"/>
							<input type="hidden"name="product_name" value="<?php echo$row->title;?>"/>
							<input type="hidden"name="product_price" value="<?php			
													if($row->discountPrice)
													{
													$price=$row->discountPrice;
													}
													else 
													{
													$price=$row->price;	
													}
										echo$price;?>"/>
							<input type="hidden"name="product_old_price" value="<?php echo$row->price;?>"/>
							<input type="hidden"name="quantity" value="1"/>
							
							<input type="hidden"name="product_image" value="<?php echo base_url().$proImage;?>"/>
							
							
							
							
							<?php $pres=$row->product_need_prescription;
							if($pres==1)
							{
							   
							   ?>
							   <!--
							    <a style="color:white"href="<?php //echo base_url().$row->slug;?>" class="btn btn-warning btn-sm">Details</a>
							   -->
							   <a href="<?php echo base_url().$row->slug;?>" style="color:white"title="This medicine need prescription to buy!" class="btn btn-primary btn-sm" >Add to Bag</a>
							   
							   
							   <?php 
							    
							}
							else
							{
							?>
							
							
							
							<?php
        									$qty=$row->product_quantity;
        									if($qty<=0)
        									{
        									    ?>
        									    
        									    <span style="color:red;font-size:18px">Product Out of stock</span>
								
								<input class="btn btn-primary btn-sm disabled" type="text" value="Add To Bag" title="Product Out of Stock" />
								<?php 
        									}
        									else 
        									{
        									    
        									    ?>
        									    
        									  <input class="btn btn-primary btn-sm " type="submit" value="Add To Bag" />
        									    <?php 
        									}
        									
							}
								
								?>
							
							
							
							</form>
					 
					 
					 
					 
					
					 
					 
					 </li>
					 
					 <?php 
					    
					  endforeach;
				 }
				 else
				 {
					   echo "<li> <em style='color:red'> No product found matching your search keyword... </em> </li>";
					   ?>
			<li>		   
	
			 
			<h2 class="text text-info">Send Product Request</h2>
				<form action="<?php echo base_url('search/productRequest')?>" method="POST">
			
				  <div class="form-group">
					<label for="exampleFormControlInput1">Name</label>
					<input type="text" size="10"name="name"class="form-control" id="exInput" placeholder="name" required>
				  </div>
				  <div class="form-group">
				  
					<label for="exampleFormControlTextarea1">Phone Number</label>
					 
					<input type="text" name="phone"class="form-control" id="exInput" placeholder="phone number" required >
					
				</div>
				 
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Address</label>
					<textarea class="form-control" name="address"id="exampleFormControlTextarea1" rows="1" required></textarea>
				  </div>
				  
				  <div class="form-group">
					<label for="exampleFormControlTextarea1">Product Request</label>
					<textarea class="form-control" name="productName"id="exampleFormControlTextarea1"rows="1" required > </textarea>
				  </div>
				  
				  <div class="text-left"> 
				  <input type="submit" class="btn btn-success btn-lg" value="Send Request" />
				  </div>
			
				  
				</form>
				
		 
		   </li>
					   
					   <?php 
					   
					   
				 }
			 }
	
	
	
	
	
}
