<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Dashboard_model');
		//$this->load->library('cart');
		
	
	//$this->output->cache(720);
	
		
	}
	

	public function index()
	{
	    $login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('admin'));
		}
		else 
		{
		    $data=array();
    		$data['title']="Shombhob.com Admin Panel";
    		$this->load->view('back-end/templates/header',$data);
    		$this->load->view('back-end/dashboard',$data);
    		$this->load->view('back-end/templates/footer');
		}
		
	}
	
	public function login()
	{
		$data=array();
		$data['title']="Shombhob.com Admin Panel";
		//$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/admin/login',$data);
		//$this->load->view('back-end/templates/footer');
	}
	
	public function logout(){ 
        $this->session->unset_userdata('isAdminLoggedIn'); 
        $this->session->sess_destroy(); 
        redirect(base_url('admin')); 
    } 
    
    
    public function checkLogin(){ 
      
      
		$this->load->model('user');
		$user= $this->input->post('username');
		$pass= md5($this->input->post('password'));
	
//	exit();
	
		$checkUser=$this->user->checkWebsiteUser($user,$pass);
		//$checkUser['user_name']."".$checkUser['password'].$checkUser['user_role'];
		$user_info=$checkUser['user_role'];

		if($checkUser==TRUE)
       {
           //$this->session->set_userdata('isUserLoggedIn', TRUE);
           $this->session->set_userdata('isAdminLoggedIn',true);
           $this->session->set_userdata('user_role',$user_info);
           redirect(base_url('dashboard'));
       }
       else 
       {
           $this->session->set_flashdata('adminLoginError','Username or Password is incorrect!');
			
		    redirect(base_url('admin')); 
       }
	     
    }
    
    
	
	/*
	public function checkLogin(){ 
      
      if($_POST['login'])
      {
      
       $user= $this->input->post('username');
       $pass= $this->input->post('password');
       
       if($user=="admin@yesbd.com" && $pass=="Admin@2020")
       {
           //$this->session->set_userdata('isUserLoggedIn', TRUE);
           $this->session->set_userdata('isAdminLoggedIn',true);
           redirect(base_url('dashboard'));
       }
       else 
       {
           $this->session->set_flashdata('adminLoginError','Username or Password is incorrect!');
			
		    redirect(base_url('yesAdmin')); 
       }
      }
         
    }
    
  */  
    
	
	
	
	public function category()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
  
	
	
}
