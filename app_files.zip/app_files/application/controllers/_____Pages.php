<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('DashboardSettings_model');
		$this->load->library('cart');
		
	}
	

	public function index()
	{
	   
	    
		$data=array();
		$data['cartItems'] = $this->cart->contents();
		$data['products']=$this->product_model->get_all_product();
		//$data['website_info']=$this->DashboardSettings_model->fetchGeneralSettings();
		$data['slider_info']=$this->DashboardSettings_model->fetchActiveSliders();
		$data['slider_info']=$this->DashboardSettings_model->fetchActiveSliders();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
		
	//	redirect(base_url());
	}
	
	public function search()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		$data['title']="Yesbd.com Ltd";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/home',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	public function test()
	{
		//$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['products']=$this->product_model->get_all_product();
		//$data['title']="Yesbd.com Ltd";
		//$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/test');
		//$this->load->view('front-end/templates/footer');
	}
	
	
	
	// Offer page
	public function offerPage()
	{
		if(isset($_POST['category']))
		{
			$cat=$this->input->post('category');
			$data=array();
			//$data['cartItems'] = $this->cart->contents();
			$data['offerProducts']=$this->product_model->get_all_offers();
			$data['offerCategories']=$this->product_model->get_offer_categories();
			$data['offersByCategory']=$this->product_model->getOffersByCategory($cat);
			$data['title']="Yesbd.com Ltd || Offers";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/offers',$data);
			$this->load->view('front-end/templates/footer');
		}
		else 
		{
		
			$data=array();
			//$data['cartItems'] = $this->cart->contents();
			$data['offerProducts']=$this->product_model->get_all_offers();
			$data['offerCategories']=$this->product_model->get_offer_categories();
			$data['title']="Yesbd.com Ltd || Offers";
			$this->load->view('front-end/templates/header',$data);
			$this->load->view('front-end/offers',$data);
			$this->load->view('front-end/templates/footer');
		}
		
	}
	
	
	
	// Offer page
	public function category()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['offerProducts']=$this->product_model->get_all_offers();
		//$data['offerCategories']=$this->product_model->get_offer_categories();
		$data['title']="Yesbd.com Ltd || Offers";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/category',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
/* Function for pages like-about us, how to order, contact us, privacy policy etc...*/
	public function displayPage()
	{
		$data=array();
		$this->load->model('pages_model');
		$data['pageInfo']=$this->pages_model->get_all_pages();
		$data['title']="Yesbd.com Ltd || Pages";
		$this->load->view('front-end/templates/header',$data);
		$this->load->view('front-end/page',$data);
		$this->load->view('front-end/templates/footer');
	}
	
	
	
	
  
	
	
}
