<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardCategory extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('dashboardCategory_model');
		$this->load->helper("url");
		
		$login = $this->session->userdata('isAdminLoggedIn');
		if($login==false)
		{
		    redirect(base_url('yesAdmin'));
		}
		
		//$this->output->cache(720);
	}
	

	public function index()
	{
		$data=array();
		$data['categories']=$this->dashboardCategory_model->get_all_category();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/category/categoryList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	public function addCategory()
	{
		$data=array();
		$data['title']="Yesbd.com Ltd. Admin panel || Create Category";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/category/createCategory',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	
	
	// Create new category
	public function createCategory()
	{
		$slug 			= url_title($this->input->post('category_name'), 'dash', true);
		
		$category_icon 	=$this->upload_category_icon();
		$category		=$this->input->post('category_name');
		$categoryExist	=$this->dashboardCategory_model->checkCategory($category);
		if($categoryExist==true)
		{
			$this->session->set_flashdata('categoryExist','Given category already exist!');
			redirect(base_url('admin/categoryList'));
		}
		else
		{
			$data = array(
			'category_name' => $category,
			'category_slug' => $slug,
			'category_icon' => $category_icon,
			'status' => $this->input->post('status')	
			);
			$insert=$this->dashboardCategory_model->createCategory($data);
			if($insert == true) {
				
				$this->session->set_flashdata('success','Category created successfully!');
				redirect(base_url('admin/categoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Category not Added!');
				redirect(base_url('admin/categoryList'));
        	}
		}
		
	}
	
	//fetch single category for update
	public function viewCategory($id)
	{
		$data=array();
		$data['category']=$this->dashboardCategory_model->getCategoryById($id);
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/category/editCategory',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//Update specific category
	public function updateCategory($id)
	{	
	
		$slug 		= url_title($this->input->post('category_name'), 'dash', true);	
		$category	=$this->input->post('category_name');
		$status		=$this->input->post('status');
		if(!empty($_FILES['category_icon']['name'])){
	
		$category_icon = $this->upload_category_icon();
			$data = array(
			'category_name' => $category,
			'category_slug' => $slug,
			'category_icon' => $category_icon,
			'status' => $status	
			);
			$update=$this->dashboardCategory_model->updateCategoryById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Category updated successfully!');
				redirect(base_url('admin/categoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Category not updated!');
				redirect(base_url('admin/categoryList'));
        	}
		}
		else
		{
			// for empty img
			$data = array(
			'category_name' => $category,
			'category_slug' => $slug,
			//'category_icon' => $category_icon,
			'status' => $status	
			);
			$update=$this->dashboardCategory_model->updateCategoryById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Category updated successfully!');
				redirect(base_url('admin/categoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Category not updated!');
				redirect(base_url('admin/categoryList'));
        	}
			
		  
		}
	
	}
	
	
	
	public function upload_category_icon()
    {
		
        $config['upload_path'] = 'uploads/category/parent/';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('category_icon'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['category_icon']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	public function deactivateCategory($id)
	{
		$data = array(
			'status' => 0,
			);
		$changed=$this->dashboardCategory_model->deactivateCategoryById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/categoryList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/categoryList'));
        	}
	}
	
	public function activateCategory($id)
	{
		$data = array(
			'status' => 1,
			);
		$changed=$this->dashboardCategory_model->activateCategoryById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/categoryList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/categoryList'));
        	}
	}
	
	
	
	
	
	//Function for deleting category by category id
	public function deleteCategory($id)
	{
		$delete=$this->dashboardCategory_model->deleteCategoryById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Category Succesfully deleted!');
					redirect(base_url('admin/categoryList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Category not deleted');
					redirect(base_url('admin/categoryList'));
				}
		
	}
	
	
	// Show main page for sub-category
	public function subCategory()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		//$data['categories']=$this->dashboardCategory_model->get_all_active_category();
		$data['subCategories']=$this->dashboardCategory_model->get_all_subCategory();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sub-category/subCategoryList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Display page for new sub-category create
	public function createSubCategory()
	{
		$data=array();
		$data['categories']=$this->dashboardCategory_model->get_all_active_category();
		$data['title']="Yesbd.com Ltd. Admin panel || Create Sub-Category";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sub-category/createSubCategory',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Create new sub-category
	public function saveSubCategory()
	{
		$slug_sub_cat 		= url_title($this->input->post('subCategoryName'), 'dash', true);
		//$slug_main_cat 		= url_title($this->input->post('mainCategoryName'), 'dash', true);		
		$sub_category_icon 	=$this->upload_sub_category_icon();
		$subCategory		=$this->input->post('subCategoryName');
		$mainCategory		=$this->input->post('mainCategoryName');
		$status				=$this->input->post('status');
		
			$data = array(
			'subCategoryName' => $subCategory,
			'sub_category_icon' => $sub_category_icon,
			'subCategorySlug' => $slug_sub_cat,
			//'mainCategorySlug' => $slug_main_cat,
			'category_id' => $mainCategory,
			'status' => $status	
			);
			$insert=$this->dashboardCategory_model->createSubCategory($data);
			if($insert == true) {
				
				$this->session->set_flashdata('success','Sub-Category created successfully!');
				redirect(base_url('admin/subCategoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Sub-Category not created!');
				redirect(base_url('admin/subCategoryList'));
        	}
		
		
	}
	
	public function upload_sub_category_icon()
    {
		
        $config['upload_path'] = 'uploads/category/sub/';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('sub_category_icon'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['sub_category_icon']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	
	
	
	
	
	//fetch single category for update
	public function viewSubCategory($id)
	{
		$data=array();
		$data['categories']=$this->dashboardCategory_model->get_all_active_category();
		$data['subCategory']=$this->dashboardCategory_model->getSubCategoryById($id);
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/sub-category/editSubCategory',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//Update specific sub-category
	public function updateSubCategory($id)
	{
		$slug_sub_cat 	= url_title($this->input->post('subCategoryName'), 'dash', true);
		//$slug_main_cat 	= url_title($this->input->post('mainCategoryName'), 'dash', true);
		$subCategory	=$this->input->post('subCategoryName');
		$mainCategory	=$this->input->post('mainCategoryName');
		$status			=$this->input->post('status');
		if(!empty($_FILES['sub_category_icon']['name'])){
	
		$sub_category_icon = $this->upload_sub_category_icon();
			$data = array(
			'subCategoryName' => $subCategory,
			'sub_category_icon' => $sub_category_icon,
			'subCategorySlug' => $slug_sub_cat,
			//'mainCategorySlug' => $slug_main_cat,
			'category_id' => $mainCategory,
			'status' => $status
			);
			$update=$this->dashboardCategory_model->updateSubCategoryById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Sub-Category updated successfully!');
				redirect(base_url('admin/subCategoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Sub-Category not updated!');
				redirect(base_url('admin/subCategoryList'));
        	}
		}
		else
		{
			// for empty img
			$data = array(
			'subCategoryName' => $subCategory,
			//'sub_category_icon' => $sub_category_icon,
			'subCategorySlug' => $slug_sub_cat,
			//'mainCategorySlug' => $slug_main_cat,
			'category_id' => $mainCategory,
			'status' => $status);
			$update=$this->dashboardCategory_model->updateSubCategoryById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Sub-Category updated successfully!');
				redirect(base_url('admin/subCategoryList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Sub-Category not updated!');
				redirect(base_url('admin/subCategoryList'));
        	}
			
		  
		}
		
	}
	
	
	
	public function deactivateSubCategory($id)
	{
		$data = array(
			'status' => 0,
			);
		$changed=$this->dashboardCategory_model->deactivateSubCategoryById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/subCategoryList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/subCategoryList'));
        	}
	}
	
	public function activateSubCategory($id)
	{
		$data = array(
			'status' => 1,
			);
		$changed=$this->dashboardCategory_model->activateSubCategoryById($data,$id);
			if($changed == true) {
				
				redirect(base_url('admin/subCategoryList'));
        	}
        	else {
        	
				
				redirect(base_url('admin/subCategoryList'));
        	}
	}
	
	
	//Function for deleting sub-category by id
	public function deleteSubCategory($id)
	{
		$delete=$this->dashboardCategory_model->deleteSubCategoryById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Sub-Category Succesfully deleted!');
					redirect(base_url('admin/subCategoryList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Sub-Category not deleted');
					redirect(base_url('admin/subCategoryList'));
				}
		
	}
	
	public function brand()
	{
		$data=array();
		//$data['cartItems'] = $this->cart->contents();
		$data['brands']=$this->dashboardCategory_model->get_all_brand();
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/brands/brandList',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	// Create new category
	public function createBrand()
	{
		$slug 			= url_title($this->input->post('brand_name'), 'dash', true);
		$brand_logo 	= $this->upload_brand_logo();
		$brand_name		=$this->input->post('brand_name');
		$brandExist		=$this->dashboardCategory_model->checkBrand($brand_name);
		if($brandExist==true)
		{
			$this->session->set_flashdata('brandExist','Given brand already exist!');
			redirect(base_url('admin/brandList'));
		}
		else
		{
			$data = array(
			'brand_name' => $brand_name,
			'brand_slug' => $slug,
			'brand_logo' => $brand_logo,
			'status' => $this->input->post('status')	
			);
			$insert=$this->dashboardCategory_model->createBrand($data);
			if($insert == true) {
				
				$this->session->set_flashdata('success','Brand created successfully!');
				redirect(base_url('admin/brandList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Brand not Created!');
				redirect(base_url('admin/brandList'));
        	}
		}
		
	}
	
	//fetch single brand for update
	public function viewBrand($id)
	{
		$data=array();
		$data['brand']=$this->dashboardCategory_model->getBrandById($id);
		$data['title']="Yesbd.com Ltd. Admin panel";
		$this->load->view('back-end/templates/header',$data);
		$this->load->view('back-end/brands/editBrand',$data);
		$this->load->view('back-end/templates/footer');
	}
	
	//Update specific category
	public function updateBrand($id)
	{
		$slug 		= url_title($this->input->post('brand_name'), 'dash', true);
		$brand_name	=$this->input->post('brand_name');
		$status		=$this->input->post('status');
		if(!empty($_FILES['brand_logo']['name'])){
	
		$brand_logo = $this->upload_brand_logo();
			$data = array(
			'brand_name' => $brand_name,
			'brand_slug' => $slug,
			'brand_logo' => $brand_logo,
			'status' => $status	
			);
			$update=$this->dashboardCategory_model->updateBrandById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Brand updated successfully!');
				redirect(base_url('admin/brandList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Brand not updated!');
				redirect(base_url('admin/brandList'));
        	}
		}
		else
		{
			// for empty img
			$data = array(
			'brand_name' => $brand_name,
			'brand_slug' => $slug,
			//'category_icon' => $category_icon,
			'status' => $status	
			);
			$update=$this->dashboardCategory_model->updateBrandById($data,$id);
			if($update == true) {
				
				$this->session->set_flashdata('success','Brand updated successfully!');
				redirect(base_url('admin/brandList'));
        	}
        	else {
        	
				$this->session->set_flashdata('error','Brand not updated!');
				redirect(base_url('admin/brandList'));
        	}
			
		  
		}
	
	}
	
	
	
	public function upload_brand_logo()
    {
		
        $config['upload_path'] = 'assets/uploads/brandLogo';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|jpeg|png|pdf';
        $config['max_size'] = '5000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('brand_logo'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['brand_logo']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
    } 
	
	
	
	
	//Function for deleting brand by brand id
	public function deleteBrand($id)
	{
		$delete=$this->dashboardCategory_model->deleteBrandById($id);
				if($delete)
				{
					$this->session->set_flashdata('success','Brand Succesfully deleted!');
					redirect(base_url('admin/brandList'));
				}
				else 
				{
					
					$this->session->set_flashdata('error','Brand not deleted');
					redirect(base_url('admin/brandList'));
				}
		
	}
  
	
	
}
