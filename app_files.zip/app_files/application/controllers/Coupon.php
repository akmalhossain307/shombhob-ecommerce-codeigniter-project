<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coupon extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Asia/Dhaka');
		$this->load->model('Coupon_model');
		//$this->load->library('cart');
		//$this->output->cache(720);
	}
	
	public function applyCoupon()
	{
		$CurrentURL=$this->input->post('currentURL');
		$coupon_code=$this->input->post('coupon_code');
		$main_price = $this->cart->total();
		$customer_id=$this->session->userdata("active_customer");
		
		$check_coupon = $this->Coupon_model->check_coupon_code($coupon_code);
		if($check_coupon == true)
		{
			$expire_date = new DateTime($check_coupon['coupon_expire_date']);
			$current_date = new DateTime();
			if($expire_date < $current_date)
			{
				$this->session->set_flashdata('expired','Sorry the coupon has expired!');
				redirect($CurrentURL);
			}else
			{
				if($check_coupon['coupon_type'] == 1)
				{
					$check_used = $this->Coupon_model->check_coupon_hasused($check_coupon['coupon_code'], $customer_id);
					if($check_used == true)
					{
						$this->session->set_flashdata('used','You have already used this coupon once!');
						redirect($CurrentURL);
					}else
					{
						if($check_coupon['coupon_discount_type'] == 0)
						{
							$discount = $check_coupon['coupon_discount_price'].'%';
						}else
						{
							$discount = 'TK.'.$check_coupon['coupon_discount_amount'];
						}
						if($check_coupon['coupon_type'] == 0)
						{
							$coupon_type = 'Individual';
						}else
						{
							$coupon_type = 'Bulk';
						}
						$used = array(
									'cpnused_coupon_type'      => $coupon_type,
									'cpnused_coupon_discount ' => $discount,
									'cpnused_coupon_code'      => $check_coupon['coupon_code'],
									'cpnused_customer_id'          => $this->session->userdata('active_customer'),
									'cpnused_date'             => date('Y-m-d H:i:s'),
								);
						$this->Coupon_model->save_used($used);
						
						/*
						
						if($check_coupon['coupon_discount_type'] == 0)
						{
							
							$get_percentage = ($main_price / 100) * intval($check_coupon['coupon_discount_price']);
							$discounts = $get_percentage;
							//$grnd = $main_price - ceil($get_percentage);
							//$total_amount = intval($this->cart->total()) - ceil($get_percentage);
						}else
						{
							//$grnd = $main_price - $check_coupon['coupon_discount_amount'];
							$discounts = $check_coupon['coupon_discount_amount'];
							//$total_amount = intval($this->cart->total()) - $check_coupon['coupon_discount_amount'];
						}
						
						
						
						$coupon_content = '
										  <div class="coupon-ammount-content">
												<p class="applied-coupon">Applied Coupon : &nbsp;&nbsp; '.$check_coupon['coupon_code'].'</p>
												<strong class="pull-left">Discount : </strong>
												<strong class="pull-right">- TK.<span id="total">'.$this->cart->format_number($discounts).'</span></strong>
												
												<input type="hidden" name="coupon_discount" value="'.$discounts.'" />
												<input type="hidden" name="coupon_code" value="'.$check_coupon['coupon_code'].'" />
												<span style="clear:both;display:block"></span>	
										  </div>
										  <p class="order-total">
											<strong class="pull-left">Grand Total : </strong>
											<strong class="pull-right">TK.<span id="grndtotal">'.$this->cart->format_number($grnd).'</span></strong>
										  </p>
										  <input type="hidden" name="total_amnt" value="'.$total_amount.'" />
										  ';
							*/			  
										  
						$setsess['applcopn_code'] = $check_coupon['coupon_code'];
						$setsess['applcopn_discount'] = $discount;
						$this->session->set_userdata($setsess);
						//$result = array("status" => "ok", "coupon_content" => $coupon_content);
						//echo json_encode($result);
						
						$this->session->set_flashdata('applied','Coupon discount applied successfully!');
						redirect($CurrentURL);
						
						
						
						
					}
				}else
				{
					$check_ownership = $this->Coupon_model->check_coupon_owner($check_coupon['coupon_id'], $customer_id);
					if($check_ownership == true)
					{
						if($check_coupon['coupon_discount_type'] == 0)
						{
							$discount = $check_coupon['coupon_discount_price'].'%';
						}else
						{
							$discount = 'TK.'.$check_coupon['coupon_discount_amount'];
						}
						
						if($check_coupon['coupon_type'] == 0)
						{
							$coupon_type = 'Individual';
						}else
						{
							$coupon_type = 'Bulk';
						}
						
						$used = array(
									'cpnused_coupon_type'      => $coupon_type,
									'cpnused_coupon_discount ' => $discount,
									'cpnused_coupon_code'      => $check_coupon['coupon_code'],
									'cpnused_customer_id'          => $this->session->userdata('active_customer'),
									'cpnused_date'             => date('Y-m-d H:i:s'),
								);
						$this->Coupon_model->save_used($used);
						
						/*
						if($check_coupon['coupon_discount_type'] == 0)
						{
							$get_percentage = ($main_price / 100) * intval($check_coupon['coupon_discount_price']);
							$discounts = $get_percentage;
							//$grnd = $main_price - ceil($get_percentage);
							//$total_amount = intval($this->cart->total()) - ceil($get_percentage);
						}else
						{
							//$grnd = $main_price - $check_coupon['coupon_discount_amount'];
							$discounts = $check_coupon['coupon_discount_amount'];
							//$total_amount = intval($this->cart->total()) - $check_coupon['coupon_discount_amount'];
						}
						
						/*
						$coupon_content = '
										  <div class="coupon-ammount-content">
												<p class="applied-coupon">Applied Coupon : &nbsp;&nbsp; '.$check_coupon['coupon_code'].'</p>
												<strong class="pull-left">Discount : </strong>
												<strong class="pull-right">- TK.<span id="total">'.$this->cart->format_number($discounts).'</span></strong>
												
												<input type="hidden" name="coupon_discount" value="'.$check_coupon['coupon_discount_price'].'" />
												<input type="hidden" name="coupon_code" value="'.$check_coupon['coupon_code'].'" />
												<span style="clear:both;display:block"></span>	
										  </div>
										  <p class="order-total">
											<strong class="pull-left">Grand Total : </strong>
											<strong class="pull-right">TK.<span id="grndtotal">'.$this->cart->format_number(ceil($grnd)).'</span></strong>
										  </p>
										  <input type="hidden" name="total_amnt" value="'.$total_amount.'" />
										  ';
										  
							*/			  
										  
						$setsess['applcopn_code'] = $check_coupon['coupon_code'];
						$setsess['applcopn_discount'] = ceil($discount);
						$this->session->set_userdata($setsess);
						//$result = array("status" => "ok", "coupon_content" => $coupon_content);
						//echo json_encode($result);
						$this->session->set_flashdata('applied','Coupon discount applied successfully!');
						redirect($CurrentURL);
					}else
					{
						$this->session->set_flashdata('wrong','The coupon code is wrong!');
						redirect($CurrentURL);
					}
				}
			
			}
		}else
		{
			$this->session->set_flashdata('wrong','The coupon code is wrong!');
			redirect($CurrentURL);
		}
	}
	
	
}
